'use strict';
// The resolver (resolver.c): a separate pass over the whole include graph, after every document parsed.
//   1. top-level identifiers (a duplicate is an error), 2. every base must exist and be a named statement,
//   3. inheritance: an object lists its base chain's fields after its own, 4. $name references resolve to the
//   final value they point at. Statements are visited in creation order, which is node order here.
const { CODES: E } = require('./errors');
const R = require('./reader');
const { latin1 } = require('./bytes');

const lineColOf = (function lineColOf(buf, pos) {
   let line = 1, last = -1;
   for (let i = buf.indexOf(10); i >= 0 && i < pos; i = buf.indexOf(10, i + 1)) { line++; last = i; }
   return [line, pos - last];
});

const docOfNode = (function docOfNode(docs, node) {
   let lo = 0, hi = docs.length - 1;
   while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (docs[mid].lo <= node) lo = mid; else hi = mid - 1;
   }
   return lo;
});

const hashBytes = (function hashBytes(buf, s, e) {
   let h = 0x811c9dc5;
   for (let i = s; i < e; i++) h = Math.imul(h ^ buf[i], 0x01000193);
   return h >>> 0;
});

const sameBytes = (function sameBytes(ab, as, ae, bb, bs, be) {
   if (ae - as !== be - bs) return false;
   for (let i = as, j = bs; i < ae; i++, j++) if (ab[i] !== bb[j]) return false;
   return true;
});

// Returns null when everything resolved, else { code, line, col, message, doc }: doc is the index of the document the position is
// in (FR-2611-anvl-errors-001); absent for the errors with no position (4050, 4051, 4052), which belong to the root.
// Fills `inherited` (object value node -> extra statement nodes) and each VARREF node's resolved slot.
const POOL_SLOTS = new Int32Array(4096), POOL_SLOT_DOC = new Int32Array(4096);
const NO_INHERITED = new Map(); // shared and never written: most documents have no inheritance

const resolve = (function resolve(docs, tree, res) {
   const T = tree.T;
   let total = 0;
   for (const d of docs) total += d.nstmt;
   let cap = 16;
   while (cap < total * 2) cap <<= 1;
   const mask = cap - 1;
   const slotStmt = cap <= POOL_SLOTS.length ? POOL_SLOTS.fill(-1, 0, cap) : new Int32Array(cap).fill(-1);
   const slotDoc = cap <= POOL_SLOTS.length ? POOL_SLOT_DOC : new Int32Array(cap);

   // 1. identifiers
   let count = 0;
   for (let di = 0; di < docs.length; di++) {
      const d = docs[di], buf = d.buf;
      for (let s = d.firstStmt; s >= 0; s = T[s + 6]) {
         const ns = T[s + 1], ne = T[s + 2];
         let i = hashBytes(buf, ns, ne) & mask;
         while (slotStmt[i] >= 0) {
            const o = slotStmt[i];
            const od = docs[slotDoc[i]];
            if (sameBytes(od.buf, T[o + 1], T[o + 2], buf, ns, ne)) {
               const [line, col] = lineColOf(buf, ns);
               const [firstLine] = lineColOf(od.buf, T[o + 1]);
               const nameLen = Math.min(ne - ns, 100);
               const name = latin1(buf, ns, ns + nameLen);
               return {
                  code: E.ANVL_ERR_RESOLVER_DUPLICATE_IDENTIFIER, line, col, doc: di,
                  message: `Duplicate top-level identifier '${name}' (first declared at line ${firstLine})`,
               };
            }
            i = (i + 1) & mask;
         }
         slotStmt[i] = s;
         slotDoc[i] = di;
         count++;
      }
   }

   function lookup(buf, s, e) {
      let i = hashBytes(buf, s, e) & mask;
      while (slotStmt[i] >= 0) {
         const o = slotStmt[i];
         if (sameBytes(docs[slotDoc[i]].buf, T[o + 1], T[o + 2], buf, s, e)) return o;
         i = (i + 1) & mask;
      }
      return -1;
   }

   const bases = tree.baseStmts;
   const docBuf = (node) => docs[docOfNode(docs, node)].buf;

   // 2. bases
   for (const s of bases) {
      const base = lookup(docBuf(s), T[s + 3], T[s + 4]);
      if (base < 0) return { code: E.ANVL_ERR_RESOLVER_MISSING_BASE, line: 0, col: 0 };
      if ((T[base] & 255) === R.S_BLOCK) return { code: E.ANVL_ERR_CANNOT_INHERIT_FROM_ANONYMOUS, line: 0, col: 0 };
      // a base must itself be an object: a scalar, array, tuple, blob or reference has no fields to merge (4020), reported
      // at the base name in the deriving statement
      const bv = T[base + 5];
      if (bv < 0 || T[bv] !== R.T_OBJECT) {
         const [line, col] = lineColOf(docBuf(s), T[s + 3]);
         return { code: E.ANVL_ERR_PARSER_INHERITANCE_REQUIRES_OBJECT, line, col, doc: docOfNode(docs, s) }; // the document holding the deriving statement
      }
   }

   // 3. inheritance. An object's field list is its own statements, then what was merged into it.
   const objectOf = (stmt) => {
      if ((T[stmt] & 255) === R.S_BLOCK) return T[stmt + 5];
      const v = T[stmt + 5];
      return v >= 0 && T[v] === R.T_OBJECT ? v : -1;
   };
   const fieldsOf = (obj) => {
      const out = [];
      for (let c = T[obj + 5]; c >= 0; c = T[c + 6]) out.push(c);
      const extra = res.inherited.get(obj);
      if (extra) for (const x of extra) out.push(x);
      return out;
   };
   const hasName = (obj, field) => {
      const fb = docBuf(field), fs = T[field + 1], fe = T[field + 2];
      for (let c = T[obj + 5]; c >= 0; c = T[c + 6]) {
         if (sameBytes(docBuf(c), T[c + 1], T[c + 2], fb, fs, fe)) return true;
      }
      const extra = res.inherited.get(obj);
      if (extra) for (const c of extra) if (sameBytes(docBuf(c), T[c + 1], T[c + 2], fb, fs, fe)) return true;
      return false;
   };
   const maxHops = count + 1;
   for (const s of bases) {
      const obj = objectOf(s);
      if (obj < 0) continue;
      let bs = T[s + 3], be = T[s + 4], bbuf = docBuf(s);
      let ended = false;
      for (let hop = 0; hop < maxHops; hop++) {
         const anc = lookup(bbuf, bs, be);
         if (anc < 0) { ended = true; break; }
         const ancObj = objectOf(anc);
         if (ancObj >= 0) {
            for (const f of fieldsOf(ancObj)) {
               if (!hasName(obj, f)) {
                  let extra = res.inherited.get(obj);
                  if (!extra) {
                     if (res.inherited === NO_INHERITED) res.inherited = new Map();
                     res.inherited.set(obj, extra = []);
                  }
                  extra.push(f);
               }
            }
         }
         if (T[anc + 3] < 0) { ended = true; break; }
         bbuf = docBuf(anc); bs = T[anc + 3]; be = T[anc + 4];
      }
      if (!ended) return { code: E.ANVL_ERR_RESOLVER_CYCLE_DETECTED, line: 0, col: 0 };
   }

   // 4. references
   let resolved = 0;
   for (const v of tree.varrefs) {
      let ts = T[v + 3], te = T[v + 4], tb = docBuf(v), found = -1;
      for (let hop = 0; hop < maxHops; hop++) {
         const st = lookup(tb, ts, te);
         if (st < 0) break;
         const val = T[st + 5];
         if (val < 0) break; // a block-form statement has an OBJECT value of its own, so a reference to it resolves
         if (T[val] !== R.T_VARREF) { found = val; break; }
         tb = docBuf(val); ts = T[val + 3]; te = T[val + 4];
      }
      T[v + 5] = found;
      resolved += found >= 0;
   }
   // 5. a reference that leads back to a container holding it (BR-2611-anvl-resolver-002). With no resolved reference there is
   // nothing to follow.
   stats.edges = 0;
   return resolved > 0 ? referenceCycle(docs, tree, res) : null;
});


// ------------------------------------------------------------------------------------------------------------------------
// Reference cycles (native resolver.c, check_reference_cycles; conformance/FORMAT.md "Reference cycles").
//
// A `$` reference that leads back to a container holding it is the error 4054. Treat the resolved document as a graph: a walker
// reaches a container's members, the fields an object inherits (listed after its own in `res.inherited`), and, through a
// resolved reference, the value of the statement it names. A reference always resolves to the value of one top-level
// statement, so the graph collapses to those statements: S has an edge to T for every resolved reference in S's walkable
// subtree (not entered through another reference) whose final target is T's value. A reference is on a cycle when the vertex
// that holds it is in the strongly connected component of its target. The reported one is the first on a cycle in source
// order, the documents in load order, then by byte offset: that does not depend on how the search visits statements.
//
// Cost, time and memory O(document + merged member count). An inherited field is a vertex of its own (the same field
// statement is in the list of every statement that inherits it), holding the references of its subtree once; a statement that
// inherits it has one edge to it, never a copy of its references. The vertices are the named statements and those fields, the
// edges the references (at most twice each) and one per inherited field per deriving statement. The components come from an
// iterative Tarjan and the scans use explicit stacks, so a ring of 100000 statements is as safe as one of three.
// ------------------------------------------------------------------------------------------------------------------------
const referenceCycle = (function referenceCycle(docs, tree, res) {
   const T = tree.T;
   const inherited = res.inherited;
   // the vertices that are statements: n of them, in load order (documents in order, statements in source order)
   let cap = 0;
   for (const d of docs) cap += d.nstmt;
   const nodeValue = new Int32Array(cap), nodeDoc = new Int32Array(cap), nodeDerived = new Uint8Array(cap);
   const slots = (T.length >> 3) + 1;              // nodes are 8 ints: a node id >> 3 is a dense key
   const target = new Int32Array(slots);           // a statement's concrete value -> its vertex + 1
   let fieldCache = null;                          // an inherited field's statement -> its vertex + 1, -1 when it holds no reference
   let n = 0;
   for (let di = 0; di < docs.length; di++) {
      for (let s = docs[di].firstStmt; s >= 0; s = T[s + 6]) {
         const v = T[s + 5];
         if (v < 0) continue;
         nodeValue[n] = v;
         nodeDoc[n] = di;
         nodeDerived[n] = T[s + 3] >= 0 ? 1 : 0;
         if (T[v] !== R.T_VARREF) target[v >> 3] = n + 1; // a reference resolves to a concrete value, never to another reference
         n++;
      }
   }
   // edges: the reference node (or -1 for an edge to an inherited field), the vertex it leaves, the vertex it enters
   let ecap = tree.varrefs.length * 2 + 16, ec = 0;
   let eRef = new Int32Array(ecap), eFrom = new Int32Array(ecap), eTo = new Int32Array(ecap);
   const addEdge = (ref, from, to) => {
      if (ec === ecap) {
         ecap *= 2;
         let g = new Int32Array(ecap); g.set(eRef); eRef = g;
         g = new Int32Array(ecap); g.set(eFrom); eFrom = g;
         g = new Int32Array(ecap); g.set(eTo); eTo = g;
      }
      eRef[ec] = ref; eFrom[ec] = from; eTo[ec] = to;
      ec++;
   };
   // the edges of every resolved reference in the walkable subtree of `root`: members and elements at any depth, not through a reference
   let stack = new Int32Array(256);
   const scan = (from, root) => {
      let top = 0;
      stack[top++] = root;
      while (top > 0) {
         const v = stack[--top];
         const t = T[v];
         if (t === R.T_VARREF) {
            const r = T[v + 5];
            if (r >= 0) {
               const to = target[r >> 3] - 1;
               if (to >= 0) addEdge(v, from, to);
            }
         } else if (t === R.T_ARRAY || t === R.T_TUPLE) {
            if (top + T[v + 7] > stack.length) { const g = new Int32Array((top + T[v + 7]) * 2); g.set(stack); stack = g; }
            for (let c = T[v + 5]; c >= 0; c = T[c + 6]) {
               const ct = T[c];
               if (ct === R.T_VARREF || ct === R.T_ARRAY || ct === R.T_TUPLE || ct === R.T_OBJECT) stack[top++] = c;
            }
         } else if (t === R.T_OBJECT) {
            if (top + T[v + 7] > stack.length) { const g = new Int32Array((top + T[v + 7]) * 2); g.set(stack); stack = g; }
            for (let c = T[v + 5]; c >= 0; c = T[c + 6]) {
               const cv = T[c + 5];
               if (cv < 0) continue;
               const ct = T[cv];
               if (ct === R.T_VARREF || ct === R.T_ARRAY || ct === R.T_TUPLE || ct === R.T_OBJECT) stack[top++] = cv;
            }
         }
      }
   };
   let total = n;
   for (let i = 0; i < n; i++) {
      scan(i, nodeValue[i]);
      if (!nodeDerived[i]) continue;
      const extra = inherited.get(nodeValue[i]);
      if (extra === undefined) continue;
      if (fieldCache === null) fieldCache = new Int32Array(slots);
      for (let k = 0; k < extra.length; k++) {
         const f = extra[k], fv = T[f + 5];
         if (fv < 0) continue;
         let node = fieldCache[f >> 3];
         if (node === 0) {
            const before = ec;
            node = total++;
            scan(node, fv);
            if (ec === before) { total--; node = -1; } else node += 1;
            fieldCache[f >> 3] = node < 0 ? -1 : node;
            if (node < 0) continue;
         } else if (node < 0) {
            continue;
         }
         addEdge(-1, i, node - 1);
      }
   }
   stats.edges = ec;

   // group the edges by the vertex they leave (counting sort)
   const start = new Int32Array(total + 2);
   for (let e = 0; e < ec; e++) start[eFrom[e] + 1]++;
   for (let v = 0; v < total; v++) start[v + 1] += start[v];
   const adj = new Int32Array(ec);
   const fill = start.slice(0, total + 1);
   for (let e = 0; e < ec; e++) adj[fill[eFrom[e]]++] = e;

   // Tarjan's strongly connected components, iterative
   const comp = new Int32Array(total).fill(-1);
   const order = new Int32Array(total), low = new Int32Array(total), cursor = new Int32Array(total);
   const tstack = new Int32Array(total), calls = new Int32Array(total);
   let nextOrder = 1, nextComp = 0, sp = 0;
   for (let root = 0; root < total; root++) {
      if (order[root] !== 0) continue;
      let depth = 0;
      order[root] = low[root] = nextOrder++;
      cursor[root] = start[root];
      calls[depth++] = root;
      tstack[sp++] = root;
      while (depth > 0) {
         const v = calls[depth - 1];
         if (cursor[v] < start[v + 1]) {
            const w = eTo[adj[cursor[v]++]];
            if (order[w] === 0) {
               order[w] = low[w] = nextOrder++;
               cursor[w] = start[w];
               calls[depth++] = w;
               tstack[sp++] = w;
            } else if (comp[w] < 0 && order[w] < low[v]) {
               low[v] = order[w];
            }
            continue;
         }
         if (low[v] === order[v]) {
            let w;
            do { w = tstack[--sp]; comp[w] = nextComp; } while (w !== v);
            nextComp++;
         }
         depth--;
         if (depth > 0 && low[v] < low[calls[depth - 1]]) low[calls[depth - 1]] = low[v];
      }
   }

   // the first reference whose holder (its statement, or the inherited field that holds it) is in the component of its target
   let best = -1, bestDoc = 0;
   for (let e = 0; e < ec; e++) {
      const ref = eRef[e];
      if (ref < 0 || comp[eFrom[e]] !== comp[eTo[e]]) continue;
      const d = docs.length === 1 ? 0 : docOfNode(docs, ref);
      if (best < 0 || d < bestDoc || (d === bestDoc && T[ref + 1] < T[best + 1])) { best = ref; bestDoc = d; }
   }
   if (best < 0) return null;
   const [line, col] = lineColOf(docs[bestDoc].buf, T[best + 1]);
   return { code: E.ANVL_ERR_RESOLVER_REFERENCE_CYCLE, line, col, doc: bestDoc };
});

// test hook: the edges the reference-cycle check of the last resolve built (like native's anvl_resolver_last_edges)
const stats = { edges: 0 };

module.exports = { resolve, NO_INHERITED, lineColOf, docOfNode, stats };
