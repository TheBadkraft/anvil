'use strict';
// AnvilWriter: the streaming writer (phase S3), a port of native's src/writer (writer.c, grammar.c). Browser-safe: no node buffers;
// the Node entry point installs a bytes wrapper with setBytes(). Output is built as a JS string and encoded to
// UTF-8 once, at finish; blob bytes that are not valid UTF-8 switch the writer to a list of byte chunks.
const AnvilDialect = Object.freeze({ AML: 0, AMP: 1 });
const WriterErrorCode = Object.freeze({
   OK: 0, INVALID_ARGUMENT: 1, MEMORY: 2, STATE: 3, DIALECT: 4, INVALID_IDENTIFIER: 5, RESERVED_WORD: 6,
   INVALID_NUMERIC: 7, INVALID_BARE: 8, INVALID_BLOB: 9, INVALID_ATTRIBUTE_VALUE: 10, INVALID_INCLUDE_PATH: 11,
   EMPTY_COLLECTION: 12, INHERITANCE_REQUIRES_OBJECT: 13, UNFINISHED: 14, DUPLICATE_NAME: 15, DEPTH_EXCEEDED: 16,
   DUPLICATE_FIELD: 17, DUPLICATE_ATTRIBUTE_KEY: 18, INHERITANCE_CYCLE: 19, MISSING_BASE: 20, BLOCK_REQUIRES_OBJECT: 21,
   BASE_IS_BLOCK_FORM: 22, NESTED_BASE: 23, REFERENCE_CYCLE: 24,
});
const E = WriterErrorCode;

// anvil_writer_error_message
const MESSAGES = [
   'no error', 'invalid argument', 'memory allocation failed', 'call is not legal at this point in the document',
   'construct is forbidden in this dialect', 'invalid identifier', 'reserved word', 'invalid numeric',
   'text cannot be written as a bare literal', 'invalid blob tag or content', 'invalid attribute value',
   'invalid include path', 'empty collection (arrays and objects need 1 element, tuples 2)',
   'a statement with a base must have an object value', 'document has an open statement, array, tuple or object',
   'top-level name declared twice', 'nesting is too deep', 'field name declared twice in one object',
   'attribute key given twice',
   "inheritance cycle: a statement's base chain loops back to itself",
   'base names no member of the document and no include could supply it',
   'a block-form statement must have an object value',
   'a base cannot be a block-form statement (it is read-only)',
   'only a top-level statement can have a base',
   "reference cycle: a '$' reference leads back to a value that contains it",
];

class AnvilWriterError extends Error {
   constructor(code) {
      super(MESSAGES[code] || 'unknown error');
      this.name = 'AnvilWriterError';
      this.code = code;
   }
}

let wrapBytes = (u8) => u8; // the Node entry point makes these node buffers, as anvil-node returns them
function setBytes(fn) { wrapBytes = fn; }

const Arg = {
   // A required NUL-terminated string: native code would silently truncate at an embedded NUL.
   required(value, what) {
      if (typeof value !== 'string') throw new TypeError(`${what} must be a string, not ${typeof value}`);
      if (value.includes('\0')) throw new RangeError(`${what} must not contain a NUL character`);
      return value;
   },
   optional(value, what) {
      return value === null || value === undefined ? null : Arg.required(value, what);
   },
   dialect(value) {
      if (value !== AnvilDialect.AML && value !== AnvilDialect.AMP) {
         throw new TypeError('dialect must be AnvilDialect.AML or AnvilDialect.AMP');
      }
      return value;
   },
};

const enc = new TextEncoder();
const dec = new TextDecoder('utf-8', { ignoreBOM: true });
const strict = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

const FLUSH_AT = 16384;
const T_ARRAY = 0, T_TUPLE = 1, T_OBJECT = 2;
const P_HEADER = 0, P_BODY = 1, P_FINISHED = 2;
const INDENTS = ['', '   ', '      ', '         '];
function indent(n) { return n < INDENTS.length ? INDENTS[n] : ' '.repeat(3 * n); }


// ---- grammar.c: what the writer accepts. Text is a JS string; a non-ASCII char is a byte >= 0x80 natively, which
// no identifier, bare or numeric rule accepts, so the ASCII-only tests below agree with the byte-wise ones.
const TAG = /^[A-Za-z_][A-Za-z0-9_]{0,30}$/;
const KEYWORDS = new Set(['include', 'import', 'vars', 'true', 'false', 'null']);
const BARE_REST = /^[A-Za-z0-9_\-./:$]*$/;

function checkName(s) {
   const n = s.length;
   if (n === 0) return E.INVALID_IDENTIFIER;
   let c = s.charCodeAt(0);
   if (!((c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 95)) return E.INVALID_IDENTIFIER;
   for (let i = 1; i < n; i++) {
      c = s.charCodeAt(i);
      if (!((c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 95 || (c >= 48 && c <= 57))) return E.INVALID_IDENTIFIER;
   }
   return n <= 7 && KEYWORDS.has(s) ? E.RESERVED_WORD : 0;
}

const isDigit = (c) => c >= 48 && c <= 57;

// Whether the reader would take a digit-led token as a number (or fail on it) rather than fall back to a bare literal.
function readerTakesAsNumber(s) {
   let i = 0;
   const n = s.length;
   const at = (k) => (k < n ? s.charCodeAt(k) : 0);
   if (!isDigit(at(i))) return false;
   while (isDigit(at(i))) i++;
   if (at(i) === 46) {
      i++;
      if (!isDigit(at(i))) {
         const c = at(i);
         return i >= n || ((c === 101 || c === 69) && (isDigit(at(i + 1)) || at(i + 1) === 43 || at(i + 1) === 45 || i + 1 >= n));
      }
      while (isDigit(at(i))) i++;
      if (at(i) === 46) return false;
   }
   if (at(i) === 101 || at(i) === 69) {
      let e = i + 1;
      if (at(e) === 43 || at(e) === 45) {
         if (!isDigit(at(e + 1))) return true;
         e++;
      } else if (e >= n) {
         return true;
      }
      if (isDigit(at(e))) {
         while (isDigit(at(e))) e++;
         i = e;
      }
   }
   return i >= n;
}

function checkBare(s) {
   const f = s.charCodeAt(0);
   // first char: alpha, '_', '.', '/' or digit
   const start = (f >= 65 && f <= 90) || (f >= 97 && f <= 122) || f === 95 || f === 46 || f === 47 || isDigit(f);
   if (!start || !BARE_REST.test(s)) return E.INVALID_BARE;
   if (KEYWORDS.has(s)) return E.RESERVED_WORD;
   if (readerTakesAsNumber(s) || (f === 47 && (s.charCodeAt(1) === 47 || s.charCodeAt(1) === 42))) return E.INVALID_BARE;
   return 0;
}

// The text of a JS string as the UTF-8 bytes it encodes to: a lone surrogate is U+FFFD (as a UTF-8 encoder makes it).
const SURR = /[\uD800-\uDFFF]/;
function wellFormed(s) {
   if (!SURR.test(s)) return s;
   let out = '';
   for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c >= 0xD800 && c <= 0xDBFF && i + 1 < s.length && (s.charCodeAt(i + 1) & 0xFC00) === 0xDC00) {
         out += s[i] + s[++i];
      } else {
         out += c >= 0xD800 && c <= 0xDFFF ? '\uFFFD' : s[i];
      }
   }
   return out;
}

// string(): `"`, `\`, newline, tab and carriage return are escaped; every other char is written as is.
const NEEDS_WORK = /["\\\n\t\r\uD800-\uDFFF]/;
function quoteString(s) {
   if (!NEEDS_WORK.test(s)) return '"' + s + '"';
   s = wellFormed(s);
   let out = '"';
   let run = 0;
   for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      let esc;
      if (c === 34) esc = '\\"'; else if (c === 92) esc = '\\\\'; else if (c === 10) esc = '\\n'; else if (c === 9) esc = '\\t'; else if (c === 13) esc = '\\r'; else continue;
      out += s.slice(run, i) + esc;
      run = i + 1;
   }
   return out + s.slice(run) + '"';
}

// Raw attribute value text, emitted verbatim: no empty value, no leading '$', '[', '(', '{', backtick or '@', no
// leading or trailing blank, no newline, and no ',' or ']' outside double quotes (the reader ends the value there).
function checkAttributeValue(v) {
   const n = v.length;
   if (n === 0) return E.INVALID_ATTRIBUTE_VALUE;
   const f = v[0], l = v[n - 1];
   if (f === '$' || f === '[' || f === '(' || f === '{' || f === '`' || f === '@' || f === ' ' || f === '\t' || l === ' ' || l === '\t') {
      return E.INVALID_ATTRIBUTE_VALUE;
   }
   let inString = false;
   for (let i = 0; i < n; i++) {
      const c = v[i];
      if (c === '\n' || c === '\r') return E.INVALID_ATTRIBUTE_VALUE;
      if (c === '"') inString = !inString;
      else if (!inString && (c === ',' || c === ']')) return E.INVALID_ATTRIBUTE_VALUE;
   }
   return inString ? E.INVALID_ATTRIBUTE_VALUE : 0;
}

function checkAttributeText(t) {
   return /["\n\r]/.test(t) ? E.INVALID_ATTRIBUTE_VALUE : 0;
}


// native's wg_check_numeric: -?digits(.digits)?([eE][+-]?digits)?
const NUMERIC = /^-?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/;

// native's wg_format_double is the first of printf's %.15g, %.16g, %.17g that reads back as the same double, with %g's
// layout (fixed unless the exponent X is < -4 or >= the precision p). The digits are the shortest that read back
// (toExponential() with no argument): when that is n <= 15 digits, %.15g rounds to the same digits padded with zeros;
// when it is 16 or 17, the correctly rounded p-digit text is the closest p-digit decimal, which is what the shortest
// algorithm picks. So the digits are JS's and only the layout is %g's. (Checked against C printf on 10^5 doubles.)
function formatDouble(v) {
   const neg = v < 0;
   if (v === 0) return Object.is(v, -0) ? '-0' : '0';
   const a = neg ? -v : v;
   let p = 15;
   let m = a.toExponential();
   if (a < 2.2250738585072014e-308) {
      // a subnormal has fewer than 15 significant bits' worth of digits: %.15g can round-trip with more digits than the
      // shortest. No exact tie is possible at these exponents (a subnormal's decimal expansion is hundreds of digits long).
      for (; p <= 17; p++) {
         m = a.toExponential(p - 1);
         if (Number(m) === a) break;
      }
   }
   const e = m.indexOf('e');
   let digits = m.slice(0, 1) + m.slice(2, e);
   const x = +m.slice(e + 1);
   let n = digits.length;
   while (n > 1 && digits.charCodeAt(n - 1) === 48) n--; // %g drops trailing zeros
   digits = digits.slice(0, n);
   if (p === 15 && n > 15) p = n;
   let out;
   if (x < -4 || x >= p) {
      const ax = x < 0 ? -x : x;
      out = digits[0] + (n > 1 ? '.' + digits.slice(1) : '') + (x < 0 ? 'e-' : 'e+') + (ax < 10 ? '0' : '') + ax;
   } else if (x >= 0) {
      out = n <= x + 1 ? digits + '0'.repeat(x + 1 - n) : digits.slice(0, x + 1) + '.' + digits.slice(x + 1);
   } else {
      out = '0.' + '0'.repeat(-x - 1) + digits;
   }
   return neg ? '-' + out : out;
}

// Blob content as [text, bytes]: the content as a string when it is valid UTF-8 (bytes null), else null and the bytes.
function blobContent(data) {
   let bytes;
   if (typeof data === 'string') return [wellFormed(data), null];
   if (ArrayBuffer.isView(data)) bytes = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
   else if (data instanceof ArrayBuffer) bytes = new Uint8Array(data);
   else throw new TypeError('data must be bytes (Uint8Array) or a string');
   try { return [strict.decode(bytes), null]; } catch (e) { return [null, bytes]; }
}

class Frame {
   constructor(kind, owns) {
      this.kind = kind;
      this.count = 0;
      this.multiline = false;
      this.owns = owns;
      this.names = null;
   }
}

class AnvilWriter {
   constructor(dialect) {
      this._dialect = dialect;
      this._err = 0;
      this._disposed = false;
      this._phase = P_HEADER;
      this._s = dialect === 0 ? '#!aml\n\n' : '#!amp\n\n';
      this._done = ''; // text before _s: the builder's emit moves _s here, flattened, now and then (see _statementTrusted)
      this._parts = null; // byte chunks, once a blob that is not valid UTF-8 has been written
      this._stack = [];
      this._stmtOpen = false;
      this._stmtBase = false; // the open statement has a base or is block form: its value must be an object
      this._stmtBlock = false; // the open statement is block form (`name { ... };`): no ':=' before its value
      this._attrsOpen = false;
      this._headerDirty = false;
      this._headerAttrs = false; // a module attribute has been written: an include must come before it
      this._names = new Set();
      this._blockNames = null; // the top-level names written in block form (a block form cannot be a base)
      this._owns = false;
      this._stmtKeys = null; // attribute keys of the open statement
      this._moduleKeys = null; // and of the module header
   }

   // A forward-only writer; its shebang line is emitted immediately.
   static create(dialect) {
      return new AnvilWriter(Arg.dialect(dialect));
   }

   _live() {
      if (this._disposed) throw new Error('AnvilWriter has been disposed');
   }

   // Every call returns the writer. The first rejected call throws and the error is sticky.
   _check(ok) {
      if (!ok) throw new AnvilWriterError(this._err);
      return this;
   }

   _fail(code) {
      if (this._err === 0) this._err = code;
      return false;
   }

   // the common entry check of writer.c: no earlier error, not yet finished
   _ready() {
      if (this._err !== 0) return false;
      if (this._phase === P_FINISHED) return this._fail(E.STATE);
      return true;
   }

   get error() {
      this._live();
      return this._err;
   }

   // ---- statements ----

   statement(name, base = null) {
      this._live();
      return this._check(this._statement(Arg.required(name, 'name'), Arg.optional(base, 'base')));
   }

   // The block form `name [: base] [@[attributes]] { ... };`: the anonymous, read-only form. Its value is an object, AML only
   // (BR-2611-anvl-writer-001).
   statementBlock(name, base = null) {
      this._live();
      return this._check(this._statement(Arg.required(name, 'name'), Arg.optional(base, 'base'), true));
   }

   _statement(name, base, block = false) {
      if (!this._ready()) return false;
      const n = this._stack.length;
      if ((base !== null || block) && this._dialect === 1) return this._fail(E.DIALECT);
      if (this._stmtOpen || (n > 0 && this._stack[n - 1].kind !== T_OBJECT)) return this._fail(E.STATE);
      let bad = checkName(name);
      if (bad === 0 && base !== null) bad = checkName(base);
      if (bad !== 0) return this._fail(bad);
      // a base names a top-level statement, and the reader rejects a block-form one there (4052)
      if (base !== null && n === 0 && this._blockNames !== null && this._blockNames.has(base)) return this._fail(E.BASE_IS_BLOCK_FORM);
      if (n === 0) {
         if (this._names.has(name)) return this._fail(E.DUPLICATE_NAME);
         this._names.add(name);
         if (block) (this._blockNames === null ? (this._blockNames = new Set()) : this._blockNames).add(name);
      } else {
         const top = this._stack[n - 1];
         if (top.names === null) top.names = new Set();
         if (top.names.has(name)) return this._fail(E.DUPLICATE_FIELD);
         top.names.add(name);
         // only a top-level statement may have a base; the reader rejects one inside an object (4022), after the name
         if (base !== null) return this._fail(E.NESTED_BASE);
      }
      if (this._phase === P_HEADER) {
         if (this._headerDirty) this._s += '\n';
         this._phase = P_BODY;
      }
      this._s += indent(n) + name;
      this._stmtOpen = true;
      if (base !== null) this._s += ' : ' + base;
      this._stmtBase = base !== null || block;
      this._stmtBlock = block;
      this._attrsOpen = false;
      this._stmtKeys = null;
      return true;
   }

   // statement() for a name and base the builder has already validated, on a writer it has just made (so no name is repeated):
   // the same output and state, without the checks that cannot fail.
   _statementTrusted(name, base, block = false) {
      if (this._err !== 0) return false;
      const n = this._stack.length;
      if ((base !== null || block) && this._dialect === 1) return this._fail(E.DIALECT);
      if (this._stmtOpen || (n > 0 && this._stack[n - 1].kind !== T_OBJECT)) return this._fail(E.STATE);
      if (this._phase === P_HEADER) {
         if (this._headerDirty) this._s += '\n';
         this._phase = P_BODY;
      }
      if (this._s.length > FLUSH_AT && n === 0) {
         // a big document is a rope of small appends (about 9 bytes of heap per byte of text, all of it live until the end);
         // flattening it now and then keeps that garbage young
         Number(this._s); // reading a rope as a number flattens it (charCodeAt does not)
         this._done += this._s;
         this._s = '';
      }
      this._s += indent(n) + name;
      this._stmtOpen = true;
      if (base !== null) this._s += ' : ' + base;
      this._stmtBase = base !== null || block;
      this._stmtBlock = block;
      this._attrsOpen = false;
      return true;
   }

   // ---- values ----

   // Where a value goes (an array/tuple element, or the open statement's value), the dialect and base rules, and the
   // separator or ` := ` before it. Sets this._owns: whether the value completes a statement.
   _prelude(isObject, isCollection) {
      if (!this._ready()) return false;
      const n = this._stack.length;
      if (n > 0 && this._stack[n - 1].kind !== T_OBJECT) {
         const top = this._stack[n - 1];
         if (this._dialect === 1 && isCollection) return this._fail(E.DIALECT);
         if (top.count > 0) this._s += ',';
         if (top.multiline || isObject) {
            top.multiline = true;
            this._s += '\n' + indent(n);
         } else if (top.count > 0) {
            this._s += ' ';
         }
         this._owns = false;
         return true;
      }
      if (!this._stmtOpen) return this._fail(E.STATE);
      if (isObject && this._dialect === 1) return this._fail(E.DIALECT);
      if (this._stmtBase && !isObject) return this._fail(this._stmtBlock ? E.BLOCK_REQUIRES_OBJECT : E.INHERITANCE_REQUIRES_OBJECT);
      this._s += this._stmtBlock ? (this._attrsOpen ? '] ' : ' ') : this._attrsOpen ? '] := ' : ' := ';
      this._stmtOpen = false;
      this._stmtBlock = false;
      this._attrsOpen = false;
      this._owns = true;
      return true;
   }

   _complete(owns) {
      if (owns) this._s += ';\n';
      const n = this._stack.length;
      if (n > 0) this._stack[n - 1].count++;
      return true;
   }

   // A complete scalar value (its text): _prelude, the text and _complete as one step, for the common case.
   _scalar(body) {
      if (this._err !== 0) return false;
      if (this._phase === P_FINISHED) return this._fail(E.STATE);
      const st = this._stack;
      const n = st.length;
      if (n > 0) {
         const top = st[n - 1];
         if (top.kind !== T_OBJECT) {
            this._s += top.multiline ? (top.count > 0 ? ',\n' : '\n') + indent(n) + body : top.count > 0 ? ', ' + body : body;
            top.count++;
            return true;
         }
      }
      if (!this._stmtOpen) return this._fail(E.STATE);
      if (this._stmtBase) return this._fail(this._stmtBlock ? E.BLOCK_REQUIRES_OBJECT : E.INHERITANCE_REQUIRES_OBJECT);
      this._s += (this._attrsOpen ? '] := ' : ' := ') + body + ';\n';
      this._stmtOpen = false;
      this._attrsOpen = false;
      if (n > 0) st[n - 1].count++;
      return true;
   }

   null() {
      this._live();
      return this._check(this._scalar('null'));
   }

   value(value) {
      this._live();
      if (value === null) return this._check(this._scalar('null'));
      if (typeof value === 'boolean') return this._check(this._scalar(value ? 'true' : 'false'));
      if (typeof value === 'number') {
         return this._check(Number.isSafeInteger(value) ? this._scalar(String(value)) : this._doubleNum(value));
      }
      if (typeof value === 'bigint') return this._check(this._scalar(value.toString()));
      throw new TypeError(`value() takes null, a boolean, a number or a bigint, not ${typeof value}; ` +
                          'use string() or bare() for text, blob() for bytes');
   }

   // native's anvil_writer_double: the double is always written as its shortest %g text (internal: value() sends a safe
   // integer down the integer path, and anvil-node has no call for a double that holds an integer, or for -0)
   _double(value) {
      this._live();
      return this._check(this._doubleNum(value));
   }

   _doubleNum(value) {
      if (this._err !== 0) return false;
      if (!Number.isFinite(value)) return this._fail(E.INVALID_NUMERIC);
      return this._scalar(formatDouble(value));
   }

   // ANVL numeric text: -?digits(.digits)?([eE][+-]?digits)?
   numeric(text) {
      this._live();
      Arg.required(text, 'text');
      if (this._err !== 0) return this._check(false);
      if (!NUMERIC.test(text)) return this._check(this._fail(E.INVALID_NUMERIC));
      return this._check(this._scalar(text));
   }

   // A quoted string; ", \\, newline, tab and carriage return are escaped.
   string(text) {
      this._live();
      if (typeof text !== 'string') throw new TypeError(`text must be a string, not ${typeof text}`);
      return this._check(this._scalar(quoteString(text)));
   }

   // An unquoted literal; rejected unless it reads back as a bare literal.
   bare(text) {
      this._live();
      Arg.required(text, 'text');
      if (this._err !== 0) return this._check(false);
      const bad = checkBare(text);
      if (bad !== 0) return this._check(this._fail(bad));
      return this._check(this._scalar(text));
   }

   // `tag` is null (or empty) for an untagged blob; `data` is bytes or a string. A backtick in the content is
   // rejected (INVALID_BLOB): a blob has no escape for its closing delimiter.
   blob(tag, data) {
      this._live();
      tag = Arg.optional(tag, 'tag');
      return this._check(this._blob(tag, ...blobContent(data)));
   }

   // The blob step on a tag and content already converted: `text` is the content as a string when it is valid UTF-8, else
   // null and `bytes` holds it.
   _blob(tag, text, bytes) {
      if (this._err !== 0) return false;
      const tagged = tag !== null && tag !== '';
      if ((tagged && !TAG.test(tag)) || (text !== null ? text.includes('`') : bytes.includes(96))) {
         return this._fail(E.INVALID_BLOB);
      }
      if (text !== null) return this._scalar((tagged ? '@' + tag : '') + '`' + text + '`');
      // bytes that are not UTF-8: the text so far becomes a chunk, then the bytes, then the closing backtick starts the next
      if (!this._prelude(false, false)) return false;
      this._s += (tagged ? '@' + tag : '') + '`';
      (this._parts || (this._parts = [])).push(enc.encode(this._done + this._s), bytes.slice());
      this._done = '';
      this._s = '`';
      return this._complete(this._owns);
   }

   // ---- header (AML only, before the first statement) ----

   // Before the first statement a module attribute (`@[key=value]` on its own line); right after statement() a
   // statement attribute. `value` is raw text emitted verbatim, or null for a flag.
   attribute(key, value = null) {
      this._live();
      return this._check(this._attribute(Arg.required(key, 'key'), Arg.optional(value, 'value'), false));
   }

   attributeString(key, text) {
      this._live();
      if (typeof text !== 'string') throw new TypeError(`text must be a string, not ${typeof text}`);
      return this._check(this._attribute(Arg.required(key, 'key'), wellFormed(text), true));
   }

   _attribute(key, value, quoted) {
      if (!this._ready()) return false;
      if (this._dialect === 1) return this._fail(E.DIALECT);
      if (!(this._stmtOpen || (this._phase === P_HEADER && this._stack.length === 0))) return this._fail(E.STATE);
      let bad = checkName(key);
      if (bad === 0 && value !== null) bad = quoted ? checkAttributeText(value) : checkAttributeValue(value);
      if (bad !== 0) return this._fail(bad);
      let keys = this._stmtOpen ? this._stmtKeys : this._moduleKeys;
      if (keys === null) {
         keys = new Set();
         if (this._stmtOpen) this._stmtKeys = keys; else this._moduleKeys = keys;
      }
      if (keys.has(key)) return this._fail(E.DUPLICATE_ATTRIBUTE_KEY);
      keys.add(key);
      if (this._stmtOpen) {
         this._s += (this._attrsOpen ? ', ' : ' @[') + key;
         this._attrsOpen = true;
      } else {
         this._s += '@[' + key;
      }
      if (value !== null) this._s += quoted ? '="' + value + '"' : '=' + wellFormed(value);
      if (!this._stmtOpen) {
         this._headerDirty = true;
         this._headerAttrs = true;
         this._s += ']\n';
      }
      return true;
   }

   // A statement attribute the builder has already validated, on a writer it has just made (so no key is repeated).
   _attributeTrusted(key, value, quoted) {
      if (this._err !== 0) return false;
      if (this._dialect === 1) return this._fail(E.DIALECT);
      if (!this._stmtOpen) return this._fail(E.STATE);
      this._s += (this._attrsOpen ? ', ' : ' @[') + key;
      this._attrsOpen = true;
      if (value !== null) this._s += quoted ? '="' + value + '"' : '=' + value;
      return true;
   }

   // `include "path";` (module header, AML only)
   include(path) {
      this._live();
      return this._check(this._include(Arg.required(path, 'path')));
   }

   _include(path) {
      if (!this._ready()) return false;
      if (this._dialect === 1) return this._fail(E.DIALECT);
      if (this._phase !== P_HEADER || this._stack.length !== 0 || this._stmtOpen || this._headerAttrs) return this._fail(E.STATE);
      if (path === '' || /["\n\r]/.test(path)) return this._fail(E.INVALID_INCLUDE_PATH);
      this._headerDirty = true;
      this._s += 'include "' + wellFormed(path) + '";\n';
      return true;
   }

   // A dollar-name reference (AML only).
   varref(name) {
      this._live();
      return this._check(this._varref(Arg.required(name, 'name')));
   }

   _varref(name) {
      if (this._err !== 0) return false;
      if (this._dialect === 1) return this._fail(E.DIALECT);
      const bad = checkName(name);
      if (bad !== 0) return this._fail(bad);
      return this._scalar('$' + name);
   }

   // ---- collections ----

   _begin(kind) {
      const isObject = kind === T_OBJECT;
      if (!this._prelude(isObject, true)) return false;
      this._s += kind === T_ARRAY ? '[' : kind === T_TUPLE ? '(' : '{\n';
      this._stack.push(new Frame(kind, this._owns));
      return true;
   }

   _end(kind) {
      if (!this._ready()) return false;
      const n = this._stack.length;
      if (n === 0 || this._stack[n - 1].kind !== kind || this._stmtOpen) return this._fail(E.STATE);
      const done = this._stack[n - 1];
      if (done.count < (kind === T_TUPLE ? 2 : 1)) return this._fail(E.EMPTY_COLLECTION);
      this._stack.pop();
      if (kind === T_OBJECT) this._s += indent(n - 1) + '}';
      else this._s += (done.multiline ? '\n' + indent(n - 1) : '') + (kind === T_ARRAY ? ']' : ')');
      return this._complete(done.owns);
   }

   beginArray() { this._live(); return this._check(this._begin(T_ARRAY)); }
   endArray() { this._live(); return this._check(this._end(T_ARRAY)); }
   beginTuple() { this._live(); return this._check(this._begin(T_TUPLE)); }
   endTuple() { this._live(); return this._check(this._end(T_TUPLE)); }
   beginObject() { this._live(); return this._check(this._begin(T_OBJECT)); }
   endObject() { this._live(); return this._check(this._end(T_OBJECT)); }

   // ---- output ----

   _finish() {
      if (this._err !== 0) return false;
      if (this._phase === P_FINISHED) return true;
      if (this._stack.length > 0 || this._stmtOpen) return this._fail(E.UNFINISHED);
      this._phase = P_FINISHED;
      return true;
   }

   _bytes() {
      if (this._parts === null) return enc.encode(this._done + this._s);
      const parts = this._parts.concat([enc.encode(this._done + this._s)]);
      let n = 0;
      for (const p of parts) n += p.length;
      const out = new Uint8Array(n);
      n = 0;
      for (const p of parts) { out.set(p, n); n += p.length; }
      return out;
   }

   _text() {
      return this._parts === null ? this._done + this._s : dec.decode(this._bytes());
   }

   // Closes the document and returns its exact bytes. Throws UNFINISHED if anything is still open. Idempotent.
   finishBytes() {
      this._live();
      this._check(this._finish());
      return wrapBytes(this._bytes());
   }

   finish() {
      this._live();
      this._check(this._finish());
      return this._text();
   }

   // The emitted bytes, or null until finish() has succeeded.
   get data() {
      this._live();
      return this._err !== 0 || this._phase !== P_FINISHED ? null : wrapBytes(this._bytes());
   }

   get text() {
      this._live();
      return this._err !== 0 || this._phase !== P_FINISHED ? null : this._text();
   }

   dispose() {
      this._disposed = true;
      this._s = '';
      this._done = '';
      this._parts = null;
   }
}

// native's anvil_writer_error_message (internal: the corpus runner prints it; anvil-node exposes it only as AnvilWriterError.message)
function writerErrorMessage(code) { return MESSAGES[code] || 'unknown error'; }

// The grammar checks and encoders the builder shares with the writer (internal; not part of the public API).
const grammar = { checkName, checkBare, checkAttributeValue, checkAttributeText, NUMERIC, TAG, quoteString, wellFormed, formatDouble, blobContent };

module.exports = { AnvilDialect, WriterErrorCode, AnvilWriterError, AnvilWriter, setBytes, writerErrorMessage, KEYWORDS, Arg, grammar };
