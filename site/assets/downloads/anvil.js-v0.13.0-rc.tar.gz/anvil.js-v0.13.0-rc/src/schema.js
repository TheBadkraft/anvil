'use strict';
// The type registry and AnvilSchema (anvil_type_registry.h, anvil_schema.h) with anvil-node's API.
// Enums mirror the C names; test/compat's types-schema.test.js pins every value against the vendored headers.

const TypeKind = Object.freeze({
   UNKNOWN: 0, NUMERIC: 1, STRING: 2, BOOL: 3, OBJECT: 4, TUPLE: 5, ARRAY: 6, ENUM: 7, BLOB: 8,
});
const TypeDiagnostic = Object.freeze({
   NAME_COLLISION: 1, UNKNOWN_BASE_TYPE: 2, MALFORMED_CONSTRAINT: 3, MALFORMED_ENUM_VALUES: 4,
});
const SchemaViolation = Object.freeze({
   REQUIRED: 1, TYPE_MISMATCH: 2, SIZE: 3, RANGE: 4, VALUES: 5, UNKNOWN_FIELD: 6, ITEM_COUNT: 7,
   TAG: 8, FORMAT: 9, UNRESOLVED_TYPE: 10,
});
const SchemaDiagnostic = Object.freeze({
   UNKNOWN_TYPE: 1, MALFORMED_CONSTRAINT: 2, RULE_NOT_OBJECT: 3, UNKNOWN_FORMAT: 4,
   SELF_REFERENCE: 5, CONFLICTING_CONSTRAINTS: 6, TYPE_REGISTRY: 7,
});


// A class's methods compile on their first call; a function's, written as a parenthesized expression, at load.
const defineMethod = (function defineMethod(proto, name, fn) { Object.defineProperty(proto, name, { value: fn, writable: true, configurable: true }); });

// ------------------------------------------------------------------------------------------ the value layer
// Native's public flat API over the reader's tree. Text is held as a "binary string" (one char per byte), so a label or a
// value that is not UTF-8, or holds a NUL, compares by its exact bytes as native does; it is decoded only for output.
const api = require('./api');
const R = require('./reader');
const formats = require('./formats');
const { load, loadFragment } = require('./load');
const { latin1, utf8Binary, fromBinary } = require('./bytes');
const { CATEGORY, NAMES, MESSAGES } = require('./errors');

const { Ctx, ROOT, unescape, plainNumber } = api.internals;
const enc = new TextEncoder();
const dec = new TextDecoder('utf-8', { ignoreBOM: true });

// anvil_value_type
const V_NULL = 0, V_BOOL = 1, V_NUMERIC = 2, V_STRING = 3, V_BLOB = 4, V_BARE = 5, V_ARRAY = 6, V_TUPLE = 7, V_OBJECT = 8;
const VTYPE = new Uint8Array(11);
VTYPE[R.T_BOOL] = V_BOOL; VTYPE[R.T_NUMERIC] = V_NUMERIC; VTYPE[R.T_STRING] = V_STRING; VTYPE[R.T_BLOB] = V_BLOB;
VTYPE[R.T_BARE] = V_BARE; VTYPE[R.T_ARRAY] = V_ARRAY; VTYPE[R.T_TUPLE] = V_TUPLE; VTYPE[R.T_OBJECT] = V_OBJECT;

// A value node as the public API sees it: a resolved reference reads as its target, an unresolved one as null (-1).
const val = (c, v) => (v >= 0 && c.T[v] === R.T_VARREF ? c.T[v + 5] : v);
const vtype = (c, v) => (v < 0 ? V_NULL : VTYPE[c.T[v]]);

// anvil_value_get_bytes: the raw span of a scalar (a string's escapes are not resolved, a blob's content is without its
// backticks); nothing for a collection.
const rawBytes = (function rawBytes(c, v) {
   if (v < 0) return '';
   const t = c.T[v];
   if (t === R.T_ARRAY || t === R.T_TUPLE || t === R.T_OBJECT || t === R.T_NONE) return '';
   return latin1(c.buf(v), c.T[v + 1], c.T[v + 2]);
});

// anvil_value_get_text: a string with its escapes resolved, everything else its raw span (a collection's included).
const textOf = (function textOf(c, v) {
   if (v < 0) return '';
   const T = c.T, s = latin1(c.buf(v), T[v + 1], T[v + 2]);
   return T[v] === R.T_STRING && T[v + 3] ? unescape(s) : s;
});

const toUtf8 = (bin) => {
   for (let i = 0; i < bin.length; i++) if (bin.charCodeAt(i) > 127) return dec.decode(fromBinary(bin));
   return bin;
};

// The text of a value that NAMES something (a type, a flag): null, and nul = true, if it holds a NUL byte.
const identOf = (function identOf(c, v) {
   const t = textOf(c, v);
   return t.indexOf('\0') >= 0 ? { text: null, nul: true } : { text: t, nul: false };
});

// The statements of an object value: its own, then those it inherited.
const stmtsOf = (function stmtsOf(c, v) {
   const out = [];
   if (v < 0 || c.T[v] !== R.T_OBJECT) return out;
   for (let s = c.T[v + 5]; s >= 0; s = c.T[s + 6]) out.push(s);
   const extra = c.inh.get(v);
   if (extra) for (const s of extra) out.push(s);
   return out;
});

// Statement names repeat (the rows of a table all carry the same ones), so a name is made once and found again by its bytes.
const NAMES_SEEN = new Map();
const stmtName = (c, s) => {
   const buf = c.buf(s), a = c.T[s + 1], e = c.T[s + 2];
   let h = 0x811c9dc5 ^ (e - a);
   for (let i = a; i < e; i++) h = Math.imul(h ^ buf[i], 0x01000193);
   const seen = NAMES_SEEN.get(h);
   if (seen !== undefined && seen.length === e - a) {
      let i = 0;
      while (i < seen.length && seen.charCodeAt(i) === buf[a + i]) i++;
      if (i === seen.length) return seen;
   }
   const name = latin1(buf, a, e);
   if (NAMES_SEEN.size < 4096) NAMES_SEEN.set(h, name);
   return name;
};
const stmtValue = (c, s) => val(c, c.T[s + 5]);

const elementsOf = (function elementsOf(c, v) {
   const out = [];
   const t = v < 0 ? 0 : c.T[v];
   if (t !== R.T_ARRAY && t !== R.T_TUPLE) return out;
   for (let e = c.T[v + 5]; e >= 0; e = c.T[e + 6]) out.push(val(c, e));
   return out;
});

// ---- numbers (anvil_value_get_numeric and internal/numeric_bound.h)
const I64_MIN = -(2n ** 63n), I64_MAX = 2n ** 63n - 1n;
// { integral, n } with n a Number (a BigInt for an integer beyond 2^53), or null when it overflows or is not a number
const numRead = (function numRead(c, v) {
   if (v < 0 || c.T[v] !== R.T_NUMERIC) return null;
   const T = c.T;
   const float = T[v + 3] === 1;
   const n = plainNumber(c.buf(v), T[v + 1], T[v + 2], float);
   if (float) return Number.isFinite(n) ? { integral: false, n } : null;
   if (typeof n === 'bigint' && (n < I64_MIN || n > I64_MAX)) return null;
   return { integral: true, n: n === 0 ? 0 : n };
});

// a size or an item count: an integral, non-negative number that fits
const readSize = (function readSize(c, v) {
   const b = numRead(c, v);
   return b !== null && b.integral && b.n >= 0 ? b.n : null;
});

// the JS Number the binding reports for a bound
const boundNumber = (b) => (typeof b.n === 'bigint' ? Number(b.n) : b.n);

// ---- loading
// a failure native has no code for (a document without @[schema] or @[types]): the addon's message, code 0, no name
const setError = (message) => api.internals.setLastError({ message, line: 0, column: 0, code: 0, name: null });

// The result of anvil_load: always a document, never null. `res` is the load (null when the file could not be read), `root` the root
// document as far as the load got (a failed load keeps what it read: the header, the includes that resolved, the statements
// parsed before the error), `category` the failing phase's CATEGORY (0 when it loaded) and `error` its description.
const ioFailure = (function ioFailure(code) {
   return { res: null, c: null, root: null, ok: false, category: CATEGORY.IO, error: { message: MESSAGES[code], line: 0, column: 0, code, name: NAMES[code] } };
});
const finishLoad = (function finishLoad(res) {
   const nd = { res, c: new Ctx(res), root: res.docs[0], ok: res.ok, category: res.ok ? CATEGORY.OK : res.category, error: null };
   if (!res.ok) nd.error = api.errorInfo(res.err);
   return nd;
});
// anvil_load(path): the bytes come from io.readFile(binary path). A failure is native's (BR-2610-anvl-io-001): an empty path 1003, a
// directory or an unreadable file 1001, a missing file 1002 (io.readFailure may say which; the default is a missing file).
const readDocument = (function readDocument(path, io) {
   if (path === '') return ioFailure(1003);
   if (io && io.isDirectory && io.isDirectory(path)) return ioFailure(1001);
   const bytes = io ? io.readFile(path) : null;
   if (!bytes) return ioFailure(io && io.readFailure ? io.readFailure(path) : 1002);
   return finishLoad(load(bytes, { path, io }));
});
// anvil_load_buffer(text)
const readBuffer = (bytes, io) => finishLoad(load(bytes, { path: null, io }));

// For the public loaders: null (lastError set) when the load failed, unless `tolerate` keeps the document (a name defined by two
// included @[types] documents collides in its namespace, and the registry reports that as a NAME_COLLISION diagnostic).
const loadDoc = (function loadDoc(source, isFile, tolerate) {
   api.internals.setLastError(null);
   const io = api.internals.io();
   const nd = isFile ? readDocument(utf8Binary(source), io) : readBuffer(enc.encode(source), io);
   if (nd.ok || tolerate) return nd;
   api.internals.setLastError(nd.error);
   return null;
});

// does a document carry the module attribute `key`
const hasModuleAttr = (function hasModuleAttr(c, doc, key) {
   const A = c.A;
   for (let k = 0, a = doc.attrFirst; k < doc.attrCount; k++, a += 4) {
      if (latin1(doc.buf, A[a], A[a + 1]) === key) return true;
   }
   return false;
});

// the top-level statements of one document, in order
const topStmts = (function topStmts(c, doc) {
   const out = [];
   for (let s = doc.firstStmt; s >= 0; s = c.T[s + 6]) out.push(s);
   return out;
});

// ------------------------------------------------------------------------------------------ the type registry
const KIND_BY_NAME = new Map([
   ['Numeric', TypeKind.NUMERIC], ['String', TypeKind.STRING], ['Bool', TypeKind.BOOL], ['Object', TypeKind.OBJECT],
   ['Tuple', TypeKind.TUPLE], ['Array', TypeKind.ARRAY], ['enum', TypeKind.ENUM], ['Blob', TypeKind.BLOB],
]);
const parseTypeKind = (text) => KIND_BY_NAME.get(text) || TypeKind.UNKNOWN;

const newDef = (function newDef(name, kind) {
   return {
      name, kind, size: null, min: null, max: null, values: null, source: null, format: null, tag: null,
      integerDeclared: false, integer: false, nullableDeclared: false, nullable: false, fields: null,
   };
});
// the six native primitives, enum and Blob: always available, with no constraints of their own
const NATIVE_DEFS = new Map();
for (const [name, kind] of KIND_BY_NAME) NATIVE_DEFS.set(name, newDef(name, kind));

// An enum's `values := [ ... ]`: each element's text (a bare label and a quoted one read the same). null if it is not an array.
const readValuesList = (function readValuesList(c, v) {
   if (vtype(c, v) !== V_ARRAY) return null;
   return elementsOf(c, v).map((e) => textOf(c, e));
});

// Reads one type definition's object value in a single pass. `issues` collects what the definition itself can't carry.
const readTypeFields = (function readTypeFields(c, obj, def) {
   const issues = {
      typeDeclared: false, typeText: null, badSize: false, badMin: false, badMax: false, badValues: false, badFields: false,
      badNullable: false, badInteger: false, badTag: false, nulType: false, nulFormat: false, nulTag: false, nulNullable: false,
      nulInteger: false, badFormatName: null,
   };
   for (const s of stmtsOf(c, obj)) {
      const fname = stmtName(c, s), fval = stmtValue(c, s);
      if (fname === 'type') {
         const id = identOf(c, fval);
         issues.typeDeclared = true;
         issues.nulType = issues.nulType || id.nul;
         if (id.text !== null) { def.kind = parseTypeKind(id.text); issues.typeText = id.text; }
      } else if (fname === 'size') {
         def.size = readSize(c, fval);
         issues.badSize = def.size === null;
      } else if (fname === 'min') {
         def.min = numRead(c, fval);
         issues.badMin = def.min === null;
      } else if (fname === 'max') {
         def.max = numRead(c, fval);
         issues.badMax = def.max === null;
      } else if (fname === 'values') {
         def.values = readValuesList(c, fval);
         issues.badValues = def.values === null;
      } else if (fname === 'format') {
         const ft = vtype(c, fval);
         const id = ft === V_BARE || ft === V_STRING ? identOf(c, fval) : { text: null, nul: false };
         issues.nulFormat = issues.nulFormat || id.nul;
         if (id.text !== null && formats.known(id.text)) def.format = id.text;
         else issues.badFormatName = id.text !== null ? id.text : '';
      } else if (fname === 'tag') {
         const tt = vtype(c, fval);
         const id = tt === V_BARE || tt === V_STRING ? identOf(c, fval) : { text: null, nul: false };
         if (id.text !== null) def.tag = id.text;
         else { issues.badTag = true; issues.nulTag = issues.nulTag || id.nul; }
      } else if (fname === 'integer' || fname === 'nullable') {
         const id = identOf(c, fval);
         const flag = id.text === 'true' ? true : id.text === 'false' ? false : null;
         if (flag !== null) { def[fname + 'Declared'] = true; def[fname] = flag; }
         else if (fname === 'integer') { issues.badInteger = true; issues.nulInteger = issues.nulInteger || id.nul; }
         else { issues.badNullable = true; issues.nulNullable = issues.nulNullable || id.nul; }
      } else if (fname === 'fields') {
         if (vtype(c, fval) === V_OBJECT) def.fields = c.buf(fval).slice(c.T[fval + 1], c.T[fval + 2]); // the source text, re-read when a rule inherits it
         else issues.badFields = true;
      }
   }
   return issues;
});

const nulNote = (flag) => (flag ? ' (the value contains a NUL byte)' : '');

const addTypeDiag = (function addTypeDiag(reg, category, name, source, message) {
   reg.diagnostics.push({ category, name, source, message });
});

const collectTypeDefs = (function collectTypeDefs(c, doc, reg) {
   const src = doc.path;
   for (const s of topStmts(c, doc)) {
      const v = stmtValue(c, s);
      if (vtype(c, v) !== V_OBJECT) continue; // not a type-definition shape at all
      const def = newDef(stmtName(c, s), TypeKind.UNKNOWN);
      def.source = src;
      const issues = readTypeFields(c, v, def);
      const n = def.name;
      if (def.kind === TypeKind.UNKNOWN) {
         addTypeDiag(reg, TypeDiagnostic.UNKNOWN_BASE_TYPE, n, src, issues.typeDeclared
            ? `type '${n}' has an unrecognized base type 'type := ${issues.typeText === null ? '' : issues.typeText}'${nulNote(issues.nulType)}`
            : `type '${n}' declares no 'type :=' base type`);
         continue; // not registered
      }
      const malformed = (message) => addTypeDiag(reg, TypeDiagnostic.MALFORMED_CONSTRAINT, n, src, message);
      if (issues.badSize) malformed(`type '${n}': 'size' is not a non-negative integer; treated as not declared`);
      if (issues.badMin) malformed(`type '${n}': 'min' is not a valid number; treated as not declared`);
      if (issues.badMax) malformed(`type '${n}': 'max' is not a valid number; treated as not declared`);
      if (issues.badFormatName !== null) {
         malformed(`type '${n}': unknown format '${issues.badFormatName}' (known: iso8601_date, iso8601_datetime, uuid)${nulNote(issues.nulFormat)}; treated as not declared`);
      }
      if (issues.badTag) malformed(`type '${n}': 'tag' must be an identifier or string${nulNote(issues.nulTag)}; treated as not declared`);
      if (issues.badInteger) malformed(`type '${n}': 'integer' must be true or false${nulNote(issues.nulInteger)}; treated as not declared`);
      if (issues.badNullable) malformed(`type '${n}': 'nullable' must be true or false${nulNote(issues.nulNullable)}; treated as not declared`);
      if (issues.badFields) malformed(`type '${n}': 'fields' must be an object of field rules; treated as not declared`);
      if (issues.badValues) addTypeDiag(reg, TypeDiagnostic.MALFORMED_ENUM_VALUES, n, src, `type '${n}': 'values' must be an array of labels`);
      const prior = reg.byName.get(n);
      if (prior !== undefined) {
         const earlier = prior.source === null ? '' : prior.source;
         addTypeDiag(reg, TypeDiagnostic.NAME_COLLISION, n, src,
            `type '${n}' is defined in both '${earlier}' and '${src}'; the one in '${src}' is used`);
      }
      reg.byName.set(n, def); // last write wins
      reg.all.push(def);
   }
});

const newRegistry = (function newRegistry() { return { byName: new Map(), all: [], diagnostics: [] }; });

// Depth-first in include order, deeper documents first, each document at most once (by path); a document without @[types] is
// walked through and contributes nothing.
const walkIncludes = (function walkIncludes(c, doc, reg, visited) {
   for (const inc of doc.includes) {
      if (inc.resolved < 0) continue;
      const included = c.docs[inc.resolved];
      if (visited.has(included.path)) continue;
      visited.add(included.path);
      walkIncludes(c, included, reg, visited);
      if (hasModuleAttr(c, included, 'types')) collectTypeDefs(c, included, reg);
   }
});

// anvil_type_registry_load: the document's own definitions; null unless it carries @[types]
const registryLoad = (function registryLoad(nd) {
   if (nd.root === null || !hasModuleAttr(nd.c, nd.root, 'types')) return null;
   const reg = newRegistry();
   collectTypeDefs(nd.c, nd.root, reg);
   return reg;
});

// anvil_type_registry_load_from_includes: the include graph's definitions; always a registry (empty for a document that read nothing)
const registryFromIncludes = (function registryFromIncludes(nd) {
   const reg = newRegistry();
   if (nd.root !== null) {
      walkIncludes(nd.c, nd.root, reg, new Set([nd.root.path]));
      // the root's own @[types] come last, as the closest definitions: they override the included ones, reported as a NAME_COLLISION
      // (BR-2610-anvl-schema-005)
      if (hasModuleAttr(nd.c, nd.root, 'types')) collectTypeDefs(nd.c, nd.root, reg);
   }
   return reg;
});

// the snapshot a TypeDef is made from
const TypeDef = (function TypeDef(def) {
   this.kind = def.kind;
   this.size = def.size === null ? undefined : Number(def.size);
   this.min = def.min === null ? undefined : boundNumber(def.min);
   this.max = def.max === null ? undefined : boundNumber(def.max);
   this.format = def.format === null ? undefined : def.format;
   this.values = def.kind === TypeKind.ENUM || (def.values !== null && def.values.length > 0) ? (def.values || []).map(toUtf8) : undefined;
   Object.freeze(this);
});

const TypeRegistry = (function TypeRegistry(reg, loadError) {
   this._reg = reg;
   this._loadError = loadError;
});

defineMethod(TypeRegistry, '_from', (function _from(source, isFile, fromIncludes) {
   const d = loadDoc(source, isFile, fromIncludes);
   if (d === null) return null;
   const reg = fromIncludes ? registryFromIncludes(d) : registryLoad(d);
   if (reg === null) {
      setError('document does not carry @[types]');
      return null;
   }
   return new TypeRegistry(reg, d.error);
}));

defineMethod(TypeRegistry, 'load', (function load(text) { return TypeRegistry._from(text, false, false); }));
defineMethod(TypeRegistry, 'loadFile', (function loadFile(path) { return TypeRegistry._from(path, true, false); }));

// The merged @[types] definitions of a document's include graph (the `types.X` namespace). Includes resolve against a file
// path, so fromIncludesFile() is the form that finds any.
defineMethod(TypeRegistry, 'fromIncludes', (function fromIncludes(text) { return TypeRegistry._from(text, false, true); }));
defineMethod(TypeRegistry, 'fromIncludesFile', (function fromIncludesFile(path) { return TypeRegistry._from(path, true, true); }));

// fromIncludes() builds a registry even when the consumer document itself loaded with an error (a name defined by two
// included @[types] documents collides in its namespace, which the registry reports as a NAME_COLLISION diagnostic). That
// error is kept here as { message, line, column }, or null when the document loaded cleanly.
Object.defineProperty(TypeRegistry.prototype, 'loadError', { get: (function loadError() {
   this._live();
   const e = this._loadError;
   return e === null ? null : { message: e.message, line: e.line, column: e.column };
}), configurable: true });

// What the registry reported while loading; [{ category, name, source, message }].
Object.defineProperty(TypeRegistry.prototype, 'diagnostics', { get: (function diagnostics() { return this._live().diagnostics.map((d) => ({ category: d.category, name: toUtf8(d.name), source: toUtf8(d.source), message: toUtf8(d.message) })); }), configurable: true });

defineMethod(TypeRegistry.prototype, '_live', (function _live() {
   if (this._reg === null) throw new Error('TypeRegistry has been disposed');
   return this._reg;
}));

// The registry's own definition of `name`, or null.
defineMethod(TypeRegistry.prototype, 'find', (function find(name) {
   const def = this._live().byName.get(name);
   return def === undefined ? null : new TypeDef(def);
}));

// Like find(), but also answers for the built-in types (Numeric, String, ...).
defineMethod(TypeRegistry.prototype, 'resolve', (function resolve(name) {
   const reg = this._live();
   const def = NATIVE_DEFS.get(name) || reg.byName.get(name);
   return def === undefined ? null : new TypeDef(def);
}));

defineMethod(TypeRegistry.prototype, 'dispose', (function dispose() { this._reg = null; }));

// ------------------------------------------------------------------------------------------ AnvilSchema
const newRule = (function newRule(name) {
   return {
      name, hasKind: false, kind: TypeKind.UNKNOWN, typeUnresolved: false, required: false, typeName: null, extras: [],
      format: null, tag: null, integer: false, integerDeclared: false, nullable: false, nullableDeclared: false,
      size: null, min: null, max: null, values: null, hasFields: false, children: null, childByName: null, items: null,
      minItems: null, maxItems: null, snap: null, idx: 0,
   };
});

const addSchemaDiag = (function addSchemaDiag(schema, category, typeCategory, field, message) {
   schema.diagnostics.push({ category, typeCategory, field, message });
});

// `type :=` text names either a bare native kind or a types.X custom type; the registry stores bare names
const stripTypesPrefix = (text) => (text.startsWith('types.') ? text.slice(6) : text);
const resolveType = (reg, name) => NATIVE_DEFS.get(name) || reg.byName.get(name) || null;

const joinPath = (prefix, name) => (prefix === '' ? name : prefix + '.' + name);

// The source a value is read back from: a collection's raw span; a string or blob re-wrapped from its exact bytes.
const valueSourceBytes = (function valueSourceBytes(c, v) {
   const t = vtype(c, v);
   if (t !== V_STRING && t !== V_BLOB) return v < 0 ? new Uint8Array(0) : c.buf(v).slice(c.T[v + 1], c.T[v + 2]);
   const T = c.T;
   const body = c.buf(v).subarray(T[v + 1], T[v + 2]);
   const tag = t === V_BLOB && T[v + 3] >= 0 ? c.buf(v).subarray(T[v + 3], T[v + 4]) : null;
   const open = t === V_BLOB ? 96 : 34;
   const out = new Uint8Array(body.length + (tag ? tag.length + 1 : 0) + 2);
   let at = 0;
   if (tag) { out[at++] = 64; out.set(tag, at); at += tag.length; }
   out[at++] = open;
   out.set(body, at); at += body.length;
   out[at] = open;
   return out;
});

// A rule key the schema doesn't consume: kept as a value of its own (read back from its source), so it outlives the document.
const addExtra = (function addExtra(c, rule, name, v) {
   const res = loadFragment(valueSourceBytes(c, v));
   const fc = res.ok ? new Ctx(res) : null;
   const value = res.ok ? new api.AnvlNode(fc, res.value) : new api.AnvlNode(c, api.internals.NONE);
   rule.extras.push({ name, value, c: fc, v: res.ok ? res.value : -1 });
});

const buildChildren = (function buildChildren(c, fieldsObj, types, rule, schema, path, stack) {
   rule.hasFields = true;
   if (rule.children === null) { rule.children = []; rule.childByName = new Map(); }
   for (const s of stmtsOf(c, fieldsObj)) {
      const name = stmtName(c, s), v = stmtValue(c, s);
      const childPath = joinPath(path, name);
      if (vtype(c, v) !== V_OBJECT) {
         addSchemaDiag(schema, SchemaDiagnostic.RULE_NOT_OBJECT, 0, childPath, `'${childPath}' is not a field rule (expected a '{ ... }' object); skipped`);
         continue;
      }
      const child = newRule(name);
      buildRule(c, v, types, child, schema, childPath, stack);
      child.idx = rule.children.length;
      rule.children.push(child);
      rule.childByName.set(name, child);
   }
});

// A field referencing an Object type that declares `fields` inherits that shape, unless it declared its own. The registry keeps
// the nested rules as source text, so the text is read again here as a value of its own.
const expandTypeFields = (function expandTypeFields(def, types, rule, schema, path, stack) {
   if (def.fields === null) return;
   for (let f = stack; f !== null; f = f.up) {
      if (f.def === def) {
         addSchemaDiag(schema, SchemaDiagnostic.SELF_REFERENCE, 0, path, `field '${path}': its type's 'fields' refer back to the type itself; not expanded`);
         return;
      }
   }
   const res = loadFragment(def.fields);
   if (!res.ok) return;
   const fc = new Ctx(res);
   if (vtype(fc, res.value) === V_OBJECT) buildChildren(fc, res.value, types, rule, schema, path, { def, up: stack });
});

const buildRule = (function buildRule(c, obj, types, rule, schema, path, stack) {
   let resolved = null;
   const diag = (cat, msg) => addSchemaDiag(schema, cat, 0, path, msg);
   const malformed = (msg) => diag(SchemaDiagnostic.MALFORMED_CONSTRAINT, msg);
   // First pass: exactly what the field declares inline. Inheritance below fills in only what this pass left unset.
   for (const s of stmtsOf(c, obj)) {
      const fname = stmtName(c, s), fval = stmtValue(c, s);
      if (fname === 'type') {
         const id = identOf(c, fval);
         rule.typeName = id.text;
         resolved = id.text !== null ? resolveType(types, stripTypesPrefix(id.text)) : null;
         rule.typeUnresolved = resolved === null;
         if (resolved === null) diag(SchemaDiagnostic.UNKNOWN_TYPE, `field '${path}': type '${id.text === null ? '' : id.text}' is neither a native type nor a known types.X${nulNote(id.nul)}`);
         else { rule.hasKind = true; rule.kind = resolved.kind; }
      } else if (fname === 'required') {
         const id = identOf(c, fval);
         rule.required = id.text === 'true';
         if (id.text !== 'true' && id.text !== 'false') malformed(`field '${path}': 'required' must be true or false${nulNote(id.nul)}`);
      } else if (fname === 'format') {
         const ft = vtype(c, fval);
         const id = ft === V_BARE || ft === V_STRING ? identOf(c, fval) : { text: null, nul: false };
         if (id.text !== null && formats.known(id.text)) rule.format = id.text;
         else diag(SchemaDiagnostic.UNKNOWN_FORMAT, `field '${path}': unknown format '${id.text === null ? '' : id.text}' (known: iso8601_date, iso8601_datetime, uuid)${nulNote(id.nul)}; treated as not declared`);
      } else if (fname === 'tag') {
         const tt = vtype(c, fval);
         const id = tt === V_BARE || tt === V_STRING ? identOf(c, fval) : { text: null, nul: false };
         if (id.text !== null) rule.tag = id.text;
         else malformed(`field '${path}': 'tag' must be an identifier or string${nulNote(id.nul)}; treated as not declared`);
      } else if (fname === 'integer' || fname === 'nullable') {
         const id = identOf(c, fval);
         if (id.text === 'true' || id.text === 'false') { rule[fname + 'Declared'] = true; rule[fname] = id.text === 'true'; }
         else malformed(`field '${path}': '${fname}' must be true or false${nulNote(id.nul)}; treated as false`);
      } else if (fname === 'size') {
         rule.size = readSize(c, fval);
         if (rule.size === null) malformed(`field '${path}': 'size' is not a non-negative integer; treated as not declared`);
      } else if (fname === 'min' || fname === 'max') {
         rule[fname] = numRead(c, fval);
         if (rule[fname] === null) malformed(`field '${path}': '${fname}' is not a valid number; treated as not declared`);
      } else if (fname === 'values') {
         rule.values = readValuesList(c, fval);
         if (rule.values === null) malformed(`field '${path}': 'values' must be an array of labels`);
      } else if (fname === 'min_items' || fname === 'max_items') {
         const key = fname === 'min_items' ? 'minItems' : 'maxItems';
         rule[key] = readSize(c, fval);
         if (rule[key] === null) malformed(`field '${path}': '${fname}' is not a non-negative integer; treated as not declared`);
      } else if (fname === 'fields') {
         if (vtype(c, fval) === V_OBJECT) buildChildren(c, fval, types, rule, schema, path, stack);
         else malformed(`field '${path}': 'fields' must be an object of field rules`);
      } else if (fname === 'items') {
         if (vtype(c, fval) === V_OBJECT) {
            rule.items = newRule(''); // a repeated `items` replaces the earlier one
            buildRule(c, fval, types, rule.items, schema, path + '[]', stack);
         } else {
            malformed(`field '${path}': 'items' must be a field rule object`);
         }
      } else {
         addExtra(c, rule, fname, fval); // not ours: passed on to the consumer, never diagnosed
      }
   }

   // Constraint inheritance: what the field didn't declare inline falls back to its resolved type's own constraint.
   if (resolved !== null) {
      if (rule.size === null) rule.size = resolved.size;
      if (rule.min === null) rule.min = resolved.min;
      if (rule.max === null) rule.max = resolved.max;
      if (rule.values === null && resolved.values !== null && resolved.values.length > 0) rule.values = resolved.values.slice();
      if (rule.format === null) rule.format = resolved.format;
      if (rule.tag === null) rule.tag = resolved.tag;
      if (!rule.integerDeclared && resolved.integerDeclared) rule.integer = resolved.integer;
      if (!rule.nullableDeclared && resolved.nullableDeclared) rule.nullable = resolved.nullable;
      if (!rule.hasFields) expandTypeFields(resolved, types, rule, schema, path, stack);
   }

   // Effective bounds that nothing can satisfy.
   if (rule.min !== null && rule.max !== null && rule.min.n > rule.max.n) {
      diag(SchemaDiagnostic.CONFLICTING_CONSTRAINTS, `field '${path}': 'min' is greater than 'max'; no value can satisfy it`);
   }
   if (rule.minItems !== null && rule.maxItems !== null && rule.minItems > rule.maxItems) {
      diag(SchemaDiagnostic.CONFLICTING_CONSTRAINTS, `field '${path}': 'min_items' is greater than 'max_items'; no array can satisfy it`);
   }
});

// One schema rule, as a snapshot. Properties the rule doesn't declare are `undefined`, never a default.
const SchemaField = (function SchemaField(r) {
   this.name = toUtf8(r.name);
   this.kind = r.hasKind ? r.kind : TypeKind.UNKNOWN;
   this.typeName = r.typeName === null ? '' : toUtf8(r.typeName);
   this.required = r.required;
   this.nullable = r.nullable;
   this.integer = r.integer;
   this.size = r.size === null ? undefined : Number(r.size);
   this.min = r.min === null ? undefined : boundNumber(r.min);
   this.max = r.max === null ? undefined : boundNumber(r.max);
   this.minItems = r.minItems === null ? undefined : Number(r.minItems);
   this.maxItems = r.maxItems === null ? undefined : Number(r.maxItems);
   this.values = this.kind === TypeKind.ENUM || (r.values !== null && r.values.length > 0) ? (r.values || []).map(toUtf8) : undefined;
   this.format = r.format === null ? undefined : r.format;
   this.tag = r.tag === null ? undefined : toUtf8(r.tag);
   this.nested = Object.freeze(r.children === null ? [] : r.children.map(snapshot));
   this.items = r.items === null ? undefined : snapshot(r.items);
   this.extras = Object.freeze(r.extras.map((e) => Object.freeze({ name: toUtf8(e.name), value: e.value })));
   Object.freeze(this);
});

defineMethod(SchemaField.prototype, 'findNested', (function findNested(name) {
   return this.nested.find((f) => f.name === name) || null;
}));
const snapshot = (r) => r.snap || (r.snap = new SchemaField(r));

// a value fragment read from text: { c, v }, or null (lastError set)
const loadValue = (function loadValue(text) {
   api.internals.setLastError(null);
   const res = loadFragment(enc.encode(text));
   if (!res.ok) { api.internals.setLastError(api.errorInfo(res.err)); return null; }
   return { c: new Ctx(res), v: res.value };
});

// ---- validation (schema.c: validate_members, check_value)
// a violation's field path is built only when there is a violation: `leaf` is a name, or an index for an array element
const pathFor = (parent, leaf) => (typeof leaf === 'number' ? `${parent}[${leaf}]` : joinPath(parent, leaf));
const viol = (out, parent, leaf, category, message) => { out.push({ category, field: pathFor(parent, leaf), message }); };

// is the value a whole number (integer := true is value-based: 2.0 and 1e+3 pass)
const isWhole = (function isWhole(c, v) {
   const n = numRead(c, v);
   // a digits-only literal is whole even past int64; a decimal or exponent literal beyond double range (1e400) is no finite value, so not
   // an integer (BR-2610-anvl-schema-004)
   if (n === null) return c.T[v + 3] !== 1;
   if (n.integral) return true;
   const d = n.n;
   if (d >= 9223372036854775808 || d <= -9223372036854775808) return true;
   return Number.isInteger(d);
});

// the data value against a bound: <0, 0, >0 (exact; a number beyond int64 compares by its sign)
const compareBound = (function compareBound(c, v, bound) {
   const n = numRead(c, v);
   if (n === null) return textOf(c, v).charCodeAt(0) === 45 ? -1 : 1;
   return n.n < bound.n ? -1 : n.n > bound.n ? 1 : 0;
});

const kindMatches = (function kindMatches(expected, actual) {
   switch (expected) {
   case TypeKind.NUMERIC: return actual === V_NUMERIC;
   case TypeKind.STRING: return actual === V_STRING || actual === V_BARE || actual === V_BLOB; // textual content, whatever the spelling
   case TypeKind.ENUM: return actual === V_STRING || actual === V_BARE;
   case TypeKind.BLOB: return actual === V_BLOB;
   case TypeKind.BOOL: return actual === V_BOOL;
   case TypeKind.OBJECT: return actual === V_OBJECT;
   case TypeKind.TUPLE: return actual === V_TUPLE;
   case TypeKind.ARRAY: return actual === V_ARRAY;
   default: return true;
   }
});

const validateMembers = (function validateMembers(c, rules, rulesByName, stmts, prefix, vo, out) {
   const nr = rules.length;
   const first = new Array(nr); // the first data statement of each rule
   let unknown = null;
   for (let k = 0; k < stmts.length; k++) {
      const name = stmtName(c, stmts[k]);
      const r = rulesByName === null ? undefined : rulesByName.get(name);
      if (r === undefined) { if (!vo.allowUnknown) (unknown || (unknown = [])).push(name); } else if (first[r.idx] === undefined) first[r.idx] = stmts[k];
   }
   for (let i = 0; i < nr; i++) {
      const rule = rules[i];
      let found = first[i];
      if (found === undefined && rulesByName !== null) { // two rules of one name (a duplicate the resolver reported): both see the statement of the name
         const same = rulesByName.get(rule.name);
         if (same !== rule && same !== undefined) found = first[same.idx];
      }
      if (found === undefined) {
         if (rule.required && !vo.skipRequired) viol(out, prefix, rule.name, SchemaViolation.REQUIRED, 'required field is missing');
      } else {
         checkValue(c, rule, prefix, rule.name, stmtValue(c, found), vo, out);
      }
   }
   // every member not declared at this level is a violation of its own
   if (unknown !== null) for (const name of unknown) viol(out, prefix, name, SchemaViolation.UNKNOWN_FIELD, 'field is not declared in the schema');
});

const checkValue = (function checkValue(c, rule, parent, leaf, v, vo, out) {
   const actual = vtype(c, v);

   // a rule whose declared type never resolved judges nothing, so it accepts nothing (an explicit null included)
   if (rule.typeUnresolved) {
      viol(out, parent, leaf, SchemaViolation.UNRESOLVED_TYPE, "the rule's declared type is unresolved; the value cannot be validated");
      return;
   }
   // an explicit null: legal iff the rule says so, and then nothing else about it is evaluated; an untyped rule has no type to violate
   if (actual === V_NULL) {
      if (rule.nullable) return;
      if (rule.hasKind) { viol(out, parent, leaf, SchemaViolation.TYPE_MISMATCH, 'field is not nullable'); return; }
   }
   if (rule.hasKind && !kindMatches(rule.kind, actual)) {
      viol(out, parent, leaf, SchemaViolation.TYPE_MISMATCH, 'field value does not match the declared type');
      return; // one violation, not a pile of them
   }
   if (rule.size !== null && v >= 0) {
      // a blob's payload, else the text's bytes: the span, unless a string's escapes are resolved (then it is shorter)
      const len = actual === V_STRING && c.T[v + 3] ? textOf(c, v).length : c.T[v + 2] - c.T[v + 1];
      if (len > rule.size) viol(out, parent, leaf, SchemaViolation.SIZE, 'field value exceeds the declared size');
   }
   if (rule.format !== null && (actual === V_STRING || actual === V_BARE || actual === V_BLOB)) {
      const text = rawBytes(c, v);
      if (text.indexOf('\0') >= 0 || !formats.valid(rule.format, text)) viol(out, parent, leaf, SchemaViolation.FORMAT, 'value does not match the declared format');
   }
   if (rule.tag !== null && actual === V_BLOB) {
      const tag = c.T[v + 3] < 0 ? '' : latin1(c.buf(v), c.T[v + 3], c.T[v + 4]);
      if (tag !== rule.tag) viol(out, parent, leaf, SchemaViolation.TAG, 'blob tag does not match the required tag');
   }
   if (rule.integer && v >= 0 && actual === V_NUMERIC && !isWhole(c, v)) viol(out, parent, leaf, SchemaViolation.TYPE_MISMATCH, 'value must be an integer');
   if ((rule.min !== null || rule.max !== null) && v >= 0 && actual === V_NUMERIC) {
      if ((rule.min !== null && compareBound(c, v, rule.min) < 0) || (rule.max !== null && compareBound(c, v, rule.max) > 0)) {
         viol(out, parent, leaf, SchemaViolation.RANGE, 'field value is outside the declared min/max range');
      }
   }
   if (rule.values !== null && v >= 0) {
      const text = textOf(c, v);
      if (!rule.values.includes(text)) viol(out, parent, leaf, SchemaViolation.VALUES, 'field value is not one of the declared values');
   }

   // shape: an object's declared `fields`, an array's `items` and item count
   if (rule.hasFields && actual === V_OBJECT) {
      validateMembers(c, rule.children, rule.childByName, stmtsOf(c, v), pathFor(parent, leaf), vo, out);
   }
   if (actual === V_ARRAY) {
      const count = c.T[v + 7];
      if (rule.minItems !== null && count < rule.minItems) viol(out, parent, leaf, SchemaViolation.ITEM_COUNT, 'array has fewer items than min_items');
      if (rule.maxItems !== null && count > rule.maxItems) viol(out, parent, leaf, SchemaViolation.ITEM_COUNT, 'array has more items than max_items');
      if (rule.items !== null) {
         const els = elementsOf(c, v);
         const path = pathFor(parent, leaf);
         for (let i = 0; i < els.length; i++) checkValue(c, rule.items, path, i, els[i], vo, out);
      }
   }
});

// ---- the fast path for a flat record: `{ name := scalar; ... }` (what a server validates once per create and update).
// The text is read by a sticky regex into names and plain values, without a tree, and checked here exactly as checkValue
// checks the same values. It takes only what that reads identically: ASCII strings without escapes or controls, integers of up to
// 15 digits without leading zeros, decimals, true, false, null, names that are not keywords and not repeated; anything else
// (and any error) is the general path's. test/record-fast.test.js compares the two.
const FIELD = /([A-Za-z_][A-Za-z0-9_]*)[ \t\r\n]*:=[ \t]*(?:"([\x20\x21\x23-\x5b\x5d-\x7e]*)"|(-?(?:0|[1-9][0-9]*)\.[0-9]+)|(-?(?:0|[1-9][0-9]{0,14}))|(true|false|null))[ \t]*;[ \t\r\n]*/y;
const KEYWORD_NAMES = new Set(['include', 'import', 'vars', 'true', 'false', 'null']);
const recordFast = (function recordFast(model, text, opts) {
   if (recordFast.disabled || typeof text !== 'string') return null;
   const n = text.length;
   let i = 0, c;
   while (i < n && ((c = text.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   if (i >= n || text.charCodeAt(i) !== 123) return null;
   i++;
   while (i < n && ((c = text.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   const names = [], kinds = [], texts = [];
   for (;;) {
      if (i < n && text.charCodeAt(i) === 125) { i++; break; }
      FIELD.lastIndex = i;
      const m = FIELD.exec(text);
      if (m === null || names.length >= 64) return null;
      const name = m[1];
      if ((name.length >= 4 && name.length <= 7 && KEYWORD_NAMES.has(name)) || (names.length > 0 && names.indexOf(name) >= 0)) return null; // a keyword, or a repeated name (a parse error)
      names.push(name);
      if (m[2] !== undefined) { kinds.push(V_STRING); texts.push(m[2]); } else if (m[3] !== undefined) {
         if (!Number.isFinite(Number(m[3]))) return null;
         kinds.push(V_NUMERIC); texts.push(m[3]);
      } else if (m[4] !== undefined) { kinds.push(V_NUMERIC); texts.push(m[4]); } else {
         kinds.push(m[5] === 'null' ? V_NULL : V_BOOL); texts.push(m[5]);
      }
      i = FIELD.lastIndex;
   }
   while (i < n && ((c = text.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   if (i !== n || names.length === 0) return null;
   recordFast.hits++;
   const out = [];
   const skipRequired = opts !== null && opts.skipRequired, allowUnknown = opts !== null && opts.allowUnknown;
   const rules = model.fields, rulesByName = model.byName, nr = rules.length;
   const first = new Array(nr);
   let unknown = null;
   for (let k = 0; k < names.length; k++) {
      const r = rulesByName.get(names[k]);
      if (r === undefined) { if (!allowUnknown) (unknown || (unknown = [])).push(names[k]); } else first[r.idx] = k;
   }
   for (let r = 0; r < nr; r++) {
      const rule = rules[r];
      let k = first[r];
      if (k === undefined) {
         const same = rulesByName.get(rule.name);
         if (same !== rule && same !== undefined) k = first[same.idx];
      }
      if (k === undefined) {
         if (rule.required && !skipRequired) out.push({ category: SchemaViolation.REQUIRED, field: rule.name, message: 'required field is missing' });
      } else {
         checkScalar(rule, kinds[k], texts[k], out);
      }
   }
   if (unknown !== null) for (const name of unknown) out.push({ category: SchemaViolation.UNKNOWN_FIELD, field: name, message: 'field is not declared in the schema' });
   return out;
});
recordFast.hits = 0;
recordFast.disabled = false;

// Schema.load is the one-time cost, so the record path is warmed there: a record of the schema's own fields (a value of the kind each
// rule declares) is checked a few dozen times, which compiles the regex and takes the code through V8's first tiers before the
// first validateValue of a server. Nothing observable changes: the results are dropped and the hit counter is restored.
const WARM_VALUE = { 1: '1', 2: '"x"', 3: 'true', 7: '"x"' };
const warmRecordPath = (function warmRecordPath(model) {
   if (model.fields.length === 0 || recordFast.disabled) return;
   const rules = model.fields.slice(0, 12);
   const record = (wrong) => `{ ${rules.map((r, i) => `${r.name} := ${i === 0 && wrong ? (r.hasKind && r.kind === TypeKind.NUMERIC ? '"x"' : '1') : (r.hasKind && WARM_VALUE[r.kind]) || '"x"'};`).join(' ')} zz_unknown := null; }`;
   const texts = [record(false), record(true)];
   const hits = recordFast.hits;
   for (let i = 0; i < 200; i++) result(recordFast(model, texts[i & 1], i % 4 === 0 ? { skipRequired: true, allowUnknown: false } : null), plain);
   recordFast.hits = hits;
});

// checkValue for a scalar `actual` (string, number, true/false, null) given as its text: a string's content, else the token
const checkScalar = (function checkScalar(rule, actual, text, out) {
   const name = rule.name;
   if (rule.typeUnresolved) { out.push({ category: SchemaViolation.UNRESOLVED_TYPE, field: name, message: "the rule's declared type is unresolved; the value cannot be validated" }); return; }
   if (actual === V_NULL) {
      if (rule.nullable) return;
      if (rule.hasKind) { out.push({ category: SchemaViolation.TYPE_MISMATCH, field: name, message: 'field is not nullable' }); return; }
   }
   if (rule.hasKind && !kindMatches(rule.kind, actual)) { out.push({ category: SchemaViolation.TYPE_MISMATCH, field: name, message: 'field value does not match the declared type' }); return; }
   if (rule.size !== null && text.length > rule.size) out.push({ category: SchemaViolation.SIZE, field: name, message: 'field value exceeds the declared size' });
   if (rule.format !== null && actual === V_STRING && !formats.valid(rule.format, text)) out.push({ category: SchemaViolation.FORMAT, field: name, message: 'value does not match the declared format' });
   if (actual === V_NUMERIC) {
      const d = Number(text);
      if (rule.integer && !(Number.isInteger(d) || d >= 9223372036854775808 || d <= -9223372036854775808)) out.push({ category: SchemaViolation.TYPE_MISMATCH, field: name, message: 'value must be an integer' });
      if ((rule.min !== null && d < rule.min.n) || (rule.max !== null && d > rule.max.n)) out.push({ category: SchemaViolation.RANGE, field: name, message: 'field value is outside the declared min/max range' });
   }
   if (rule.values !== null && !rule.values.includes(text)) out.push({ category: SchemaViolation.VALUES, field: name, message: 'field value is not one of the declared values' });
});

const runValidation = (function runValidation(m, c, stmts, vo) {
   const out = [];
   validateMembers(c, m.fields, m.byName, stmts, '', vo, out);
   return out;
});

const result = (out, prefix) => ({
   valid: out.length === 0,
   violations: out.map((x) => ({ category: x.category, field: toUtf8(prefix(x.field)), message: x.message })),
});
const plain = (f) => f;

const noOpts = { skipRequired: false, allowUnknown: false };

// anvil_schema_validate_value: an object value's statements as if they were a document's top level
const validateObject = (function validateObject(m, c, v, vo) {
   if (vtype(c, v) !== V_OBJECT) return [{ category: SchemaViolation.TYPE_MISMATCH, field: '', message: 'value is not an object' }];
   return runValidation(m, c, stmtsOf(c, v), vo);
});

// anvil_schema_load: a ruleset from the document's top-level statements; null unless it carries @[schema]
const schemaLoad = (function schemaLoad(nd) {
   if (nd.root === null || !hasModuleAttr(nd.c, nd.root, 'schema')) return null;
   const model = { fields: [], byName: new Map(), diagnostics: [], violations: null };
   const types = registryFromIncludes(nd);
   for (const rd of types.diagnostics) {
      model.diagnostics.push({ category: SchemaDiagnostic.TYPE_REGISTRY, typeCategory: rd.category, field: rd.name, message: rd.message });
   }
   for (const s of topStmts(nd.c, nd.root)) {
      const v = stmtValue(nd.c, s);
      const name = stmtName(nd.c, s);
      if (vtype(nd.c, v) !== V_OBJECT) {
         addSchemaDiag(model, SchemaDiagnostic.RULE_NOT_OBJECT, 0, name, `'${name}' is not a field rule (expected a '{ ... }' object); skipped`);
         continue;
      }
      const rule = newRule(name);
      buildRule(nd.c, v, types, rule, model, name, null);
      rule.idx = model.fields.length;
      model.fields.push(rule);
      model.byName.set(name, rule);
   }
   return model;
});

// anvil_schema_validate: a data document's top-level statements; replaces the violations the schema holds
const schemaValidate = (function schemaValidate(model, nd) {
   if (model === null || nd === null) return false;
   model.violations = runValidation(model, nd.c, nd.root === null ? [] : topStmts(nd.c, nd.root), noOpts);
   return model.violations.length === 0;
});

// anvil_schema_validate_value: an object value; a null schema or value leaves the violations as they were
const schemaValidateValue = (function schemaValidateValue(model, frag, opts) {
   if (model === null || frag === null) return false;
   model.violations = validateObject(model, frag.c, frag.v, opts === null ? noOpts : opts);
   return model.violations.length === 0;
});

// the validate_value step on a text: the fast path when it applies (then the fragment loaded, as `doc=ok`), else null
const schemaValidateValueText = (function schemaValidateValueText(model, text, opts) {
   if (model === null) return null;
   const quick = recordFast(model, text, opts === null ? noOpts : opts);
   if (quick === null) return null;
   model.violations = quick;
   return quick.length === 0;
});

// anvil_parse_value_fragment: { ok, category, c, v } (v is -1 when the text did not parse)
const readFragment = (function readFragment(bytes) {
   const res = loadFragment(bytes);
   return res.ok ? { ok: true, category: CATEGORY.OK, c: new Ctx(res), v: res.value } : { ok: false, category: res.category, c: null, v: -1 };
});

const Schema = (function Schema(model) {
   this._m = model;
});

// The schema document is read, loaded and released inside one call; the Schema keeps its own copy of every rule. Returns
// null on failure; lastError() says why.
defineMethod(Schema, '_from', (function _from(source, isFile) {
   const d = loadDoc(source, isFile, false);
   if (d === null) return null;
   const model = schemaLoad(d);
   if (model === null) {
      setError('document does not carry @[schema]');
      return null;
   }
   warmRecordPath(model);
   return new Schema(model);
}));

// A document that carries @[schema].
defineMethod(Schema, 'load', (function load(text) { return Schema._from(text, false); }));

// Same, from a path. Use this form when the schema includes @[types] documents.
defineMethod(Schema, 'loadFile', (function loadFile(path) { return Schema._from(path, true); }));

defineMethod(Schema.prototype, '_live', (function _live() {
   if (this._m === null) throw new Error('Schema has been disposed');
   return this._m;
}));

// The schema's top-level rules, in declaration order: snapshots, readable after dispose().
Object.defineProperty(Schema.prototype, 'fields', { get: (function fields() { return this._live().fields.map(snapshot); }), configurable: true });

defineMethod(Schema.prototype, 'findField', (function findField(name) {
   const m = this._live();
   if (typeof name !== 'string') throw new TypeError('name must be a string');
   const r = m.byName.get(utf8Binary(name));
   return r === undefined ? null : snapshot(r);
}));

// Validates a data document (ANVL text) against the schema. Returns { valid, violations: [{ category, field, message }] }, where
// `category` is a SchemaViolation, or null if the data does not parse (see lastError()).
defineMethod(Schema.prototype, 'validate', (function validate(dataText) {
   const m = this._live();
   if (typeof dataText !== 'string') { api.internals.setLastError(null); return null; }
   const d = loadDoc(dataText, false, false);
   if (d === null) return null;
   return result(runValidation(m, d.c, topStmts(d.c, d.root), noOpts), plain);
}));

// Validates an object *value* given as ANVL text, e.g. `{ asset_id := 1; }`, the way a request body's `set` is checked.
// skipRequired gives patch semantics; allowUnknown ignores fields the schema doesn't declare. Same result shape as validate().
defineMethod(Schema.prototype, 'validateValue', (function validateValue(objectText, { skipRequired = false, allowUnknown = false } = {}) {
   const m = this._live();
   if (typeof objectText !== 'string') { api.internals.setLastError(null); return null; }
   const vo = { skipRequired: !!skipRequired, allowUnknown: !!allowUnknown };
   api.internals.setLastError(null);
   const quick = recordFast(m, objectText, vo);
   if (quick !== null) return result(quick, plain);
   const f = loadValue(objectText);
   if (f === null) return null;
   return result(validateObject(m, f.c, f.v, vo), plain);
}));

// Parses `docText`, finds the top-level statement `name`, and validates its object value: validateValue() for a request body
// you already hold as ANVL text. An absent statement is one REQUIRED violation with an empty field; one that is not an object
// is the native TYPE_MISMATCH. `each: true` treats an array or tuple value as a batch: every element is validated with the
// same options, and its violations are reported at "[i]" / "[i].field".
defineMethod(Schema.prototype, 'validateField', (function validateField(docText, name, { skipRequired = false, allowUnknown = false, each = false } = {}) {
   const m = this._live();
   if (typeof docText !== 'string') throw new TypeError('docText must be a string');
   if (typeof name !== 'string') throw new TypeError(`name must be a string, not ${typeof name}`);
   if (name.includes('\0')) throw new RangeError('name must not contain a NUL character');
   const d = loadDoc(docText, false, false);
   if (d === null) return null;
   const wanted = utf8Binary(name);
   let stmt = -1;
   for (const doc of d.res.docs) {
      for (const s of topStmts(d.c, doc)) if (stmt < 0 && stmtName(d.c, s) === wanted) stmt = s;
   }
   if (stmt < 0) {
      return { valid: false, violations: [{ category: SchemaViolation.REQUIRED, field: '', message: `statement '${name}' is not present` }] };
   }
   const vo = { skipRequired: !!skipRequired, allowUnknown: !!allowUnknown };
   const v = stmtValue(d.c, stmt);
   const t = vtype(d.c, v);
   if (each && (t === V_ARRAY || t === V_TUPLE)) {
      const all = [];
      elementsOf(d.c, v).forEach((e, i) => {
         for (const x of validateObject(m, d.c, e, vo)) all.push({ category: x.category, field: x.field === '' ? `[${i}]` : `[${i}].${x.field}`, message: x.message });
      });
      return result(all, plain);
   }
   return result(validateObject(m, d.c, v, vo), plain);
}));

// What the schema reported while loading; [{ category, typeCategory, field, message }].
Object.defineProperty(Schema.prototype, 'diagnostics', { get: (function diagnostics() { return this._live().diagnostics.map((d) => ({ category: d.category, typeCategory: d.typeCategory, field: toUtf8(d.field), message: toUtf8(d.message) })); }), configurable: true });

defineMethod(Schema.prototype, 'dispose', (function dispose() { this._m = null; }));

// the native-shaped layer anvil.js's own corpus runner (js/schema-run.js) drives; not part of the package API
const nativeLayer = {
   readDocument, readFragment, recordFast, schemaValidateValueText, registryLoad, registryFromIncludes, schemaLoad, schemaValidate, schemaValidateValue,
   NATIVE_DEFS, resolveType, vtype, textOf, rawBytes, stmtsOf, stmtName, stmtValue, elementsOf, numRead, V_NULL, V_BOOL, V_NUMERIC,
   V_STRING, V_BLOB, V_BARE, V_ARRAY, V_TUPLE, V_OBJECT,
};

module.exports = { TypeKind, TypeDiagnostic, SchemaViolation, SchemaDiagnostic, TypeRegistry, TypeDef, Schema, SchemaField, nativeLayer };
