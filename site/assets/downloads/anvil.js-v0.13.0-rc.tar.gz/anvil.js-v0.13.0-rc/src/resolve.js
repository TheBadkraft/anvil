'use strict';
// The resolver (resolver.c): a separate pass over the whole include graph, after every document parsed.
//   1. top-level identifiers (a duplicate is an error), 2. every base must exist and be a named statement,
//   3. inheritance: an object lists its base chain's fields after its own, 4. $name references resolve to the
//   final value they point at. Statements are visited in creation order, which is node order here.
const { CODES: E } = require('./errors');
const R = require('./reader');
const { latin1 } = require('./bytes');

const lineColOf = (function lineColOf(buf, pos) {
   let line = 1, last = -1;
   for (let i = buf.indexOf(10); i >= 0 && i < pos; i = buf.indexOf(10, i + 1)) { line++; last = i; }
   return [line, pos - last];
});

const docOfNode = (function docOfNode(docs, node) {
   let lo = 0, hi = docs.length - 1;
   while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (docs[mid].lo <= node) lo = mid; else hi = mid - 1;
   }
   return lo;
});

const hashBytes = (function hashBytes(buf, s, e) {
   let h = 0x811c9dc5;
   for (let i = s; i < e; i++) h = Math.imul(h ^ buf[i], 0x01000193);
   return h >>> 0;
});

const sameBytes = (function sameBytes(ab, as, ae, bb, bs, be) {
   if (ae - as !== be - bs) return false;
   for (let i = as, j = bs; i < ae; i++, j++) if (ab[i] !== bb[j]) return false;
   return true;
});

// Returns null when everything resolved, else { code, line, col, message }.
// Fills `inherited` (object value node -> extra statement nodes) and each VARREF node's resolved slot.
const POOL_SLOTS = new Int32Array(4096), POOL_SLOT_DOC = new Int32Array(4096);
const NO_INHERITED = new Map(); // shared and never written: most documents have no inheritance

const resolve = (function resolve(docs, tree, res) {
   const T = tree.T;
   let total = 0;
   for (const d of docs) total += d.nstmt;
   let cap = 16;
   while (cap < total * 2) cap <<= 1;
   const mask = cap - 1;
   const slotStmt = cap <= POOL_SLOTS.length ? POOL_SLOTS.fill(-1, 0, cap) : new Int32Array(cap).fill(-1);
   const slotDoc = cap <= POOL_SLOTS.length ? POOL_SLOT_DOC : new Int32Array(cap);

   // 1. identifiers
   let count = 0;
   for (let di = 0; di < docs.length; di++) {
      const d = docs[di], buf = d.buf;
      for (let s = d.firstStmt; s >= 0; s = T[s + 6]) {
         const ns = T[s + 1], ne = T[s + 2];
         let i = hashBytes(buf, ns, ne) & mask;
         while (slotStmt[i] >= 0) {
            const o = slotStmt[i];
            const od = docs[slotDoc[i]];
            if (sameBytes(od.buf, T[o + 1], T[o + 2], buf, ns, ne)) {
               const [line, col] = lineColOf(buf, ns);
               const [firstLine] = lineColOf(od.buf, T[o + 1]);
               const nameLen = Math.min(ne - ns, 100);
               const name = latin1(buf, ns, ns + nameLen);
               return {
                  code: E.ANVL_ERR_RESOLVER_DUPLICATE_IDENTIFIER, line, col,
                  message: `Duplicate top-level identifier '${name}' (first declared at line ${firstLine})`,
               };
            }
            i = (i + 1) & mask;
         }
         slotStmt[i] = s;
         slotDoc[i] = di;
         count++;
      }
   }

   function lookup(buf, s, e) {
      let i = hashBytes(buf, s, e) & mask;
      while (slotStmt[i] >= 0) {
         const o = slotStmt[i];
         if (sameBytes(docs[slotDoc[i]].buf, T[o + 1], T[o + 2], buf, s, e)) return o;
         i = (i + 1) & mask;
      }
      return -1;
   }

   const bases = tree.baseStmts;
   const docBuf = (node) => docs[docOfNode(docs, node)].buf;

   // 2. bases
   for (const s of bases) {
      const base = lookup(docBuf(s), T[s + 3], T[s + 4]);
      if (base < 0) return { code: E.ANVL_ERR_RESOLVER_MISSING_BASE, line: 0, col: 0 };
      if ((T[base] & 255) === R.S_BLOCK) return { code: E.ANVL_ERR_CANNOT_INHERIT_FROM_ANONYMOUS, line: 0, col: 0 };
      // a base must itself be an object: a scalar, array, tuple, blob or reference has no fields to merge (4020), reported
      // at the base name in the deriving statement
      const bv = T[base + 5];
      if (bv < 0 || T[bv] !== R.T_OBJECT) {
         const [line, col] = lineColOf(docBuf(s), T[s + 3]);
         return { code: E.ANVL_ERR_PARSER_INHERITANCE_REQUIRES_OBJECT, line, col };
      }
   }

   // 3. inheritance. An object's field list is its own statements, then what was merged into it.
   const objectOf = (stmt) => {
      if ((T[stmt] & 255) === R.S_BLOCK) return T[stmt + 5];
      const v = T[stmt + 5];
      return v >= 0 && T[v] === R.T_OBJECT ? v : -1;
   };
   const fieldsOf = (obj) => {
      const out = [];
      for (let c = T[obj + 5]; c >= 0; c = T[c + 6]) out.push(c);
      const extra = res.inherited.get(obj);
      if (extra) for (const x of extra) out.push(x);
      return out;
   };
   const hasName = (obj, field) => {
      const fb = docBuf(field), fs = T[field + 1], fe = T[field + 2];
      for (let c = T[obj + 5]; c >= 0; c = T[c + 6]) {
         if (sameBytes(docBuf(c), T[c + 1], T[c + 2], fb, fs, fe)) return true;
      }
      const extra = res.inherited.get(obj);
      if (extra) for (const c of extra) if (sameBytes(docBuf(c), T[c + 1], T[c + 2], fb, fs, fe)) return true;
      return false;
   };
   const maxHops = count + 1;
   for (const s of bases) {
      const obj = objectOf(s);
      if (obj < 0) continue;
      let bs = T[s + 3], be = T[s + 4], bbuf = docBuf(s);
      let ended = false;
      for (let hop = 0; hop < maxHops; hop++) {
         const anc = lookup(bbuf, bs, be);
         if (anc < 0) { ended = true; break; }
         const ancObj = objectOf(anc);
         if (ancObj >= 0) {
            for (const f of fieldsOf(ancObj)) {
               if (!hasName(obj, f)) {
                  let extra = res.inherited.get(obj);
                  if (!extra) {
                     if (res.inherited === NO_INHERITED) res.inherited = new Map();
                     res.inherited.set(obj, extra = []);
                  }
                  extra.push(f);
               }
            }
         }
         if (T[anc + 3] < 0) { ended = true; break; }
         bbuf = docBuf(anc); bs = T[anc + 3]; be = T[anc + 4];
      }
      if (!ended) return { code: E.ANVL_ERR_RESOLVER_CYCLE_DETECTED, line: 0, col: 0 };
   }

   // 4. references
   for (const v of tree.varrefs) {
      let ts = T[v + 3], te = T[v + 4], tb = docBuf(v), found = -1;
      for (let hop = 0; hop < maxHops; hop++) {
         const st = lookup(tb, ts, te);
         if (st < 0) break;
         const val = T[st + 5];
         if (val < 0) break; // a block-form statement has an OBJECT value of its own, so a reference to it resolves
         if (T[val] !== R.T_VARREF) { found = val; break; }
         tb = docBuf(val); ts = T[val + 3]; te = T[val + 4];
      }
      T[v + 5] = found;
   }
   return null;
});

module.exports = { resolve, NO_INHERITED, lineColOf, docOfNode };
