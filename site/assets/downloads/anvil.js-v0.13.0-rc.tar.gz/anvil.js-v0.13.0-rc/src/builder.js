'use strict';
// AnvilBuilder (phase S4): a port of native's src/writer/builder.c. Browser-safe. A tree of nodes and members, validated at each
// call with the writer's grammar rules, and emitted by driving AnvilWriter, so the builder adds no emission logic of its own.
// Errors are not sticky: a rejected call throws and changes nothing; what is only known once the tree is complete fails at emit().
const { AnvilDialect, WriterErrorCode: E, AnvilWriterError, AnvilWriter, Arg, grammar } = require('./writer');
const { checkName, checkBare, checkAttributeValue, checkAttributeText, NUMERIC, TAG, quoteString, wellFormed, formatDouble, blobContent } = grammar;

const MAX_DEPTH = 256; // ANVIL_BUILDER_MAX_DEPTH
const K_NULL = 0, K_BOOL = 1, K_NUMERIC = 2, K_STRING = 3, K_BARE = 4, K_BLOB = 5, K_VARREF = 6, K_ARRAY = 7, K_TUPLE = 8, K_OBJECT = 9;
const T_ARRAY = 0, T_TUPLE = 1, T_OBJECT = 2;
const SCALAR_MAX = K_VARREF;
const SCAN_MAX = 8;

// How value(x) maps a JS value to a native scalar (anvil-node's Arg.classify): a safe integer is an int64; a bigint is exact;
// any other number is a double; a string is ambiguous between string() and bare(), so it is a TypeError.
function classify(value) {
   if (value === null) return 'null';
   if (typeof value === 'boolean') return 'bool';
   if (typeof value === 'bigint') return 'int';
   if (typeof value === 'number') return Number.isSafeInteger(value) ? 'int' : 'double';
   throw new TypeError(`value() takes null, a boolean, a number or a bigint, not ${typeof value}; ` +
                       'use string() or bare() for text, blob() for bytes');
}

function text(value, what) {
   if (typeof value !== 'string') throw new TypeError(`${what} must be a string, not ${typeof value}`);
   return wellFormed(value); // the UTF-8 bytes of the string: a lone surrogate is U+FFFD
}

function data(value) {
   if (typeof value === 'string' || ArrayBuffer.isView(value) || value instanceof ArrayBuffer) return blobContent(value);
   throw new TypeError('data must be bytes (a Uint8Array) or a string');
}

// A value created through a builder: detached, attached exactly once (as an array/tuple element or a member's value). Once added
// to a document or an object it is a statement too: its name, base and attributes live here, and an AnvilMember is a handle on it.
class AnvilNode {
   constructor(builder, kind, body) {
      this._builder = builder;
      this._kind = kind;
      this._body = body;       // the scalar's text as the writer emits it
      this._parent = null;     // the array/tuple/object holding this node; null at document level or while detached
      this._name = null;       // set when the node is added as a statement (to the document or to an object)
      this._meta = null;       // [base, base target, cycle-check mark, key, value, quoted, key, value, quoted, ...] once a statement has a base or an attribute
      this._next = null;       // the next element or member of the container holding this node
   }

   append(element) {
      this._builder._appendTo(this, element);
      return this;
   }

   add(name, value) {
      return this._builder._addTo(this, name, value);
   }

   find(name) {
      return this._builder._findIn(this, name);
   }
}

// An array, tuple or object: what a scalar does not carry.
class AnvilContainer extends AnvilNode {
   constructor(builder, kind) {
      super(builder, kind, null);
      this._height = 1;   // containers on the longest path down from here, this one included (capped)
      this._first = null; // array/tuple elements, or object members (nodes), as a linked list: no array to grow per container
      this._last = null;
      this._count = 0;
      this._extra = null; // object: the field names once there are many (a Set)
   }
}

// A statement already added to a builder: a handle on its node, which holds the name, base, attributes and value.
class AnvilMember {
   constructor(node) {
      this._node = node;
   }

   setBase(base) {
      const b = this._node._builder;
      b._live();
      return b._setBase(this._node, Arg.required(base, 'base')), this;
   }

   attribute(key, value = null) {
      const b = this._node._builder;
      b._live();
      return b._memberAttr(this._node, Arg.required(key, 'key'), Arg.optional(value, 'value'), false), this;
   }

   attributeString(key, t) {
      const b = this._node._builder;
      b._live();
      return b._memberAttr(this._node, Arg.required(key, 'key'), text(t, 'text'), true), this;
   }
}

class AnvilBuilder {
   constructor(dialect) {
      this._dialect = dialect;
      this._err = 0;
      this._disposed = false;
      this._header = [];  // [isInclude, key, value, quoted]
      this._members = []; // document-level statements, in order
      this._byName = new Map(); // document-level statements by name
      this._epoch = 0;
      this._based = [];   // every member that was given a base
   }

   // A builder: create values first and place them afterwards, add incrementally, re-emit after changing.
   static create(dialect) {
      return new AnvilBuilder(Arg.dialect(dialect));
   }

   _live() {
      if (this._disposed) throw new Error('AnvilBuilder has been disposed');
      return this;
   }

   // Records a call's outcome; throws the failure, or returns `result`.
   _fail(code) {
      this._err = code;
      throw new AnvilWriterError(code);
   }

   get error() {
      this._live();
      return this._err;
   }

   // The node of `node`, which must belong to this builder.
   _owned(node, what) {
      if (!(node instanceof AnvilNode)) throw new TypeError(`${what} must be an AnvilNode`);
      if (node._builder !== this) throw new Error(`${what} belongs to a different AnvilBuilder`);
      this._live();
      return node;
   }

   // ---- header (AML only) ----

   attribute(key, value = null) {
      this._live();
      return this._addHeader(false, Arg.required(key, 'key'), Arg.optional(value, 'value'), false);
   }

   attributeString(key, t) {
      this._live();
      return this._addHeader(false, Arg.required(key, 'key'), text(t, 'text'), true);
   }

   include(path) {
      this._live();
      return this._addHeader(true, Arg.required(path, 'path'), null, false);
   }

   _addHeader(isInclude, key, value, quoted) {
      if (this._dialect === AnvilDialect.AMP) this._fail(E.DIALECT);
      let code;
      if (isInclude) {
         code = key === '' || /["\n\r]/.test(key) ? E.INVALID_INCLUDE_PATH : 0;
      } else {
         code = checkName(key);
         if (code === 0 && value !== null) code = quoted ? checkAttributeText(value) : checkAttributeValue(value);
      }
      if (code !== 0) this._fail(code);
      if (!isInclude) {
         for (const h of this._header) if (!h[0] && h[1] === key) this._fail(E.DUPLICATE_ATTRIBUTE_KEY);
      }
      this._header.push([isInclude, key, value, quoted]);
      this._err = 0;
      return this;
   }

   // ---- values (created detached) ----

   _node(kind, body) {
      this._err = 0;
      return new AnvilNode(this, kind, body);
   }

   _container(kind) {
      this._err = 0;
      return new AnvilContainer(this, kind);
   }

   null() { return this._live()._node(K_NULL, 'null'); }

   value(value) {
      this._live();
      switch (classify(value)) {
         case 'null': return this._node(K_NULL, 'null');
         case 'bool': return this._node(K_BOOL, value ? 'true' : 'false');
         case 'int': return this._node(K_NUMERIC, value.toString());
         default: return this._doubleNode(value);
      }
   }

   // native's anvil_builder_double: the double is always written as its shortest %g text (internal: value() sends a safe
   // integer down the integer path, and anvil-node has no call for a double that holds an integer, or for -0)
   _double(value) {
      return this._live()._doubleNode(value);
   }

   _doubleNode(value) {
      if (!Number.isFinite(value)) this._fail(E.INVALID_NUMERIC);
      return this._node(K_NUMERIC, formatDouble(value));
   }

   numeric(t) {
      this._live();
      Arg.required(t, 'text');
      if (!NUMERIC.test(t)) this._fail(E.INVALID_NUMERIC);
      return this._node(K_NUMERIC, t);
   }

   string(t) {
      this._live();
      return this._node(K_STRING, quoteString(text(t, 'text')));
   }

   bare(t) {
      this._live();
      Arg.required(t, 'text');
      const code = checkBare(t);
      if (code !== 0) this._fail(code);
      return this._node(K_BARE, t);
   }

   // `tag` is null (or empty) for an untagged blob; `data` is bytes or a string.
   blob(tag, content) {
      this._live();
      tag = Arg.optional(tag, 'tag');
      const [t, bytes] = data(content);
      const tagged = tag !== null && tag !== '';
      if ((tagged && !TAG.test(tag)) || (t !== null ? t.includes('`') : bytes.includes(96))) this._fail(E.INVALID_BLOB);
      const n = this._node(K_BLOB, t === null ? null : (tagged ? '@' + tag : '') + '`' + t + '`');
      if (t === null) n._extra = { tag: tagged ? tag : null, bytes: bytes.slice() };
      return n;
   }

   varref(name) {
      this._live();
      Arg.required(name, 'name');
      if (this._dialect === AnvilDialect.AMP) this._fail(E.DIALECT);
      const code = checkName(name);
      if (code !== 0) this._fail(code);
      return this._node(K_VARREF, '$' + name);
   }

   array() { return this._live()._container(K_ARRAY); }
   tuple() { return this._live()._container(K_TUPLE); }

   object() {
      this._live();
      if (this._dialect === AnvilDialect.AMP) this._fail(E.DIALECT);
      return this._container(K_OBJECT);
   }

   // ---- structure ----

   // Adds a top-level statement; a name may be added once. Statements emit in the order added.
   add(name, value) {
      return this._addTo(null, name, value);
   }

   find(name) {
      return this._findIn(null, name);
   }

   _addTo(object, name, value) {
      this._live();
      const checkedName = Arg.required(name, 'name');
      if (object !== null) this._owned(object, 'object');
      this._owned(value, 'value');
      if (object !== null && object._kind !== K_OBJECT) this._fail(E.STATE);
      const code = checkName(checkedName);
      if (code !== 0) this._fail(code);
      if (value._name !== null || value._parent !== null || contained(object, value)) this._fail(E.STATE);
      if (object === null) {
         if (this._byName.has(checkedName)) this._fail(E.DUPLICATE_NAME);
      } else {
         // an object with few fields is scanned; past SCAN_MAX fields the names go in a Set
         let dup = false;
         if (object._extra !== null) {
            dup = object._extra.has(checkedName);
         } else {
            for (let c = object._first; c !== null; c = c._next) if (c._name === checkedName) { dup = true; break; }
            if (!dup && object._count >= SCAN_MAX) {
               object._extra = new Set();
               for (let c = object._first; c !== null; c = c._next) object._extra.add(c._name);
            }
         }
         if (dup) this._fail(E.DUPLICATE_FIELD);
         if (object._extra !== null) object._extra.add(checkedName);
      }
      value._name = checkedName;
      value._parent = object;
      if (object !== null) link(object, value); else { this._members.push(value); this._byName.set(checkedName, value); }
      if (value._kind >= K_ARRAY) raise(object, value._height);
      this._err = 0;
      return new AnvilMember(value);
   }

   _findIn(object, name) {
      this._live();
      Arg.required(name, 'name');
      if (object !== null) {
         this._owned(object, 'object');
         if (object._kind !== K_OBJECT) return null;
         for (let c = object._first; c !== null; c = c._next) if (c._name === name) return new AnvilMember(c);
      } else {
         const m = this._byName.get(name);
         if (m !== undefined) return new AnvilMember(m);
      }
      return null;
   }

   _appendTo(collection, element) {
      this._live();
      this._owned(collection, 'collection');
      this._owned(element, 'element');
      if (collection._kind !== K_ARRAY && collection._kind !== K_TUPLE) this._fail(E.STATE);
      if (element._name !== null || element._parent !== null || contained(collection, element)) this._fail(E.STATE);
      if (this._dialect === AnvilDialect.AMP && element._kind >= K_ARRAY) this._fail(E.DIALECT);
      link(collection, element);
      element._parent = collection;
      if (element._kind >= K_ARRAY) raise(collection, element._height);
      this._err = 0;
   }

   // ---- members ----

   _memberReady() {
      if (this._dialect === AnvilDialect.AMP) this._fail(E.DIALECT);
   }

   _setBase(m, base) {
      this._memberReady();
      let code = checkName(base);
      if (code === 0 && m._kind !== K_OBJECT) code = E.INHERITANCE_REQUIRES_OBJECT;
      if (code !== 0) this._fail(code);
      if (m._meta === null) { m._meta = [base, null, 0]; this._based.push(m); }
      else {
         if (m._meta[0] === null) this._based.push(m); // a base is never removed, so a member is listed once
         m._meta[0] = base;
      }
      this._err = 0;
   }

   _memberAttr(m, key, value, quoted) {
      this._memberReady();
      let code = checkName(key);
      if (code === 0 && value !== null) code = quoted ? checkAttributeText(value) : checkAttributeValue(value);
      if (code !== 0) this._fail(code);
      if (value !== null && !quoted) value = wellFormed(value); // as the writer emits it
      const meta = m._meta;
      if (meta === null) {
         m._meta = [null, null, 0, key, value, quoted];
      } else {
         for (let i = 3; i < meta.length; i += 3) if (meta[i] === key) this._fail(E.DUPLICATE_ATTRIBUTE_KEY);
         meta.push(key, value, quoted);
      }
      this._err = 0;
   }

   // ---- output ----

   // BR-2610-anvl-writer-002, -004: what the reader would refuse about the bases, across every member the builder created (attached
   // or not). A base names a top-level member of this document. In this order: the member it names must be an object; it must exist,
   // unless the builder holds an include, which may supply it; and the chain of top-level members' bases must not loop.
   _checkBases() {
      const based = this._based;
      if (based.length === 0) return 0;
      const byName = this._byName;
      const includes = this._header.some((h) => h[0]);
      let missing = false;
      for (const m of based) {
         const mt = m._meta;
         const target = byName.get(mt[0]);
         mt[1] = target === undefined ? null : target; // kept for the cycle walk below
         if (target !== undefined && target._kind !== K_OBJECT) return E.INHERITANCE_REQUIRES_OBJECT;
         missing = missing || (target === undefined && !includes);
      }
      if (missing) return E.MISSING_BASE;
      // A cycle among the top-level members' bases. Each member has at most one base, so this is a walk on a functional graph:
      // a member of the walk in progress is marked base+1 and, when the walk ends, base+2; reaching one in progress is a loop.
      // Every member is visited once, so the check is linear however long the chains are. (base is new for every check.)
      const base = (this._epoch += 3);
      for (const start of based) {
         if (start._meta[2] > base) continue;
         const path = [];
         let cur = start;
         for (;;) {
            const mt = cur._meta;
            if (mt === null || mt[0] === null) break;   // not based: the chain ends
            if (mt[2] > base) {
               if (mt[2] === base + 1) return E.INHERITANCE_CYCLE;
               break;                                   // already walked and found to end
            }
            mt[2] = base + 1;
            path.push(mt);
            cur = mt[1];
            if (cur === null) break;                    // supplied by an include
         }
         for (const mt of path) mt[2] = base + 2;
      }
      return 0;
   }

   _checkDepth() {
      for (const m of this._members) if (m._kind >= K_ARRAY && m._height > MAX_DEPTH) return E.DEPTH_EXCEEDED;
      return 0;
   }

   // Replays the tree into `w`: the includes, then the module attributes (BR-2610-anvl-writer-003), then the statements.
   _replay(w, trusted) {
      let code = this._checkBases();
      if (code === 0) code = this._checkDepth();
      if (code !== 0) { this._err = code; return false; }
      let ok = true;
      const header = this._header;
      for (let i = 0; ok && i < header.length; i++) if (header[i][0]) ok = w._include(header[i][1]);
      for (let i = 0; ok && i < header.length; i++) if (!header[i][0]) ok = w._attribute(header[i][1], header[i][2], header[i][3]);
      const members = this._members;
      for (let i = 0; ok && i < members.length; i++) ok = trusted ? emitMemberTrusted(w, members[i]) : emitMember(w, members[i]);
      this._err = ok ? 0 : w._err;
      return ok;
   }

   // Replays the tree into a fresh writer of the same dialect. The writer is not finished.
   write(writer) {
      this._live();
      if (!(writer instanceof AnvilWriter)) throw new TypeError('writer must be an AnvilWriter');
      writer._live();
      if (!this._replay(writer)) throw new AnvilWriterError(this._err);
      return this;
   }

   _emitted() {
      const w = new AnvilWriter(this._dialect);
      if (!this._replay(w, true) || !w._finish()) {
         if (this._err === 0) this._err = w._err;
         throw new AnvilWriterError(this._err);
      }
      return w;
   }

   emitBytes() {
      return this._live()._emitted().finishBytes();
   }

   emit() {
      return this._live()._emitted()._text();
   }

   dispose() {
      if (!this._disposed) {
         this._disposed = true;
         this._header = this._members = this._based = null;
         this._byName = null;
      }
   }
}

// Appends `child` to the container's list.
function link(container, child) {
   if (container._last === null) container._first = child; else container._last._next = child;
   container._last = child;
   container._count++;
}

// Whether `node` is `candidate` or sits inside it, walking up through the containers.
function contained(node, candidate) {
   for (; node !== null; node = node._parent) if (node === candidate) return true;
   return false;
}

// `container` now holds something `h` containers deep: raise the heights above it (capped, so a deep tree is cheap to track).
function raise(container, h) {
   for (h += 1; container !== null && h > container._height && container._height <= MAX_DEPTH; container = container._parent) {
      container._height = h > MAX_DEPTH + 1 ? MAX_DEPTH + 1 : h;
      h = container._height + 1;
   }
}

function emitMember(w, m) {
   const meta = m._meta;
   if (meta === null) return w._statement(m._name, null) && emitNode(w, m);
   if (!w._statement(m._name, meta[0])) return false;
   for (let i = 3; i < meta.length; i += 3) if (!w._attribute(meta[i], meta[i + 1], meta[i + 2])) return false;
   return emitNode(w, m);
}

function emitMemberTrusted(w, m) {
   const meta = m._meta;
   if (meta === null) return w._statementTrusted(m._name, null) && emitNodeTrusted(w, m);
   if (!w._statementTrusted(m._name, meta[0])) return false;
   for (let i = 3; i < meta.length; i += 3) if (!w._attributeTrusted(meta[i], meta[i + 1], meta[i + 2])) return false;
   return emitNodeTrusted(w, m);
}

function emitNode(w, n) {
   const kind = n._kind;
   if (kind <= SCALAR_MAX) {
      if (kind === K_VARREF) return w._varref(n._body.slice(1));
      if (kind === K_BLOB && n._body === null) return w._blob(n._extra.tag, null, n._extra.bytes);
      return w._scalar(n._body);
   }
   const t = kind === K_ARRAY ? T_ARRAY : kind === K_TUPLE ? T_TUPLE : T_OBJECT;
   if (!w._begin(t)) return false;
   if (t === T_OBJECT) {
      for (let c = n._first; c !== null; c = c._next) if (!emitMember(w, c)) return false;
   } else {
      for (let c = n._first; c !== null; c = c._next) if (!emitNode(w, c)) return false;
   }
   return w._end(t);
}

function emitNodeTrusted(w, n) {
   const kind = n._kind;
   if (kind <= SCALAR_MAX) {
      if (kind === K_VARREF) return w._varref(n._body.slice(1));
      if (kind === K_BLOB && n._body === null) return w._blob(n._extra.tag, null, n._extra.bytes);
      return w._scalar(n._body);
   }
   const t = kind === K_ARRAY ? T_ARRAY : kind === K_TUPLE ? T_TUPLE : T_OBJECT;
   if (!w._begin(t)) return false;
   if (t === T_OBJECT) {
      for (let c = n._first; c !== null; c = c._next) if (!emitMemberTrusted(w, c)) return false;
   } else {
      for (let c = n._first; c !== null; c = c._next) if (!emitNodeTrusted(w, c)) return false;
   }
   return w._end(t);
}

module.exports = { AnvilBuilder, AnvilNode, AnvilMember };
