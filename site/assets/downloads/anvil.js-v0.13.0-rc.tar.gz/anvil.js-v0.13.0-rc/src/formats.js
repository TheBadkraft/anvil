'use strict';
// The closed set of lexical formats a String constraint can name (internal/format.h, anvil_types.c): iso8601_date,
// iso8601_datetime, uuid. As native's hand-written checks: a real calendar check, an offset that is required. Text is a binary
// string (one char per byte). A shape is matched by regex (native speed from the first call) and the ranges are checked on the captures;
// test/formats.test.js compares this with the character-by-character version it replaced.

const DATE = /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/;
const DATETIME = /^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.[0-9]+)?(?:Z|[+-]([0-9]{2}):([0-9]{2}))$/;
const UUID = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const DIM = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

// a real calendar date
const calendar = (function calendar(year, month, day) {
   if (month < 1 || month > 12 || day < 1) return false;
   let dim = DIM[month - 1];
   if (month === 2 && ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0)) dim = 29;
   return day <= dim;
});

const date = (function date(s) {
   const m = DATE.exec(s);
   return m !== null && calendar(+m[1], +m[2], +m[3]);
});

const datetime = (function datetime(s) {
   const m = DATETIME.exec(s);
   if (m === null || !calendar(+m[1], +m[2], +m[3])) return false;
   if (+m[4] > 23 || +m[5] > 59 || +m[6] > 60) return false; // 60: a leap second
   return m[7] === undefined || (+m[7] <= 23 && +m[8] <= 59);
});

const uuid = (function uuid(s) { return UUID.test(s); });

const CHECKS = { iso8601_date: date, iso8601_datetime: datetime, uuid };

const known = (function known(name) { return name === 'iso8601_date' || name === 'iso8601_datetime' || name === 'uuid'; });
const valid = (function valid(name, text) { return known(name) ? CHECKS[name](text) : false; });

module.exports = { known, valid };
