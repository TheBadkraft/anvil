'use strict';
// Node entry point: the browser-safe API, plus the filesystem for `include` (resolved against the working directory,
// as anvil-node does for parse()).
const fs = require('node:fs');
const api = require('../src/api');
const writer = require('../src/writer');

api.setDefaultIo({
   // anvil_load cannot read a directory (the loaders of Schema and TypeRegistry ask)
   isDirectory(binaryPath) {
      try {
         return fs.statSync(Buffer.from(binaryPath, 'latin1')).isDirectory();
      } catch (e) {
         return false;
      }
   },
   readFile(binaryPath) {
      try {
         return fs.readFileSync(Buffer.from(binaryPath, 'latin1'));
      } catch (e) {
         return null; // a directory, a missing or an unreadable file (an include of a directory is an include error)
      }
   },
   // why a file could not be read, as native's loader reports it: 1002 missing, 1001 anything else (a directory, no permission)
   readFailure(binaryPath) {
      try {
         fs.statSync(Buffer.from(binaryPath, 'latin1'));
         return 1001;
      } catch (e) {
         return e.code === 'ENOENT' || e.code === 'ENOTDIR' ? 1002 : 1001;
      }
   },
});
// anvil-node returns Buffers for the writer's bytes
writer.setBytes((u8) => Buffer.from(u8.buffer, u8.byteOffset, u8.byteLength));
module.exports = require('../src/index.js');
