# anvil.js

The pure-JavaScript ANVL implementation (published as `anvil.js`, with the same API as anvil-node). ANVL Native is the spec: this reader is held to
it by the native-owned conformance corpus (`vendor/anvil/conformance/`), differential fuzzing and drift tests.

Design (owner-approved in R0): UTF-8 `Uint8Array` input, one `Int32Array` tree with 8 ints per node holding source
spans, values decoded lazily, a single forward pass with no lexer.

- `src/reader.js` header and body scanner; `src/load.js` include graph and phases; `src/resolve.js` the resolver;
  `src/dump.js` the FORMAT.md dump writer; `js/dump.js` the `anvil-dump` command line.
- `src/writer.js` the streaming writer (`AnvilWriter`); `src/builder.js` the document builder (`AnvilBuilder`, `AnvilNode`, `AnvilMember`), which emits through the writer.

## Use

```js
const anvl = require('anvil.js');          // Node (include resolves against the working directory)
const doc = anvl.parse('#!aml\nid := 9007199254740993;\nname := "x";\n');
doc.get('id').asBigInt();                  // 9007199254740993n
doc.get('name').asString();                // 'x'
anvl.parse('x := 5.;');                    // null; anvl.lastError() is { message, line, column, code, name }
```

In a browser, with no bundler: vendor `dist/anvil.mjs` (`import { parse } from './anvil.mjs'`) or load
`dist/anvil.global.js` with a script tag (it defines `window.anvl`). `npm run build` regenerates both.

The reader API is anvil-node's (`parse`, `parseRawValue`, `lastError`, `getVersion`, `AnvlNode`, `AnvlStatement`) plus
`isNull()`, `blobTag`, `overflowed`, `implementation` (`'anvil.js'`) and `BUILD_INFO.json`. The writer (`AnvilWriter`, `AnvilDialect`, `WriterErrorCode`, `AnvilWriterError`) and the builder (`AnvilBuilder`, `AnvilNode`, `AnvilMember`) are anvil-node's, byte for byte
with native's. So are the type registry and schema (`TypeRegistry`, `Schema`, `SchemaField` and the enums `TypeKind`, `TypeDiagnostic`,
`SchemaViolation`, `SchemaDiagnostic`).

Errors: `lastError()` returns anvil-node's `{ message, line, column }` and, as an addition to anvil-node's API, native's numeric
`code` (for example `4001`) and its `name` (`'ANVL_ERR_PARSER_DUPLICATE_FIELD_IN_OBJECT'`), for `parse()` and `parseRawValue()`
alike, so a consumer can test the code instead of matching message text. They equal the `code=` and `name=` of native's
conformance dump for every error case.

Writer notes (anvil-node's API, which differs from the C API in two ways a JS call cannot avoid): `value(n)` writes a safe
integer as an integer, so `value(1e15)` gives `1000000000000000` (the C `double` verb gives `1e+15`) and `value(-0)` gives `0`
(C gives `-0`); and there is no NULL, so a missing string is a `TypeError` and `string()` takes a JS string, never invalid UTF-8
(use `blob()` for raw bytes). In the browser builds, `data` and `finishBytes()` are `Uint8Array`s; in Node they are Buffers.

Builder notes: `AnvilBuilder.create(dialect)` makes values detached (`b.object()`, `b.value(1)`, ...) and places them afterwards
(`b.add(name, node)`, `object.add(...)`, `array.append(...)`); a call that is wrong in itself throws an `AnvilWriterError` and changes
nothing (errors are not sticky), and what is only known once the tree is complete (an empty collection, a base that names a
non-object, nesting deeper than 256) fails at `emit()` or `write(writer)`, after which the builder is still usable. `emit()`
writes every `include` before the module attributes, whatever order they were added in. A node or member of another builder, a
disposed builder and a missing string are an `Error` or `TypeError` before the builder is reached (the C API reports
`INVALID_ARGUMENT`); the corpus cases that need that are listed in `test/builder-c-api-only.json`. `find()` and `add()` return a new `AnvilMember` handle on every call, as anvil-node's do (two handles for one statement are not `===`).

Schema notes: `Schema.load(text)` and `Schema.loadFile(path)` read a document that carries `@[schema]`; use `loadFile` when the
schema includes `@[types]` documents (a text loader resolves includes against the working directory, a file loader against the
file). `validate(text)`, `validateValue(text, { skipRequired, allowUnknown })` and `validateField(text, name, { ..., each })` return
`{ valid, violations: [{ category, field, message }] }`, or `null` when the data does not parse (`lastError()` says why).
Violations come in native's order, with full paths (`links[2].target`). `fields`, `findField(name)` and `diagnostics` read the loaded
rules back: a field or diagnostic is a snapshot that stays readable after `dispose()`, a schema with diagnostics still loads, and a
rule whose `type` does not resolve fails closed (`UNRESOLVED_TYPE`) for any value present. `TypeRegistry` has the same load forms plus
`fromIncludes(Text|File)`, `find`, `resolve`, `diagnostics` and `loadError`. A `min` or `max` is a JS number, so a bound past 2^53
loses precision, as in anvil-node. Load failures: a file that cannot be read is native's IO failure with its code and message (`lastError()` is `{ message: 'IO file not found', code: 1002, name: 'ANVL_ERR_FILE_NOT_FOUND' }` for a missing file, 1001 `ANVL_ERR_FILE_READ` for a directory or an unreadable one, 1003 `ANVL_ERR_FILE_INVALID_PATH` for an empty path); a document without `@[schema]` or `@[types]`
is `null` with the addon's message, `code: 0` and `name: null` (there is no native code for it).

Includes in a browser: a browser has no file system, so `include` resolves through a reader you install. `setIo({ read(path) })` takes a
synchronous function that is called with the composed include path (the includer's directory, `/`, then the include string, for
example `./schema-gen/x.types.anvl`) and returns the text (a string or a `Uint8Array`) or `null` for not found, which is native's
include-not-found error (`lastError().code` 4204). It applies to `parse`, `TypeRegistry.fromIncludes` and `Schema.load`. There is no
async form and no caching; `setIo(null)` removes the reader (in Node the file system is the default again). Pre-fetch what the
document includes, put it in a map, and install it:

```js
const files = new Map();
for (const name of ['schema-gen/assets.types.anvl']) files.set('./' + name, await (await fetch('/' + name)).text());
anvl.setIo({ read: (path) => files.get(path) ?? null });
const schema = anvl.Schema.load(schemaText);   // schemaText has: include "schema-gen/assets.types.anvl";
```


Performance notes (what the code does for speed, and why; measured against anvil-node, not promised):
- The reader's functions and classes are compiled when the module loads, not on their first call (V8 compiles lazily): a process's
  first `parse()` costs about 0.2 ms instead of 1.1 ms, and `require` about 0.7 ms more. `test/eager-compile.test.js` keeps it so.
- `parseRawValue` has a fast path for an array of tuples of plain scalars (what FlyWire's Table decode feeds it): a grammar check with
  a regex, then `JSON.parse`. Everything else, and every error, takes the general reader; the two are compared by `test/raw-fast.test.js`
  and `scripts/fuzz-raw.js` (against native).
- `Schema.validateValue` has a fast path for a flat record of plain scalars (`{ name := value; ... }`), checked without building a tree;
  anything else takes the general path (`test/record-fast.test.js`, and the schema fuzz against native).
- `Schema.load` runs synthetic records through that path about 200 times before it returns. This depends on how V8 tiers up code:
  a function that has run only a few dozen times executes in a slow tier, so the first calls of a server would be several times
  slower than steady state. Warming at load, which is a one-time cost (about 0.4 ms for FlyWire's assets schema), moves that out of
  the first requests. It changes no result (the results are dropped); the code is `warmRecordPath` in `src/schema.js`. A time
  bound or a different count may suit another machine; this is a measured trade, not a guarantee.

Known performance gaps (measured, labelled, no promise to close them; a tuning phase is planned). Time ratios, anvil.js / anvil-node, lower
is faster, on CPUs 6-7, each arm in a fresh process, median of 10 processes, with FlyWire's gate inputs (flywire@f452a4a and @fef94b9,
in `bench/fixtures/anviljs-gate`); `bench/rawvalue-compare.js`, `bench/validate-compare.js` and `bench/schema-compare.js` reproduce them:
- A small `@bin` read or poll response (`parse` then `get('payload').asString()`, 1 to 17 rows): cold 1.16x to 1.48x, warm 1.6x to 2.5x.
- An AMP envelope with a `@table` or `@bin` payload at 17 and 100 rows, cold: 1.1x to 1.4x. The error document: cold 1.4x to 1.6x, warm 1.9x.
- `validateValue` on a 12-field record, calls 200-400 of a process: up to 1.15x (create-valid), 1.07x (missing-required), 1.03x (type-violation).
- `Schema.load` is about 10x slower than anvil-node's (0.45 ms against 0.044 ms for FlyWire's assets schema), partly the warm-up above.
Every other measured cell is at or below 1.00x: `parseRawValue` of FlyWire's Table text at 17 to 10,000 rows (cold 0.32x to 1.04x, warm 0.26x to 0.43x),
`validateValue` calls 1 and 20-120 and steady state (0.52x to 0.91x), `validateValue` x100 and x10,000 (0.35x), the writer and the reader gates.
