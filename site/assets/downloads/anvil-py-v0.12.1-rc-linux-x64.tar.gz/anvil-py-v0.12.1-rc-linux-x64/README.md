# anvil-py

Python bindings for **Anvil Native**, the reference C implementation of the ANVL (AML/AMP/ASL) parser. Parse
ANVL, navigate it lazily, validate it against a schema, and write it back out, with the same parser every other
Anvil binding uses. Pure `ctypes`: no compiled extension module and no dependency beyond the standard library.
Documentation: https://anvldata.com/docs

## Installing the prebuilt package

The tarball contains the `anvil` package and the native library it links against
(`runtimes/linux-x64/native/libanvil.so`), so installing it needs no compiler and no build step.

- **Python:** CPython 3.11 or later. Standard library only.
- **Platform:** Linux x64 (glibc) only. Other platforms build from source (see Development).
- **Not on PyPI yet:** there is no `pip install anvil-py`.

Download and extract the tarball, then put the extracted directory on `PYTHONPATH`:

```sh
tar xzf anvil-py-<version>-linux-x64.tar.gz
export PYTHONPATH="$PWD/<extracted directory>/src:$PYTHONPATH"
python3 -c "from anvil import AnvilDocument; print('ok')"
```

(Use the directory that contains the `anvil` package; the library is found next to it.)

## Quick start

```python
from anvil import AnvilDialect, AnvilDocument, AnvilSchema, AnvilWriter

# Parse. Accessors are lazy calls into the native library; the `with` block frees the document.
with AnvilDocument.load_buffer(
    '#!aml\n@[version="1.2"]\nticket @[type=bug] := { id := 7; title := "login fails"; };\n'
) as doc:
    assert doc is not None and not doc.has_errors
    doc.find_attribute("version").decoded_value.as_string()     # '1.2'
    ticket = doc.find_statement("ticket")
    ticket.find_attribute("type").value                         # 'bug'
    ticket.value["title"].as_string()                           # 'login fails'

# Validate. A schema is an ANVL document carrying @[schema]; the data to check is ANVL text too.
with AnvilDocument.load_buffer('#!aml\n@[schema]\nasset_id := { type := Numeric; required := true; };\n') as schema_doc:
    schema = AnvilSchema.load(schema_doc)
with schema:
    schema.validate_field('set := { asset_id := 7; };\n', "set").is_valid     # True
    bad = schema.validate_field('set := { name := "x"; };\n', "set")
    bad.is_valid                                                 # False
    [v.code.name for v in bad.violations]                        # ['REQUIRED', 'UNKNOWN_FIELD']

# Write.
with AnvilWriter.create(AnvilDialect.AMP) as w:
    text = w.statement("status").bare("ok").statement("code").value(200).finish()
```

A parse failure still gives you a usable document: always check `doc.has_errors` (`doc.error.message`, `.line`,
`.column` say why). `docs/getting-started.md` is a task-oriented walkthrough of the reading API.

## Reading

```python
from anvil import AnvilDocument, ValueType

with AnvilDocument.load("config.anvl") as doc:
    if doc is None or doc.has_errors:
        pass  # doc.error.message / .line / .column

    server = doc.find_value("server")
    if server is not None and server.type == ValueType.OBJECT:
        name = server["name"].as_string() if server["name"] else None
        port = server["port"].as_int() if server["port"] else None

    for stmt in doc.statements:
        pass  # stmt.name, stmt.value

    for included in doc.includes:
        with included:
            pass  # independently disposable, shares doc's parse context
```

`AnvilDocument`, `AnvlValue`, `AnvlStatement`, `AnvilAttribute` and `AnvilError` make every accessor a direct, lazy
call into Anvil Native; nothing is materialized into a tree up front. Python's `with` gives deterministic cleanup
(`.dispose()` also works), and using a disposed document raises `RuntimeError`.

## Type registry and schema

Anvil Native's type registry and AnvilSchema, over the `TypeRegistry` and
`Schema` vtables. Both are self-contained copies, so they outlive the `AnvilDocument` they were loaded
from; both are context managers, and the views they hand out (`TypeDef`, `SchemaField`) raise
`RuntimeError` once their owner is disposed.

```python
from anvil import AnvilDocument, AnvilSchema, AnvilTypeRegistry

with AnvilDocument.load("asset.schema.anvl") as schema_doc:     # carries @[schema]; may include @[types]
    schema = AnvilSchema.load(schema_doc)                         # None if it has no @[schema]

with schema, AnvilDocument.load_buffer('#!aml\nname := "widget";\nstatus := scrapped;\n') as data:
    result = schema.validate(data)                                # snapshot: is_valid + violations
    for v in result.violations:                                   # code (SchemaViolationCode), field, message
        print(v.code.name, v.field, v.message)

    # A request body's `set` object, validated without loading a second document:
    with AnvilDocument.parse_value_fragment('{ name := "widget"; }') as fragment:
        schema.validate_value(fragment.fragment_value, skip_required=True)

    # ...or straight from document text (same shape as `anvil-node`'s `validateField`):
    schema.validate_field('#!aml\nset := { name := "widget"; };\n', "set")

with AnvilDocument.load("asset.types.anvl") as types_doc, AnvilTypeRegistry.load(types_doc) as registry:
    year = registry.find("AssetYear")                             # resolve() also answers for Numeric, String, ...
    year.min, year.max                                            # int, float or None; None when not declared
    year.max_numeric                                              # exact: AnvilNumeric (is_integral, overflowed, as_int(), as_float())
```

- **Options are keyword-only** (`skip_required=`, `allow_unknown=`), so `validate_value(v, True)` is a
  `TypeError` rather than a coin flip about which flag you meant.
- **`validate_field(document, name)`** takes ANVL text, bytes, or an `AnvilDocument` you already loaded. It
  finds the top-level statement and validates its object value. An absent statement is one `REQUIRED`
  violation with an empty `field`; one that isn't an object is the native `TYPE_MISMATCH`; text that doesn't
  parse is a `ValueError`. A batch (`set := [ {...}, ... ]`) is validated by iterating the array and calling
  `validate_value` on each element. Text identical to a document you already hold loads independently
  of it, and a parse error carries native's real message (a missing `;` reads "Expected ';' to end the statement").
- **Absent constraints are `None`**, never a default: `size`, `min`, `max`, `min_items`, `max_items`, `format`,
  `tag`. `min`/`max` are an `int` when integral and a `float` when fractional; `min_numeric`/`max_numeric` give
  the exact `AnvilNumeric`, including its `overflowed` flag.
- **Introspection.** `schema.fields`/`find_field(name)` give each rule's `kind`, `type_name`, `is_required`,
  `is_nullable`, `is_integer`, the bounds above, `values`, `nested`/`find_nested`, the array `items` rule, and
  `extras` (extension keys such as FlyWire's `pooled`, as readable `AnvlValue`s owned by the schema).
- **Diagnostics.** `registry.diagnostics` and `schema.diagnostics` are what loading reported (`NAME_COLLISION`,
  `UNKNOWN_TYPE`, ...); whether any is fatal is the caller's call.
- **Enums** (`TypeKind`, `TypeDiagnosticCode`, `SchemaViolationCode`, `SchemaDiagnosticCode`) mirror the C headers
  value for value.
- **A NUL character** inside a document loses nothing after it, and the type registry and schema keep a NUL in
  an enum label and in a string extension value.

## Attributes

`@[...]` attributes hang off the document (module attributes) and off any statement:
`doc.attributes` / `doc.find_attribute(key)`, and `statement.attributes` / `statement.find_attribute(key)`.

```python
with AnvilDocument.load_buffer('#!aml\n@[version="1.2"]\nticket @[type=bug, urgent] := 1;\n') as doc:
    doc.find_attribute("version").value                         # '"1.2"'  (raw: the quotes are kept)
    doc.find_attribute("version").decoded_value.as_string()     # '1.2'
    ticket = doc.find_statement("ticket")
    ticket.find_attribute("type").value                         # 'bug'
    ticket.find_attribute("urgent").value                       # None: a flag has no value
    ticket.find_attribute("urgent").decoded_value               # None
```
- **Attributes have a raw `value` and a typed `decoded_value`.** `AnvilAttribute.value` is native's source text
  (`status="done"` is `'"done"'`, a flag is `None`). `decoded_value` reads the same attribute as an `AnvlValue`
  (native `anvil_attribute_get_value_handle`): escapes resolved, delimiters stripped, typed. `status="done"` is a
  STRING `done`, `note="a\"b"` is `a"b`, `n=42` a NUMERIC 42 (`as_int()`), `type=bug` a BARE `bug`. It is `None`
  for a flag; an explicit `@[x=null]` is a NULL value, which is not the same thing. A value the scalar grammar
  does not accept whole (`@[range=1..5]`) is a BARE value of its raw text.

## Writing

```python
from anvil import AnvilBuilder, AnvilDialect, AnvilWriter

# streaming: forward-only, chainable; the first rejected call raises and is sticky
with AnvilWriter.create(AnvilDialect.AML) as w:
    text = (w.statement("server").begin_object()
             .statement("host").bare("localhost")
             .statement("port").value(8080)
             .end_object().finish())

# builder: create values detached, attach them in any order, emit (and re-emit) at will
with AnvilBuilder.create(AnvilDialect.AML) as b:
    server = b.object()
    server.add("host", b.bare("localhost"))
    b.add("server", server).attribute("env", "production")
    text = b.emit()
```

Both raise `AnvilWriterError` (with a `WriterErrorCode`) when Anvil Native rejects a call; the native
library owns every grammar rule. Reading is exact: `as_int()` is exact for any integer (Python ints
are unbounded), with `as_float()`, `numeric_text()`, `is_integral()`, `as_bytes()`, `blob_tag()` and
`raw_bytes()` beside it. `finish_bytes()`/`emit_bytes()` and `AnvilDocument.load_buffer(bytes)` carry
non-UTF-8 blob bytes without a lossy `str` hop.

## Development

Everything below is for working on this repository. None of it applies to the prebuilt package.

### Building from source

```sh
git clone --recurse-submodules <this repository>
make -C vendor/anvil so-release   # produces vendor/anvil/lib/release/libanvil.so
python3 -m venv .venv
.venv/bin/pip install pytest
.venv/bin/python -m pytest
```

`vendor/anvil` is a git submodule pinned to a commit on `anvil`'s `main`; this binding's build step runs its own
`make so-release` and links against the result. Bump the submodule, rebuild. A dev checkout finds the library at
`vendor/anvil/lib/release/libanvil.so`; the packaged layout (`runtimes/linux-x64/native/libanvil.so`) takes
priority when present.

### The version string

The native library reports `MAJOR.MINOR.PATCH` plus a build number, and the build number comes from native's own
Makefile: the commit count of `vendor/anvil`, or `make -C vendor/anvil so-release BUILD_NUM=<n>` to set it (a release
build passes the tag's number; `make -C vendor/anvil clean` first, since a changed number alone does not force a rebuild
at older pins). A tree without git metadata gets 0, which native reports as no `+BUILD`. Python needs no build-side
change of its own.

### Design: vtable-first via `ctypes`, lazy

A `ctypes` call with blittable types costs tens of nanoseconds, not the V8-object-model money that pushed
`anvil-node` and `anvil-wasm` toward a single eager JSON crossing. Anvil Native's vtable ABI (`anvil_vtable.h`) was
documented to support this via `ctypes`' `in_dll`: real, lazy, on-demand navigation through direct calls, no
serialization anywhere.

Each vtable group (`Anvil`, `Document`, `Statement`, `Value`, `Attribute`, `Error`, `StatementIterator`,
`DocumentIterator`, `Writer`, `Builder`, `TypeRegistry`, `Schema`) is its own submodule under `src/anvil/_native/`: a
`ctypes.Structure` mirroring the C struct's exact field layout, read once via `in_dll`, with each function-pointer
field exposed as a plain module-level function. `AnvlValue` memoizes a per-key lookup, so a repeated lookup of the same
key costs one native call, proven by call-count assertions in the test suite.

### Testing scope

Marshaling-layer correctness only; never re-tests ANVL grammar (`vendor/anvil`'s own regression owns that).
`.venv/bin/python -m pytest`: a drift gate that checks every ctypes vtable struct and every mirrored enum against the
real C header field for field, the type registry and schema, exact numeric/blob reads, the writer and the builder,
document lifecycle and errors, navigation, attributes, the generators, value fragments, NUL handling, and library-path
resolution (packaged vs. dev checkout). Every change is test-first.

### Distribution

An `anvildata.com` tarball, in parity with `anvil-node`, `anvil-wasm` and `anvil.net`. A real PyPI package
(`pip install anvil-py`) is planned, not done; the `runtimes/{platform}/native/` layout is ready for it, and only
`linux-x64` is built and verified.

### Repo layout

```
anvil.py/
├── vendor/anvil/              (submodule: the native library source)
├── src/anvil/
│   ├── _native/               (the ctypes vtable-binding layer, one submodule per vtable group)
│   ├── document.py / value.py / statement.py / attribute.py / error.py   (public wrapper types)
│   ├── writer.py / builder.py (AnvilWriter, AnvilBuilder, AnvilNode, AnvilMember) and writer_error.py
│   ├── schema.py / type_registry.py   (AnvilSchema, AnvilTypeRegistry)
│   └── error_code.py / value_type.py / dialect.py / writer_error_code.py   (shared enums)
├── tests/                     (pytest, marshaling-layer only)
├── docs/getting-started.md    (task-oriented walkthrough)
└── CHANGELOG.md
```
