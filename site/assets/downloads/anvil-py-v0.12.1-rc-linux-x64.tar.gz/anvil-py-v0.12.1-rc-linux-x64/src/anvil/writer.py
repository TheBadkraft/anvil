"""AnvilWriter: a forward-only writer that emits canonical ANVL text -- a thin, validated view
over Anvil Native's streaming writer (anvil_writer.h). Every call is checked against the
dialect's real grammar by the native library, so what this class emits is always something the
reader parses back to the same kinds and text.

A statement is completed by exactly one value call (a scalar, or a begin_*/end_* pair). Inside an
array or tuple, value calls add elements and begin_object() adds an anonymous object; inside an
object, only statement() is legal.

The first rejected call raises AnvilWriterError and the error is sticky: every later call raises
the same code. Use it as a context manager (or call dispose()); the native buffer is released then,
exactly like AnvilDocument.

    with AnvilWriter.create(AnvilDialect.AML) as w:
        text = (w.statement("server").begin_object()
                 .statement("host").bare("localhost")
                 .statement("port").value(8080)
                 .end_object()
                 .finish())
"""
from anvil import _args
from anvil._native import writer as native
from anvil.dialect import AnvilDialect
from anvil.writer_error import AnvilWriterError
from anvil.writer_error_code import WriterErrorCode


class AnvilWriter:
    def __init__(self, handle: int):
        self._handle = handle
        self._disposed = False

    @classmethod
    def create(cls, dialect: AnvilDialect) -> "AnvilWriter":
        """Creates a writer; its shebang line is emitted immediately."""
        if not isinstance(dialect, AnvilDialect):
            raise TypeError(f"dialect must be AnvilDialect, not {type(dialect).__name__}")
        handle = native.create(dialect.value)
        if handle is None:
            raise MemoryError("Anvil Native could not allocate a writer")
        return cls(handle)

    def _live(self) -> int:
        if self._disposed:
            raise RuntimeError("AnvilWriter used after dispose()")
        return self._handle

    def _check(self, accepted: bool) -> "AnvilWriter":
        if not accepted:
            raise AnvilWriterError(WriterErrorCode(native.get_error(self._handle)))
        return self

    @property
    def error(self) -> WriterErrorCode:
        """The first error recorded, or WriterErrorCode.OK."""
        return WriterErrorCode(native.get_error(self._live()))

    # ---- header (AML only, before the first statement) ----

    def attribute(self, key: str, value: "str | None" = None) -> "AnvilWriter":
        """Adds an attribute: module-level before the first statement, statement-level right
        after statement(). `value` is raw text emitted verbatim (see anvil_writer_attribute), or
        None for a flag."""
        h = self._live()
        return self._check(native.attribute(h, _args.required(key, "key"), _args.optional(value, "value")))

    def attribute_string(self, key: str, text: str) -> "AnvilWriter":
        """As attribute(), but the value is emitted as a double-quoted string."""
        h = self._live()
        encoded = _args.text(text, "text")
        return self._check(native.attribute_string(h, _args.required(key, "key"), encoded, len(encoded)))

    def include(self, path: str) -> "AnvilWriter":
        """Adds an `include "path";` line to the module header."""
        h = self._live()
        return self._check(native.include(h, _args.required(path, "path")))

    # ---- statements ----

    def statement(self, name: str, base: "str | None" = None) -> "AnvilWriter":
        """Begins `name := value;`. Complete it with one value call. `base` declares an
        inheritance base, which requires an object value."""
        h = self._live()
        return self._check(native.statement(h, _args.required(name, "name"), _args.optional(base, "base")))

    # ---- scalar values ----

    def null(self) -> "AnvilWriter":
        return self._check(native.null_value(self._live()))

    def value(self, value) -> "AnvilWriter":
        """None, bool, int or float. An int past int64 is written exactly (ANVL numbers are
        unbounded); a non-finite float is rejected. Use string()/bare() for text."""
        h = self._live()
        kind, payload = _args.classify(value)
        if kind == "null":
            return self._check(native.null_value(h))
        if kind == "bool":
            return self._check(native.bool_value(h, payload))
        if kind == "int":
            return self._check(native.int_value(h, payload))
        if kind == "numeric":
            return self._check(native.numeric(h, payload))
        return self._check(native.double_value(h, payload))

    def numeric(self, text: str) -> "AnvilWriter":
        """ANVL numeric text: -?digits(.digits)?([eE][+-]digits)?"""
        h = self._live()
        return self._check(native.numeric(h, _args.required(text, "text")))

    def string(self, text: str) -> "AnvilWriter":
        """A quoted string; the text is encoded as UTF-8 and escaped by the native writer."""
        h = self._live()
        encoded = _args.text(text, "text")
        return self._check(native.string(h, encoded, len(encoded)))

    def bare(self, text: str) -> "AnvilWriter":
        """An unquoted literal; rejected unless it reads back as a bare literal."""
        h = self._live()
        return self._check(native.bare(h, _args.required(text, "text")))

    def blob(self, tag: "str | None", data) -> "AnvilWriter":
        """A blob. `tag` is None (or empty) for an untagged blob; `data` is bytes-like, or a str
        (UTF-8 encoded). Binary content is exact."""
        h = self._live()
        content = _args.data(data, "data")
        return self._check(native.blob(h, _args.optional(tag, "tag"), content, len(content)))

    def varref(self, name: str) -> "AnvilWriter":
        """A dollar-name reference (AML only)."""
        h = self._live()
        return self._check(native.varref(h, _args.required(name, "name")))

    # ---- collections ----

    def begin_array(self) -> "AnvilWriter":
        return self._check(native.begin_array(self._live()))

    def end_array(self) -> "AnvilWriter":
        """Needs at least one element."""
        return self._check(native.end_array(self._live()))

    def begin_tuple(self) -> "AnvilWriter":
        return self._check(native.begin_tuple(self._live()))

    def end_tuple(self) -> "AnvilWriter":
        """Needs at least two elements."""
        return self._check(native.end_tuple(self._live()))

    def begin_object(self) -> "AnvilWriter":
        """AML only."""
        return self._check(native.begin_object(self._live()))

    def end_object(self) -> "AnvilWriter":
        """Needs at least one statement."""
        return self._check(native.end_object(self._live()))

    # ---- output ----

    def finish(self) -> str:
        """Closes the document and returns its text. Raises WriterErrorCode.UNFINISHED if a
        statement, array, tuple or object is still open. Idempotent once successful."""
        return self.finish_bytes().decode("utf-8")

    def finish_bytes(self) -> bytes:
        """As finish(), but returns the exact bytes. Prefer this when the document carries blob
        content that isn't valid UTF-8 (a str can't hold it); read it back with
        AnvilDocument.load_buffer(bytes)."""
        self._check(native.finish(self._live()))
        return native.data(self._handle)

    @property
    def data(self) -> "bytes | None":
        """The emitted bytes, or None until finish() has succeeded (and after any error)."""
        return native.data(self._live())

    @property
    def text(self) -> "str | None":
        """The emitted text, or None until finish() has succeeded (and after any error)."""
        raw = self.data
        return None if raw is None else raw.decode("utf-8")

    def dispose(self) -> None:
        if self._disposed:
            return
        native.dispose(self._handle)
        self._disposed = True

    def __enter__(self) -> "AnvilWriter":
        return self

    def __exit__(self, *exc_info) -> None:
        self.dispose()
