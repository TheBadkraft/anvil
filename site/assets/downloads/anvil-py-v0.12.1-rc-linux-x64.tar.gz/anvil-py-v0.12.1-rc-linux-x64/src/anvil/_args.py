"""Argument marshaling shared by the writer and builder. NUL-terminated parameters reject an
embedded NUL (ValueError) rather than let native code silently see a truncated string; wrong
types raise TypeError before anything reaches native code; length-delimited parameters pass the
exact bytes, so a NUL or any non-UTF-8 byte inside them is just data.
"""

_INT64_MIN = -(2**63)
_INT64_MAX = 2**63 - 1


def required(value, what: str) -> bytes:
    """A required NUL-terminated UTF-8 string."""
    if not isinstance(value, str):
        raise TypeError(f"{what} must be str, not {type(value).__name__}")
    if "\0" in value:
        raise ValueError(f"{what} must not contain a NUL character")
    return value.encode("utf-8")


def optional(value, what: str) -> "bytes | None":
    """An optional NUL-terminated UTF-8 string; None becomes a native NULL."""
    return None if value is None else required(value, what)


def text(value, what: str) -> bytes:
    """Length-delimited text: the exact UTF-8 bytes of a str."""
    if not isinstance(value, str):
        raise TypeError(f"{what} must be str, not {type(value).__name__}")
    return value.encode("utf-8")


def data(value, what: str) -> bytes:
    """Length-delimited content that may be binary: bytes-like, or a str (UTF-8 encoded)."""
    if isinstance(value, str):
        return value.encode("utf-8")
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value)
    raise TypeError(f"{what} must be bytes-like or str, not {type(value).__name__}")


def classify(value) -> "tuple[str, object]":
    """How value(x) maps a Python object to a native scalar: None -> null, bool -> bool, int ->
    int64 (or, past int64, its exact decimal text as a numeric -- ANVL numbers are unbounded),
    float -> double. Anything else is a TypeError: a str is ambiguous between string() and bare().
    """
    if value is None:
        return "null", None
    if isinstance(value, bool):  # before int: bool is an int subclass
        return "bool", value
    if isinstance(value, int):
        if _INT64_MIN <= value <= _INT64_MAX:
            return "int", value
        return "numeric", str(value).encode("ascii")
    if isinstance(value, float):
        return "double", value
    raise TypeError(
        f"value() takes None, bool, int or float, not {type(value).__name__}; "
        "use string() or bare() for text, blob() for bytes"
    )
