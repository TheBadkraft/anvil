"""Binds Anvil Native's Value vtable group (anvil_vtable.h's anvil_value_i)."""
import ctypes as C
from typing import NamedTuple

from anvil.value_type import ValueType

from ._buffer import read_bytes, read_string
from ._lib import LIB


class _NumericRaw(C.Structure):
    """Mirrors anvil_numeric_t (anvil_types.h): two bools, 6 bytes of natural padding, an int64 and
    a double -- passed and returned by value, which ctypes/libffi handle for a struct restype."""

    _fields_ = [
        ("is_integral", C.c_bool),
        ("overflowed", C.c_bool),
        ("as_int64", C.c_int64),
        ("as_double", C.c_double),
    ]


class Numeric(NamedTuple):
    """A NUMERIC value as a machine number. Exactly one of as_int64/as_double is meaningful, and
    only when not overflowed: as_int64 when is_integral, as_double otherwise."""

    is_integral: bool
    overflowed: bool
    as_int64: int
    as_double: float


class _ValueRaw(C.Structure):
    _fields_ = [
        ("get_type", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("get_text", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_element", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("get_statement", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("find_statement", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("get_numeric", C.CFUNCTYPE(_NumericRaw, C.c_void_p)),
        ("get_bytes", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_void_p, C.c_size_t)),
        ("get_blob_tag", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
    ]


_vt = _ValueRaw.in_dll(LIB, "Value")


def get_type(val: int) -> ValueType:
    return ValueType(_vt.get_type(val))


def get_text(val: int) -> str:
    return read_string(lambda buf, buflen: _vt.get_text(val, buf, buflen))


def get_count(val: int) -> int:
    return _vt.get_count(val)


def get_element(val: int, index: int) -> int | None:
    return _vt.get_element(val, index)


def get_statement(val: int, index: int) -> int | None:
    return _vt.get_statement(val, index)


def find_statement(val: int, key: bytes) -> int | None:
    """One native call, every time -- no caching at this layer. The public wrapper's per-key
    memoization cache sits on top of this, not inside it (same division as anvil.net's
    AnvlValue vs. its own Anvil.Value.FindStatement)."""
    return _vt.find_statement(val, key)


def get_numeric(val: int) -> Numeric:
    raw = _vt.get_numeric(val)
    return Numeric(raw.is_integral, raw.overflowed, raw.as_int64, raw.as_double)


def get_bytes(val: int) -> bytes:
    """The exact, uninterpreted source span of a scalar (anvil_value_get_bytes). Empty for an empty
    value and for a non-scalar -- callers that must tell those apart check the type first."""
    return read_bytes(lambda buf, buflen: _vt.get_bytes(val, buf, buflen))


def get_blob_tag(val: int) -> str:
    """A blob's tag; empty for an untagged blob or any other kind."""
    return read_string(lambda buf, buflen: _vt.get_blob_tag(val, buf, buflen))
