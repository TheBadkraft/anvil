"""Binds Anvil Native's Schema vtable group (anvil_schema_vtable.h's anvil_schema_i). Field order
matches the C struct exactly; tests/test_vtable_drift.py checks it against the real header. Generated from
the header, then reviewed."""
import ctypes as C

from ._buffer import read_string
from ._lib import LIB
from .value import Numeric, _NumericRaw

class _SchemaOptionsRaw(C.Structure):
    """Mirrors anvil_schema_options (anvil_schema.h). `size` is the caller's sizeof, so the struct can
    grow at the end without breaking compiled callers."""

    _fields_ = [
        ("size", C.c_size_t),
        ("skip_required", C.c_bool),
        ("allow_unknown", C.c_bool),
    ]



class _SchemaRaw(C.Structure):
    _fields_ = [
        ("load", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("dispose", C.CFUNCTYPE(None, C.c_void_p)),
        ("validate", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.c_void_p)),
        ("validate_value", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.c_void_p, C.POINTER(_SchemaOptionsRaw))),
        ("get_violation_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_violation", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("violation_get_category", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("violation_get_field", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("violation_get_message", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_diagnostic_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_diagnostic", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("diagnostic_get_category", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("diagnostic_get_type_category", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("diagnostic_get_field", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("diagnostic_get_message", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_field_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_field", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("find_field", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("field_get_name", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("field_get_kind", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("field_get_type_name", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("field_is_required", C.CFUNCTYPE(C.c_bool, C.c_void_p)),
        ("field_is_nullable", C.CFUNCTYPE(C.c_bool, C.c_void_p)),
        ("field_is_integer", C.CFUNCTYPE(C.c_bool, C.c_void_p)),
        ("field_get_size", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("field_get_min_numeric", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(_NumericRaw))),
        ("field_get_max_numeric", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(_NumericRaw))),
        ("field_get_min_items", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("field_get_max_items", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("field_get_value_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("field_get_value", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_size_t, C.c_char_p, C.c_size_t)),
        ("field_get_format", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("field_get_tag", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("field_get_nested_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("field_get_nested", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("field_find_nested", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("field_get_items", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("field_get_extra_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("field_get_extra_name", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_size_t, C.c_char_p, C.c_size_t)),
        ("field_get_extra_value", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
    ]

_vt = _SchemaRaw.in_dll(LIB, "Schema")

def load(doc: int) -> int | None:
    return _vt.load(doc)

def dispose(schema: int) -> None:
    _vt.dispose(schema)

def validate(schema: int, data_doc: int) -> bool:
    return _vt.validate(schema, data_doc)

def validate_value(schema: int, object_value: int, opts: int) -> bool:
    return _vt.validate_value(schema, object_value, opts)

def get_violation_count(schema: int) -> int:
    return _vt.get_violation_count(schema)

def get_violation(schema: int, index: int) -> int | None:
    return _vt.get_violation(schema, index)

def violation_get_category(v: int) -> int:
    return _vt.violation_get_category(v)

def violation_get_field(v) -> str:
    return read_string(lambda buf, buflen: _vt.violation_get_field(v, buf, buflen))

def violation_get_message(v) -> str:
    return read_string(lambda buf, buflen: _vt.violation_get_message(v, buf, buflen))

def get_diagnostic_count(schema: int) -> int:
    return _vt.get_diagnostic_count(schema)

def get_diagnostic(schema: int, index: int) -> int | None:
    return _vt.get_diagnostic(schema, index)

def diagnostic_get_category(diag: int) -> int:
    return _vt.diagnostic_get_category(diag)

def diagnostic_get_type_category(diag: int) -> int:
    return _vt.diagnostic_get_type_category(diag)

def diagnostic_get_field(diag) -> str:
    return read_string(lambda buf, buflen: _vt.diagnostic_get_field(diag, buf, buflen))

def diagnostic_get_message(diag) -> str:
    return read_string(lambda buf, buflen: _vt.diagnostic_get_message(diag, buf, buflen))

def get_field_count(schema: int) -> int:
    return _vt.get_field_count(schema)

def get_field(schema: int, index: int) -> int | None:
    return _vt.get_field(schema, index)

def find_field(schema: int, name: bytes) -> int | None:
    return _vt.find_field(schema, name)

def field_get_name(field) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_name(field, buf, buflen))

def field_get_kind(field: int) -> int:
    return _vt.field_get_kind(field)

def field_get_type_name(field) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_type_name(field, buf, buflen))

def field_is_required(field: int) -> bool:
    return _vt.field_is_required(field)

def field_is_nullable(field: int) -> bool:
    return _vt.field_is_nullable(field)

def field_is_integer(field: int) -> bool:
    return _vt.field_is_integer(field)

def field_get_size(field) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.field_get_size(field, C.byref(out)) else None

def field_get_min_numeric(field) -> Numeric | None:
    out = _NumericRaw()
    if not _vt.field_get_min_numeric(field, C.byref(out)):
        return None
    return Numeric(bool(out.is_integral), bool(out.overflowed), out.as_int64, out.as_double)

def field_get_max_numeric(field) -> Numeric | None:
    out = _NumericRaw()
    if not _vt.field_get_max_numeric(field, C.byref(out)):
        return None
    return Numeric(bool(out.is_integral), bool(out.overflowed), out.as_int64, out.as_double)

def field_get_min_items(field) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.field_get_min_items(field, C.byref(out)) else None

def field_get_max_items(field) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.field_get_max_items(field, C.byref(out)) else None

def field_get_value_count(field: int) -> int:
    return _vt.field_get_value_count(field)

def field_get_value(field, index) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_value(field, index, buf, buflen))

def field_get_format(field) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_format(field, buf, buflen))

def field_get_tag(field) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_tag(field, buf, buflen))

def field_get_nested_count(field: int) -> int:
    return _vt.field_get_nested_count(field)

def field_get_nested(field: int, index: int) -> int | None:
    return _vt.field_get_nested(field, index)

def field_find_nested(field: int, name: bytes) -> int | None:
    return _vt.field_find_nested(field, name)

def field_get_items(field: int) -> int | None:
    return _vt.field_get_items(field)

def field_get_extra_count(field: int) -> int:
    return _vt.field_get_extra_count(field)

def field_get_extra_name(field, index) -> str:
    return read_string(lambda buf, buflen: _vt.field_get_extra_name(field, index, buf, buflen))

def field_get_extra_value(field: int, index: int) -> int | None:
    return _vt.field_get_extra_value(field, index)
