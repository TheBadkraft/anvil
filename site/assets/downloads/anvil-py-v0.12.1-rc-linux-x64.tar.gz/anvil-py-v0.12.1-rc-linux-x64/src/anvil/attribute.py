"""One @[key]/@[key=value] attribute, attached either to a document's header (module-level) or
to an individual statement. Lifetime is tied to the owning AnvilDocument; never valid after it's
disposed. `value` is the raw source text; `decoded_value` is the same attribute read as a typed value.
"""
from anvil._native import attribute as native_attribute
from anvil.value import AnvlValue


class AnvilAttribute:
    def __init__(self, handle: int):
        self._handle = handle

    @property
    def key(self) -> str:
        return native_attribute.get_key(self._handle)

    @property
    def value(self) -> str | None:
        return native_attribute.get_value(self._handle)

    @property
    def decoded_value(self) -> "AnvlValue | None":
        """The value read as a value: escapes resolved, delimiters stripped, and typed, so
        `status="done"` is a STRING "done", `n=42` a NUMERIC 42, and `type=bug` a BARE "bug". `value`
        stays the raw source text (a quoted string keeps its quotes). None for a flag attribute
        (`@[active]`), which has no value; an explicit `@[x=null]` is a NULL value, which is not the
        same thing. A value the scalar grammar does not accept whole (`@[range=1..5]`) is a BARE value
        of its raw text. Like every AnvlValue it is valid while the owning document is not disposed."""
        handle = native_attribute.get_value_handle(self._handle)
        return None if handle is None else AnvlValue(handle)
