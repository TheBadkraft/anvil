from enum import IntEnum


class AnvilDialect(IntEnum):
    """Which dialect a writer or builder emits, and therefore which grammar it enforces. Mirrors
    anvil_writer_dialect (anvil_writer_types.h) exactly, including the values."""

    AML = 0  # #!aml -- declarative data; the full grammar
    AMP = 1  # #!amp -- messaging; scalar-only arrays/tuples, no attributes/objects/base/include
