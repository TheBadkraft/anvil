"""One parsed value -- a scalar, an array/tuple, or an object. Lifetime is tied to the owning
AnvilDocument; never valid after it's disposed. Navigation is lazy: every accessor is a direct
native call, nothing eagerly materialized.
"""
from anvil._native import value as native_value
from anvil.value_type import ValueType


class AnvlValue:
    def __init__(self, handle: int):
        self._handle = handle
        # Lazy, per-key memoization -- built one entry at a time as keys are actually looked up,
        # not an eager full-map build. native_value.find_statement already does the scan natively
        # in C (one call, no per-candidate marshaling); this cache makes every *repeated* lookup
        # of the same key free on top of that. Maps key -> AnvlStatement | None, matching
        # anvil.net's AnvlValue._fieldCache exactly.
        self._field_cache: "dict[str, AnvlStatement | None]" = {}

    @property
    def type(self) -> ValueType:
        return native_value.get_type(self._handle)

    @property
    def count(self) -> int:
        return native_value.get_count(self._handle)

    def __getitem__(self, index):
        if isinstance(index, str):
            stmt = self._find_field_statement(index)
            return None if stmt is None else stmt.value
        handle = native_value.get_element(self._handle, index)
        return None if handle is None else AnvlValue(handle)

    def has(self, key: str) -> bool:
        """Shares the same lazy cache as the string indexer above."""
        return self._find_field_statement(key) is not None

    def _find_field_statement(self, key: str):
        if key not in self._field_cache:
            # Deferred import: AnvlStatement.value will need AnvlValue right back, a genuine
            # mutual reference between the two wrapper types (matching anvil.net's own
            # AnvlValue <-> AnvlStatement relationship) -- resolved at call time, not at module
            # load time, so neither module needs the other before it's fully defined.
            from anvil.statement import AnvlStatement

            handle = native_value.find_statement(self._handle, key.encode("utf-8"))
            self._field_cache[key] = None if handle is None else AnvlStatement(handle)
        return self._field_cache[key]

    def entries(self):
        """Every field of an object, in declaration order. Empty for a non-object value."""
        for i in range(self.count):
            handle = native_value.get_statement(self._handle, i)
            if handle is None:
                continue
            stmt = self._statement(handle)
            value = stmt.value
            if value is not None:
                yield stmt.name, value

    @staticmethod
    def _statement(handle: int):
        from anvil.statement import AnvlStatement

        return AnvlStatement(handle)

    def _text(self) -> str:
        """The decoded string value (anvil_value_get_text): escapes resolved for a STRING."""
        return native_value.get_text(self._handle)

    def _numeric(self):
        """The native numeric read, or None for a non-NUMERIC value."""
        return native_value.get_numeric(self._handle) if self.type == ValueType.NUMERIC else None

    def as_string(self) -> str | None:
        """Text of a `STRING` or `BARE` (unquoted literal) value; `None` for any other kind."""
        return self._text() if self.type in (ValueType.STRING, ValueType.BARE) else None

    def as_bool(self) -> bool | None:
        return native_value.get_bytes(self._handle) == b"true" if self.type == ValueType.BOOL else None

    def as_int(self) -> int | None:
        """A `NUMERIC` value as an int; `None` for any other kind. Exact for every integral
        literal -- past int64 too, since Python ints are unbounded (the one place this differs from
        a fixed-width binding, which must return None there). A decimal or exponent literal is
        truncated toward zero; `None` when it overflows a double (`1e+999`), and for an integer
        literal longer than Python's own int-conversion digit limit (see
        sys.set_int_max_str_digits) -- numeric_text() always has the exact text."""
        n = self._numeric()
        if n is None:
            return None
        if n.is_integral:
            if not n.overflowed:
                return n.as_int64
            try:
                return int(self.numeric_text())
            except ValueError:
                return None
        return None if n.overflowed else int(n.as_double)

    def as_float(self) -> float | None:
        """A `NUMERIC` value as the nearest float (an integer beyond 2**53 is rounded; use
        as_int() or numeric_text() to keep it exact); `None` for any other kind. A value too large
        for a double is parsed from its text and may come back as an infinity."""
        n = self._numeric()
        if n is None:
            return None
        if n.overflowed:
            return float(self.numeric_text())
        return float(n.as_int64) if n.is_integral else n.as_double

    def numeric_text(self) -> str | None:
        """The exact source text of a `NUMERIC` value (e.g. "007", "1e+3", or a bignum),
        uninterpreted; `None` for any other kind."""
        if self.type != ValueType.NUMERIC:
            return None
        return native_value.get_bytes(self._handle).decode("ascii")

    def is_integral(self) -> bool | None:
        """Whether a `NUMERIC` value was authored as an integer (no `.` and no exponent), so an
        int-vs-float distinction survives a read and re-emit. True even when the value is too large
        for an int64. `None` for any other kind."""
        n = self._numeric()
        return None if n is None else n.is_integral

    def raw_bytes(self) -> bytes | None:
        """The exact source span of any scalar value (`NULL`, `BOOL`, `NUMERIC`, `STRING`, `BLOB`,
        `BARE`), uninterpreted: a string's escape sequences stay as written (unlike as_string(),
        which returns the decoded value), a number is its literal text, a blob is its bytes. Empty
        (never None) for an empty value; `None` for an array, tuple or object, whose source span
        would misrepresent the resolved value. Wraps native `anvil_value_get_bytes`, the primitive
        the other readers are views of."""
        if self.type in (ValueType.ARRAY, ValueType.TUPLE, ValueType.OBJECT):
            return None
        return native_value.get_bytes(self._handle)

    def as_bytes(self) -> bytes | None:
        """The exact content bytes of a blob; `None` for any other kind (empty for an empty blob).
        Blob content is arbitrary bytes, not necessarily text, so it is deliberately not offered
        through as_string()."""
        return native_value.get_bytes(self._handle) if self.type == ValueType.BLOB else None

    def blob_tag(self) -> str | None:
        """The tag of a blob (the `date` in `@date`2026-07-07``), or `None` for an untagged blob
        and for every other kind. The tag is not part of the content: as_bytes() returns only what
        is between the backticks."""
        if self.type != ValueType.BLOB:
            return None
        return native_value.get_blob_tag(self._handle) or None
