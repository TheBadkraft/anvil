"""An exact numeric bound, as Anvil Native reads it (anvil_numeric_t)."""
from dataclasses import dataclass


@dataclass(frozen=True)
class AnvilNumeric:
    """An exact numeric bound. Exactly one of the integer and float readings is meaningful, and only
    when not `overflowed`: a bound that doesn't fit is reported as such, never saturated or wrapped.
    Python ints are unbounded, but native reads a bound as int64/double, so this reports what native
    could represent."""

    is_integral: bool
    overflowed: bool
    _as_int64: int
    _as_double: float

    @classmethod
    def _from_native(cls, n) -> "AnvilNumeric":
        return cls(n.is_integral, n.overflowed, n.as_int64, n.as_double)

    def as_int(self) -> "int | None":
        """The value as an int: only for an integral value that fits; None otherwise."""
        return self._as_int64 if self.is_integral and not self.overflowed else None

    def as_float(self) -> "float | None":
        """The value as a float: exact for a fractional bound, the nearest float for an integral one.
        None when it overflowed."""
        if self.overflowed:
            return None
        return float(self._as_int64) if self.is_integral else self._as_double
