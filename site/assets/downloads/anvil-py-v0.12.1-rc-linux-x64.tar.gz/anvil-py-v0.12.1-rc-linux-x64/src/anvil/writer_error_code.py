from enum import IntEnum

from anvil._native import writer as native_writer


class WriterErrorCode(IntEnum):
    """The writer/builder's stable error categories. Mirrors anvil_writer_err_code
    (anvil_writer_types.h) exactly, including the values -- independent of the reader's
    ErrorCode."""

    OK = 0
    INVALID_ARGUMENT = 1
    MEMORY = 2
    STATE = 3
    DIALECT = 4
    INVALID_IDENTIFIER = 5
    RESERVED_WORD = 6
    INVALID_NUMERIC = 7
    INVALID_BARE = 8
    INVALID_BLOB = 9
    INVALID_ATTRIBUTE_VALUE = 10
    INVALID_INCLUDE_PATH = 11
    EMPTY_COLLECTION = 12
    INHERITANCE_REQUIRES_OBJECT = 13
    UNFINISHED = 14
    DUPLICATE_NAME = 15
    DEPTH_EXCEEDED = 16

    @property
    def message(self) -> str:
        """Anvil Native's own human-readable text for this code."""
        return native_writer.error_message(self.value)
