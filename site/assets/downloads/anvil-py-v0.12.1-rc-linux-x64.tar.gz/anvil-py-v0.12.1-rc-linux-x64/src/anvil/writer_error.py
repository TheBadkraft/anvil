from anvil.writer_error_code import WriterErrorCode


class AnvilWriterError(Exception):
    """A writer or builder call was rejected by Anvil Native. Carries the native WriterErrorCode
    as .code; the message is the native text for it."""

    def __init__(self, code: WriterErrorCode):
        super().__init__(f"{code.message} ({code.name})")
        self.code = code
