from enum import IntEnum


class TypeDiagnosticCode(IntEnum):
    """What a type registry reports while loading. Mirrors anvil_type_diag_code (anvil_type_registry.h)
    exactly, including the values. The registry reports; whether a diagnostic is fatal is the consumer's call."""

    NONE = 0
    NAME_COLLISION = 1
    UNKNOWN_BASE_TYPE = 2
    MALFORMED_CONSTRAINT = 3
    MALFORMED_ENUM_VALUES = 4
