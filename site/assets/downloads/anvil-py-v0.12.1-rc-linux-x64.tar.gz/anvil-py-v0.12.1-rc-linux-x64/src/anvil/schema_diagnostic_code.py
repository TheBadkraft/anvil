from enum import IntEnum


class SchemaDiagnosticCode(IntEnum):
    """What a schema reports while loading. Mirrors anvil_schema_diag_code (anvil_schema.h) exactly,
    including the values. The schema reports; whether a diagnostic is fatal is the consumer's call."""

    NONE = 0
    UNKNOWN_TYPE = 1
    MALFORMED_CONSTRAINT = 2
    RULE_NOT_OBJECT = 3
    UNKNOWN_FORMAT = 4
    SELF_REFERENCE = 5
    CONFLICTING_CONSTRAINTS = 6
    TYPE_REGISTRY = 7
