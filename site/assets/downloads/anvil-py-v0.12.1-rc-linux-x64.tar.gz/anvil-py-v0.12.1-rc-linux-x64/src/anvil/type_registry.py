"""The named types of one or more @[types] documents, over Anvil Native's type registry
(anvil_type_registry.h). A registry is a self-contained copy: it stays valid after the AnvilDocument it
was loaded from is disposed. Dispose it when done (it is a context manager); every TypeDef it returned
is a view tied to it, and raises RuntimeError once it is disposed.
"""
from dataclasses import dataclass

from anvil import _args
from anvil._native import type_registry as native
from anvil.document import AnvilDocument
from anvil.numeric import AnvilNumeric
from anvil.type_diagnostic_code import TypeDiagnosticCode
from anvil.type_kind import TypeKind


@dataclass(frozen=True)
class TypeDiagnostic:
    """A diagnostic the registry reported while loading: a snapshot, independent of its lifetime."""

    code: TypeDiagnosticCode
    name: str
    source: str
    message: str


def _require_document(document) -> int:
    if not isinstance(document, AnvilDocument):
        raise TypeError(f"document must be AnvilDocument, not {type(document).__name__}")
    return document._live_handle


def _bound(numeric: "AnvilNumeric | None"):
    """A bound as a plain number: an int when integral, a float otherwise; None when undeclared or overflowed."""
    if numeric is None or numeric.overflowed:
        return None
    return numeric.as_int() if numeric.is_integral else numeric.as_float()


def _numeric(raw) -> "AnvilNumeric | None":
    return None if raw is None else AnvilNumeric._from_native(raw)


class AnvilTypeRegistry:
    def __init__(self, handle: int):
        self._handle = handle
        self._disposed = False

    @classmethod
    def load(cls, document: AnvilDocument) -> "AnvilTypeRegistry | None":
        """Builds a registry from a document's own top-level statements. The document must carry the
        @[types] module attribute; returns None if it doesn't."""
        handle = native.load(_require_document(document))
        return None if handle is None else cls(handle)

    @classmethod
    def from_includes(cls, document: AnvilDocument) -> "AnvilTypeRegistry | None":
        """Builds a registry from a document's include graph (the types.X namespace); the document itself
        needn't carry @[types]. A name defined by two included documents is a NAME_COLLISION diagnostic and
        the later one wins; the consumer document may itself report that collision as a load error, and the
        registry is built regardless."""
        handle = native.load_from_includes(_require_document(document))
        return None if handle is None else cls(handle)

    def _live(self) -> int:
        if self._disposed:
            raise RuntimeError("AnvilTypeRegistry used after dispose()")
        return self._handle

    def find(self, name: str) -> "TypeDef | None":
        """The registry's own definition of `name`, or None."""
        handle = self._live()
        found = native.find(handle, _args.required(name, "name"))
        return None if found is None else TypeDef(self, found)

    def resolve(self, name: str) -> "TypeDef | None":
        """As find(), but also answers for the built-in types (Numeric, String, ...)."""
        handle = self._live()
        found = native.resolve(handle, _args.required(name, "name"))
        return None if found is None else TypeDef(self, found)

    @property
    def diagnostics(self) -> "list[TypeDiagnostic]":
        """What the registry reported while loading; whether any of it is fatal is the caller's call."""
        handle = self._live()
        result = []
        for i in range(native.get_diagnostic_count(handle)):
            d = native.get_diagnostic(handle, i)
            result.append(
                TypeDiagnostic(
                    TypeDiagnosticCode(native.diagnostic_get_category(d)),
                    native.diagnostic_get_name(d),
                    native.diagnostic_get_source(d),
                    native.diagnostic_get_message(d),
                )
            )
        return result

    def dispose(self) -> None:
        if self._disposed:
            return
        native.dispose(self._handle)
        self._disposed = True

    def __enter__(self) -> "AnvilTypeRegistry":
        return self

    def __exit__(self, *exc_info) -> None:
        self.dispose()


class TypeDef:
    """One type definition: a view tied to the AnvilTypeRegistry it came from. Constraints the type
    doesn't declare are None (or an empty list), never a default."""

    def __init__(self, registry: AnvilTypeRegistry, handle: int):
        self._registry = registry
        self._handle = handle

    def _live(self) -> int:
        self._registry._live()
        return self._handle

    @property
    def kind(self) -> TypeKind:
        return TypeKind(native.def_get_kind(self._live()))

    @property
    def size(self) -> "int | None":
        """The declared size."""
        return native.def_get_size(self._live())

    @property
    def min_numeric(self) -> "AnvilNumeric | None":
        """The declared min, read exactly (integer or fractional); None when not declared."""
        return _numeric(native.def_get_min_numeric(self._live()))

    @property
    def max_numeric(self) -> "AnvilNumeric | None":
        return _numeric(native.def_get_max_numeric(self._live()))

    @property
    def min(self):
        """The declared min as an int (integral) or float (fractional); None when not declared or too
        large for native to read (see min_numeric.overflowed)."""
        return _bound(self.min_numeric)

    @property
    def max(self):
        return _bound(self.max_numeric)

    @property
    def format(self) -> "str | None":
        """The declared format (for example iso8601_datetime), or None."""
        return native.def_get_format(self._live()) or None

    @property
    def values(self) -> "list[str]":
        """An enum's labels in declaration order; empty for any other kind."""
        handle = self._live()
        return [native.def_get_value(handle, i) for i in range(native.def_get_value_count(handle))]
