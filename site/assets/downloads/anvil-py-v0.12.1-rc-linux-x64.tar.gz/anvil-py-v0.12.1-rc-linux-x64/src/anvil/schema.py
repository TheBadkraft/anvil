"""A document's @[schema] rules, over Anvil Native's schema (anvil_schema.h). A schema is a
self-contained copy: it stays valid after the AnvilDocument (and any included @[types] documents) it was
loaded from are disposed. Dispose it when done (it is a context manager); every SchemaField it returned is
a view tied to it, and raises RuntimeError once it is disposed.
"""
import ctypes as C
from dataclasses import dataclass, field

from anvil import _args
from anvil._native import schema as native
from anvil.document import AnvilDocument
from anvil.numeric import AnvilNumeric
from anvil.schema_diagnostic_code import SchemaDiagnosticCode
from anvil.schema_violation_code import SchemaViolationCode
from anvil.type_diagnostic_code import TypeDiagnosticCode
from anvil.type_kind import TypeKind
from anvil.type_registry import _bound, _numeric, _require_document
from anvil.value import AnvlValue


@dataclass(frozen=True)
class SchemaViolation:
    """One validation failure. `field` is the path of the offending field (empty for the value as a whole)."""

    code: SchemaViolationCode
    field: str
    message: str


@dataclass(frozen=True)
class SchemaValidation:
    """The outcome of one validation: a snapshot, independent of the schema's lifetime and of any later
    call (Anvil Native replaces its own violation list on every validation; this does not)."""

    is_valid: bool
    violations: "list[SchemaViolation]" = field(default_factory=list)


@dataclass(frozen=True)
class SchemaDiagnostic:
    """A diagnostic the schema reported while loading: a snapshot. `type_code` is the type-registry
    diagnostic behind it when `code` is TYPE_REGISTRY, otherwise TypeDiagnosticCode.NONE."""

    code: SchemaDiagnosticCode
    type_code: TypeDiagnosticCode
    field: str
    message: str


@dataclass(frozen=True)
class SchemaExtra:
    """An extension key on a rule (one the schema doesn't interpret, such as FlyWire's `pooled`). `value`
    is a copy owned by the schema: valid until the schema is disposed, and never disposed by the caller."""

    name: str
    value: AnvlValue


class AnvilSchema:
    def __init__(self, handle: int):
        self._handle = handle
        self._disposed = False

    @classmethod
    def load(cls, document: AnvilDocument) -> "AnvilSchema | None":
        """Builds a schema from a document carrying @[schema]; None if it doesn't."""
        handle = native.load(_require_document(document))
        return None if handle is None else cls(handle)

    def _live(self) -> int:
        if self._disposed:
            raise RuntimeError("AnvilSchema used after dispose()")
        return self._handle

    # ---- validation ----

    def validate(self, data: AnvilDocument) -> SchemaValidation:
        """Validates a data document's top-level statements against the schema."""
        handle = self._live()
        valid = native.validate(handle, _require_document(data))
        return self._snapshot(handle, valid)

    def validate_value(
        self, object_value: AnvlValue, *, skip_required: bool = False, allow_unknown: bool = False
    ) -> SchemaValidation:
        """Validates an object value's statements as if they were a document's top level: the form a
        request body takes (set := { ... };). `skip_required` gives patch semantics; `allow_unknown`
        ignores fields the schema doesn't declare."""
        handle = self._live()
        if not isinstance(object_value, AnvlValue):
            raise TypeError(f"object_value must be AnvlValue, not {type(object_value).__name__}")
        options = native._SchemaOptionsRaw(C.sizeof(native._SchemaOptionsRaw), skip_required, allow_unknown)
        valid = native.validate_value(handle, object_value._handle, C.byref(options))
        return self._snapshot(handle, valid)

    def validate_field(
        self,
        document: "AnvilDocument | str | bytes",
        name: str,
        *,
        skip_required: bool = False,
        allow_unknown: bool = False,
    ) -> SchemaValidation:
        """Finds the top-level statement `name` in `document` (ANVL text, or an AnvilDocument you already
        loaded) and validates its object value: validate_value() for a request body you hold as ANVL text.
        An absent statement is one REQUIRED violation with an empty field; one that isn't an object is the
        native TYPE_MISMATCH. Raises ValueError if the text doesn't parse.

        Text identical to a document you already hold loads independently of it."""
        self._live()
        _args.required(name, "name")
        if isinstance(document, AnvilDocument):
            return self._validate_field_in(document, name, skip_required, allow_unknown)
        if not isinstance(document, (str, bytes, bytearray)):
            raise TypeError(f"document must be AnvilDocument, str or bytes, not {type(document).__name__}")
        doc = AnvilDocument.load_buffer(document if isinstance(document, str) else bytes(document))
        if doc is None:
            raise ValueError("Anvil Native could not load the document text")
        with doc:
            if doc.has_errors:
                raise ValueError(self._load_failure(doc))
            return self._validate_field_in(doc, name, skip_required, allow_unknown)

    @staticmethod
    def _load_failure(doc: AnvilDocument) -> str:
        error = doc.error
        if error is None:
            return "the document text has errors"
        return f"{error.message} (line {error.line}, column {error.column})"

    def _validate_field_in(self, doc: AnvilDocument, name: str, skip_required: bool, allow_unknown: bool):
        value = doc.find_value(name)
        if value is None:
            return SchemaValidation(
                False,
                [SchemaViolation(SchemaViolationCode.REQUIRED, "", f"statement '{name}' is not present")],
            )
        return self.validate_value(value, skip_required=skip_required, allow_unknown=allow_unknown)

    # Anvil Native replaces its violation list on every validation, so copy it out immediately.
    @staticmethod
    def _snapshot(schema: int, valid: bool) -> SchemaValidation:
        violations = []
        for i in range(native.get_violation_count(schema)):
            v = native.get_violation(schema, i)
            violations.append(
                SchemaViolation(
                    SchemaViolationCode(native.violation_get_category(v)),
                    native.violation_get_field(v),
                    native.violation_get_message(v),
                )
            )
        return SchemaValidation(valid, violations)

    # ---- diagnostics ----

    @property
    def diagnostics(self) -> "list[SchemaDiagnostic]":
        """What the schema reported while loading; whether any of it is fatal is the caller's call."""
        handle = self._live()
        result = []
        for i in range(native.get_diagnostic_count(handle)):
            d = native.get_diagnostic(handle, i)
            result.append(
                SchemaDiagnostic(
                    SchemaDiagnosticCode(native.diagnostic_get_category(d)),
                    TypeDiagnosticCode(native.diagnostic_get_type_category(d)),
                    native.diagnostic_get_field(d),
                    native.diagnostic_get_message(d),
                )
            )
        return result

    # ---- introspection ----

    @property
    def fields(self) -> "list[SchemaField]":
        """The schema's top-level rules, in declaration order."""
        handle = self._live()
        return [SchemaField(self, native.get_field(handle, i)) for i in range(native.get_field_count(handle))]

    def find_field(self, name: str) -> "SchemaField | None":
        """The top-level rule named `name`, or None."""
        handle = self._live()
        found = native.find_field(handle, _args.required(name, "name"))
        return None if found is None else SchemaField(self, found)

    def dispose(self) -> None:
        if self._disposed:
            return
        native.dispose(self._handle)
        self._disposed = True

    def __enter__(self) -> "AnvilSchema":
        return self

    def __exit__(self, *exc_info) -> None:
        self.dispose()


class SchemaField:
    """One schema rule: a view tied to the AnvilSchema it came from. Everything it inherits from a
    types.X type is already folded in. Constraints the rule doesn't declare are None (or an empty list),
    never a default."""

    def __init__(self, schema: AnvilSchema, handle: int):
        self._schema = schema
        self._handle = handle

    def _live(self) -> int:
        self._schema._live()
        return self._handle

    @property
    def name(self) -> str:
        """The rule's name; empty for an array rule's `items` rule."""
        return native.field_get_name(self._live())

    @property
    def kind(self) -> TypeKind:
        return TypeKind(native.field_get_kind(self._live()))

    @property
    def type_name(self) -> str:
        """The `type :=` value as written (for example types.Id32); empty when none."""
        return native.field_get_type_name(self._live())

    @property
    def is_required(self) -> bool:
        return native.field_is_required(self._live())

    @property
    def is_nullable(self) -> bool:
        return native.field_is_nullable(self._live())

    @property
    def is_integer(self) -> bool:
        return native.field_is_integer(self._live())

    @property
    def size(self) -> "int | None":
        return native.field_get_size(self._live())

    @property
    def min_numeric(self) -> "AnvilNumeric | None":
        """The effective min, read exactly; None when not declared."""
        return _numeric(native.field_get_min_numeric(self._live()))

    @property
    def max_numeric(self) -> "AnvilNumeric | None":
        return _numeric(native.field_get_max_numeric(self._live()))

    @property
    def min(self):
        """The effective min as an int (integral) or float (fractional); None when not declared or too
        large for native to read (see min_numeric.overflowed)."""
        return _bound(self.min_numeric)

    @property
    def max(self):
        return _bound(self.max_numeric)

    @property
    def min_items(self) -> "int | None":
        return native.field_get_min_items(self._live())

    @property
    def max_items(self) -> "int | None":
        return native.field_get_max_items(self._live())

    @property
    def values(self) -> "list[str]":
        """An enum rule's labels in declaration order; empty for any other kind."""
        handle = self._live()
        return [native.field_get_value(handle, i) for i in range(native.field_get_value_count(handle))]

    @property
    def format(self) -> "str | None":
        return native.field_get_format(self._live()) or None

    @property
    def tag(self) -> "str | None":
        """The required blob tag, or None."""
        return native.field_get_tag(self._live()) or None

    @property
    def nested(self) -> "list[SchemaField]":
        """An object rule's nested rules, in declaration order; empty for any other rule."""
        handle = self._live()
        return [
            SchemaField(self._schema, native.field_get_nested(handle, i))
            for i in range(native.field_get_nested_count(handle))
        ]

    def find_nested(self, name: str) -> "SchemaField | None":
        handle = self._live()
        found = native.field_find_nested(handle, _args.required(name, "name"))
        return None if found is None else SchemaField(self._schema, found)

    @property
    def items(self) -> "SchemaField | None":
        """An array rule's element rule; None for any other rule."""
        found = native.field_get_items(self._live())
        return None if found is None else SchemaField(self._schema, found)

    @property
    def extras(self) -> "list[SchemaExtra]":
        """The rule's extension keys (anything it declares that the schema doesn't interpret), in order."""
        handle = self._live()
        return [
            SchemaExtra(
                native.field_get_extra_name(handle, i),
                AnvlValue(native.field_get_extra_value(handle, i)),
            )
            for i in range(native.field_get_extra_count(handle))
        ]
