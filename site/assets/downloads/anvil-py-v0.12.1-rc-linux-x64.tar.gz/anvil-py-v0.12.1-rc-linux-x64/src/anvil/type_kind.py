from enum import IntEnum


class TypeKind(IntEnum):
    """The kind of value a type or schema rule describes. Mirrors anvil_type_kind (anvil_type_registry.h)
    exactly, including the values; tests/test_enum_drift.py checks it against the real header."""

    UNKNOWN = 0
    NUMERIC = 1
    STRING = 2
    BOOL = 3
    OBJECT = 4
    TUPLE = 5
    ARRAY = 6
    ENUM = 7
    BLOB = 8
