'use strict';
// Writes the anvil-dump format (vendor/anvil/conformance/FORMAT.md, version 1) from a load result. This is how the
// corpus and the fuzzer compare this reader with native: byte for byte.
const R = require('./reader');
const { CATEGORY_NAMES, NAMES } = require('./errors');
const { docOfNode } = require('./resolve');
const { latin1, hex, utf8Binary } = require('./bytes');

const TYPE_NAMES = [];
TYPE_NAMES[R.T_NONE] = 'NONE'; TYPE_NAMES[R.T_NULL] = 'NULL'; TYPE_NAMES[R.T_BOOL] = 'BOOL';
TYPE_NAMES[R.T_NUMERIC] = 'NUMERIC'; TYPE_NAMES[R.T_STRING] = 'STRING'; TYPE_NAMES[R.T_BLOB] = 'BLOB';
TYPE_NAMES[R.T_ARRAY] = 'ARRAY'; TYPE_NAMES[R.T_TUPLE] = 'TUPLE'; TYPE_NAMES[R.T_OBJECT] = 'OBJECT';
TYPE_NAMES[R.T_BARE] = 'BARE'; TYPE_NAMES[R.T_VARREF] = 'VARREF';
const DIALECT_NAMES = ['AML', 'AMP', 'ASL', 'ERROR'];
const HEX = '0123456789abcdef';

// binary strings (one char per byte) -> the quoted form
const QUOTE_RE = /[\\"\x00-\x1f\x7f-\xff]/g;
function quoteChar(c) {
   switch (c) {
   case '\\': return '\\\\';
   case '"': return '\\"';
   case '\n': return '\\n';
   case '\r': return '\\r';
   case '\t': return '\\t';
   default: {
      const k = c.charCodeAt(0);
      return '\\x' + HEX[k >> 4] + HEX[k & 15];
   }
   }
}
function quote(str) { return '"' + str.replace(QUOTE_RE, quoteChar) + '"'; }


// the escape resolution of anvil_value_get_text: \n \t \r \\ \" ; any other pair is kept as written
function decodeString(raw) {
   if (raw.indexOf('\\') < 0) return raw;
   let out = '';
   const len = raw.length;
   for (let i = 0; i < len; i++) {
      let c = raw[i];
      if (c === '\\' && i + 1 < len) {
         const d = raw[i + 1];
         let r = null;
         if (d === 'n') r = '\n'; else if (d === 't') r = '\t'; else if (d === 'r') r = '\r'; else if (d === '\\') r = '\\'; else if (d === '"') r = '"';
         if (r !== null) { c = r; i++; }
      }
      out += c;
   }
   return out;
}

const F64 = new Float64Array(1);
const U32 = new Uint32Array(F64.buffer);
const I64_MAX = 9223372036854775807n;

function numeric(text, float) {
   if (!float) {
      const neg = text.charCodeAt(0) === 45;
      let digits = neg ? text.slice(1) : text;
      let i = 0;
      while (i < digits.length - 1 && digits.charCodeAt(i) === 48) i++;
      digits = digits.slice(i);
      if (digits.length <= 15) return ` kind=integer overflow=0 i64=${neg ? (Number(digits) === 0 ? '0' : '-' + digits) : digits}`;
      const mag = BigInt(digits);
      if (mag > (neg ? I64_MAX + 1n : I64_MAX)) return ' kind=integer overflow=1';
      return ` kind=integer overflow=0 i64=${neg ? '-' + digits : digits}`;
   }
   const d = Number(text);
   if (!Number.isFinite(d)) return ' kind=float overflow=1';
   F64[0] = d;
   const hi = U32[1].toString(16).padStart(8, '0'), lo = U32[0].toString(16).padStart(8, '0');
   return ` kind=float overflow=0 f64=0x${hi}${lo}`;
}

function span(key, s, e) { return s < 0 ? ` ${key}=none` : ` ${key}=${s}-${e}`; }

class Dumper {
   constructor(res) {
      this.res = res;
      this.T = res.tree ? res.tree.T : null;
      this.out = [];
   }

   // a `value` record for node v of tree T over buf (also used for the decoded value of an attribute)
   value(T, v, buf, depth) {
      const pad = '  '.repeat(depth);
      const type = T[v];
      const s = T[v + 1], e = T[v + 2];
      let line = `${pad}value type=${TYPE_NAMES[type]} span=${s}-${e} text=${quote(latin1(buf, s, e))}`;
      switch (type) {
      case R.T_BOOL: line += ` bool=${buf[s] === 116 ? 'true' : 'false'}`; break;
      case R.T_NUMERIC: line += numeric(latin1(buf, s, e), T[v + 3]); break;
      case R.T_STRING: line += ` decoded=${quote(T[v + 3] ? decodeString(latin1(buf, s, e)) : latin1(buf, s, e))}`; break;
      case R.T_BLOB: {
         const ts = T[v + 3], te = T[v + 4];
         line += ` tag=${ts < 0 ? '""' : quote(latin1(buf, ts, te))}${span('tag-span', ts, te)} bytes=${hex(buf, s, e)}`;
         break;
      }
      case R.T_ARRAY: case R.T_TUPLE: line += ` count=${T[v + 7]}`; break;
      case R.T_OBJECT: line += ` count=${T[v + 7] + (this.res.inherited.has(v) ? this.res.inherited.get(v).length : 0)}`; break;
      case R.T_VARREF: {
         const target = T[v + 5];
         line += ` target=${quote(latin1(buf, T[v + 3], T[v + 4]))} public=${target >= 0 ? TYPE_NAMES[this.publicType(T[target])] : 'NULL'} resolved=${target >= 0 ? 1 : 0}`;
         if (target >= 0) line += ` resolved-doc=${docOfNode(this.res.docs, target)} resolved-span=${T[target + 1]}-${T[target + 2]}`;
         break;
      }
      default: break;
      }
      this.out.push(line + '\n');
      if (type === R.T_ARRAY || type === R.T_TUPLE) {
         for (let c = T[v + 5]; c >= 0; c = T[c + 6]) this.value(T, c, buf, depth + 1);
      } else if (type === R.T_OBJECT) {
         for (let c = T[v + 5]; c >= 0; c = T[c + 6]) this.statement(c, buf, depth + 1);
         const extra = this.res.inherited.get(v);
         if (extra) for (const c of extra) this.statement(c, this.res.docs[docOfNode(this.res.docs, c)].buf, depth + 1);
      }
   }

   // the type native's public accessors report for a value reached through a resolved reference
   publicType(type) {
      return type === R.T_NONE || type === R.T_VARREF ? R.T_NULL : type;
   }

   attr(a, buf, depth) {
      const A = this.res.tree.A;
      const pad = '  '.repeat(depth);
      const ks = A[a], ke = A[a + 1], vs = A[a + 2], ve = A[a + 3];
      let line = `${pad}attr key=${quote(latin1(buf, ks, ke))} key-span=${ks}-${ke} raw=${quote(latin1(buf, vs, ve))}`;
      if (ve === vs) {
         this.out.push(line + ' raw-span=none flag=1\n');
         return;
      }
      this.out.push(line + ` raw-span=${vs}-${ve} flag=0\n`);
      const scratch = R.decodeAttr(buf, vs, ve);
      this.value(scratch, 0, buf, depth + 1);
   }

   statement(s, buf, depth) {
      const T = this.T;
      const pad = '  '.repeat(depth);
      const kind = T[s] & 255, nattrs = T[s] >> 8;
      const ns = T[s + 1], ne = T[s + 2], bs = T[s + 3], be = T[s + 4];
      this.out.push(`${pad}stmt kind=${kind === R.S_BLOCK ? 'OBJECT_BLOCK' : 'ASSIGN'} name=${quote(latin1(buf, ns, ne))} name-span=${ns}-${ne} base=${bs < 0 ? '""' : quote(latin1(buf, bs, be))}${span('base-span', bs, be)} attrs=${nattrs}\n`);
      for (let i = 0, a = T[s + 7]; i < nattrs; i++, a += 4) this.attr(a, buf, depth + 1);
      if (T[s + 5] >= 0) this.value(T, T[s + 5], buf, depth + 1);
   }

   documents() {
      const res = this.res, T = this.T;
      // document order: a pre-order walk of the include graph, a document reached twice kept at its first index
      const order = [];
      const seen = new Set();
      const walk = (d) => {
         if (seen.has(d)) return;
         seen.add(d);
         order.push(d);
         for (const inc of d.includes) if (inc.resolved >= 0) walk(res.docs[inc.resolved]);
      };
      walk(res.root);
      const rp = res.root.path;
      const slash = rp.lastIndexOf('/');
      const dirPrefix = slash < 0 ? '' : rp.slice(0, slash + 1);
      for (let i = 0; i < order.length; i++) {
         const d = order[i];
         let path = d === res.root ? '<root>' : d.path;
         if (d !== res.root && dirPrefix && path.startsWith(dirPrefix)) path = path.slice(dirPrefix.length);
         this.out.push(`doc ${i} path=${quote(path)} dialect=${DIALECT_NAMES[d.dialect]} bytes=${d.n}\n`);
         for (let k = 0, a = d.attrFirst; k < d.attrCount; k++, a += 4) this.attr(a, d.buf, 1);
         for (const inc of d.includes) {
            this.out.push(`  include decl-span=${inc.declS}-${inc.declE} decl=${quote(latin1(d.buf, inc.declS, inc.declE))} path-span=${inc.pathS}-${inc.pathE} path=${quote(latin1(d.buf, inc.pathS, inc.pathE))} resolved=${inc.resolved < 0 ? 'none' : order.indexOf(res.docs[inc.resolved])}\n`);
         }
         for (let s = d.firstStmt; s >= 0; s = T[s + 6]) this.statement(s, d.buf, 1);
      }
   }
}

function header(mode, inputBytes, res) {
   let s = `anvil-dump 1\nmode ${mode}\ninput-bytes ${inputBytes}\nstatus ${res.ok ? 'ok' : 'error'}\n`;
   if (mode === 'document' && res.root) s += `dialect ${DIALECT_NAMES[res.root.dialect]}\n`;
   return s;
}

function errorRecord(err, category) {
   return `error code=${err.code} name=${NAMES[err.code] || 'ANVL_ERR_UNKNOWN'} category=${category} category-name=${CATEGORY_NAMES[category]} line=${err.line} column=${err.col} message=${quote(utf8Binary(err.message))}\n`;
}

// res from load(); inputBytes is the number of bytes the tool read
function dumpDocument(res, inputBytes) {
   let s = header('document', inputBytes, res);
   if (!res.ok) return s + errorRecord(res.err, res.category);
   const d = new Dumper(res);
   d.documents();
   return s + d.out.join('');
}

function dumpFragment(res, inputBytes) {
   let s = header('fragment', inputBytes, res);
   if (!res.ok) return s + errorRecord(res.err, res.category);
   const d = new Dumper(res);
   d.value(d.T, res.value, res.root.buf, 0);
   return s + d.out.join('');
}

// a root file native could not read: the load failed before anything was recorded
const IO_MESSAGES = { 1001: 'IO error reading source file', 1002: 'IO file not found', 1003: 'IO invalid file path' };
function dumpUnreadable(code) {
   return 'anvil-dump 1\nmode document\ninput-bytes 0\nstatus error\n' +
      `error code=${code} name=${NAMES[code]} category=1 category-name=ANVIL_ERR_IO line=0 column=0 message="${IO_MESSAGES[code]}"\n`;
}

module.exports = { dumpDocument, dumpFragment, dumpUnreadable, quote };
