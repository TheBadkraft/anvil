"""One declared statement -- a name, the value it's assigned, and its own @[...] attributes.
Lifetime is tied to the owning AnvilDocument; never valid after it's disposed.
"""
from anvil._native import statement as native_statement
from anvil.attribute import AnvilAttribute


class AnvlStatement:
    def __init__(self, handle: int):
        self._handle = handle
        self._attributes: list[AnvilAttribute] | None = None

    @property
    def name(self) -> str:
        return native_statement.get_name(self._handle)

    @property
    def value(self):
        from anvil.value import AnvlValue  # deferred: see AnvlValue's own note on this cycle

        handle = native_statement.get_value(self._handle)
        return None if handle is None else AnvlValue(handle)

    @property
    def attributes(self) -> list[AnvilAttribute]:
        if self._attributes is None:
            count = native_statement.get_attribute_count(self._handle)
            self._attributes = [
                AnvilAttribute(native_statement.get_attribute(self._handle, i)) for i in range(count)
            ]
        return self._attributes

    def find_attribute(self, key: str) -> AnvilAttribute | None:
        handle = native_statement.find_attribute(self._handle, key.encode("utf-8"))
        return None if handle is None else AnvilAttribute(handle)
