"""Binds Anvil Native's Error vtable group (anvil_vtable.h's anvil_error_i) -- rich diagnostic
detail (category/message/line/column) behind a document's recorded error."""
import ctypes as C

from anvil.error_code import ErrorCode

from ._buffer import read_string
from ._lib import LIB


class _ErrorRaw(C.Structure):
    _fields_ = [
        ("get_category", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("get_message", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_line", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_column", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
    ]


_vt = _ErrorRaw.in_dll(LIB, "Error")


def get_category(err: int) -> ErrorCode:
    return ErrorCode(_vt.get_category(err))


def get_message(err: int) -> str:
    return read_string(lambda buf, buflen: _vt.get_message(err, buf, buflen))


def get_line(err: int) -> int:
    return _vt.get_line(err)


def get_column(err: int) -> int:
    return _vt.get_column(err)
