"""Binds Anvil Native's top-level `Anvil` vtable group (anvil_vtable.h's `anvil_i`) -- the
ungrouped, document-lifecycle functions. Field order below matches `anvil_i` exactly; ctypes
computes each field's offset from the ones before it, so the layout must be complete and correct
even for fields this module doesn't wrap a Python-facing function for yet.

Resolved once, at import time, via `in_dll` -- reading a real `extern const` data symbol, the same
mechanism the vtable was documented to support for exactly this (FR-2609-anvl-public-api-001's own
vtable rationale names ctypes' `in_dll` alongside P/Invoke and Rust's `extern "C" { static ... }`).
Every call after that invokes the already-resolved function pointer directly through the struct's
field -- no per-call symbol lookup.
"""
import ctypes as C

from anvil.error_code import ErrorCode

from ._lib import LIB


class _AnvilRaw(C.Structure):
    _fields_ = [
        ("load", C.CFUNCTYPE(C.c_void_p, C.c_char_p)),
        ("load_buffer", C.CFUNCTYPE(C.c_void_p, C.c_char_p, C.c_size_t)),
        ("dispose", C.CFUNCTYPE(None, C.c_void_p)),
        ("has_errors", C.CFUNCTYPE(C.c_bool, C.c_void_p)),
        ("get_error", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("get_version", C.CFUNCTYPE(C.c_char_p)),
        ("parse_value_fragment", C.CFUNCTYPE(C.c_void_p, C.c_char_p, C.c_size_t)),
    ]


_vt = _AnvilRaw.in_dll(LIB, "Anvil")


def load(filepath: bytes) -> int | None:
    return _vt.load(filepath)


def load_buffer(source: bytes, length: int) -> int | None:
    return _vt.load_buffer(source, length)


def has_errors(doc: int) -> bool:
    return _vt.has_errors(doc)


def get_error(doc: int) -> ErrorCode:
    return ErrorCode(_vt.get_error(doc))


def dispose(doc: int) -> None:
    _vt.dispose(doc)


def parse_value_fragment(text: bytes, length: int) -> int | None:
    return _vt.parse_value_fragment(text, length)


def get_version() -> str:
    """The Anvil Native library version string, e.g. "0.8.0+135-rc".

    Not manual pointer-freeing territory the way C#'s automatic string marshaling was (that bug
    class doesn't apply here): ctypes' `c_char_p` restype only ever reads bytes at the returned
    address into a new Python `bytes` object -- it never calls `free()` on anything automatically,
    so a static, non-owned string literal (which is exactly what `anvil_get_version()` returns) is
    safe as-is, no special-casing needed.
    """
    return _vt.get_version().decode("utf-8")
