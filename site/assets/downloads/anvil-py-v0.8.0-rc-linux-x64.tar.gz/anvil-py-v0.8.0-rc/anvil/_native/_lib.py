"""The one shared libanvil.so handle every vtable-group module resolves its own struct against.

ctypes.CDLL("libanvil.so") relies on OS-default probing, which doesn't include either of this
library's own possible locations (confirmed empirically -- OSError, library not found, with no
env var set). Resolving an explicit absolute path is the ctypes equivalent of the fix the .NET
binding needed for the identical problem (NativeLibrary.Load's default search not covering a
sibling .so either).

Two real locations, checked in order: a packaged/distributed layout (runtimes/linux-x64/native/,
matching the RID-folder convention every other binding already uses) takes priority, falling back
to this dev checkout's own vendor/anvil build output when the packaged one isn't present.
"""
import ctypes as C
from pathlib import Path


def _resolve_lib_path(package_root: Path, repo_root: Path) -> Path:
    packaged = package_root / "runtimes" / "linux-x64" / "native" / "libanvil.so"
    if packaged.exists():
        return packaged

    vendored = repo_root / "vendor" / "anvil" / "lib" / "release" / "libanvil.so"
    if vendored.exists():
        return vendored

    raise FileNotFoundError(
        f"libanvil.so not found at {packaged} (packaged layout) or {vendored} "
        "(dev checkout) -- build it first: make -C vendor/anvil so-release"
    )


_THIS_FILE = Path(__file__).resolve()
LIB_PATH = _resolve_lib_path(package_root=_THIS_FILE.parents[1], repo_root=_THIS_FILE.parents[3])
LIB = C.CDLL(str(LIB_PATH))
