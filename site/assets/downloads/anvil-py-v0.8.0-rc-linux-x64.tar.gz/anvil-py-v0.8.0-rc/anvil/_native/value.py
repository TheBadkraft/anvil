"""Binds Anvil Native's Value vtable group (anvil_vtable.h's anvil_value_i)."""
import ctypes as C

from anvil.value_type import ValueType

from ._buffer import read_string
from ._lib import LIB


class _ValueRaw(C.Structure):
    _fields_ = [
        ("get_type", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("get_text", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_element", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("get_statement", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("find_statement", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
    ]


_vt = _ValueRaw.in_dll(LIB, "Value")


def get_type(val: int) -> ValueType:
    return ValueType(_vt.get_type(val))


def get_text(val: int) -> str:
    return read_string(lambda buf, buflen: _vt.get_text(val, buf, buflen))


def get_count(val: int) -> int:
    return _vt.get_count(val)


def get_element(val: int, index: int) -> int | None:
    return _vt.get_element(val, index)


def get_statement(val: int, index: int) -> int | None:
    return _vt.get_statement(val, index)


def find_statement(val: int, key: bytes) -> int | None:
    """One native call, every time -- no caching at this layer. The public wrapper's per-key
    memoization cache sits on top of this, not inside it (same division as anvil.net's
    AnvlValue vs. its own Anvil.Value.FindStatement)."""
    return _vt.find_statement(val, key)
