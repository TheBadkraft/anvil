"""Binds Anvil Native's Document vtable group (anvil_vtable.h's anvil_document_i). Field order
matches anvil_document_i exactly -- see _native/anvil.py's own module docstring for why the full
layout is declared even where only one field has a Python-facing wrapper so far."""
import ctypes as C

from ._lib import LIB


class _DocumentRaw(C.Structure):
    _fields_ = [
        ("get_attribute_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_attribute", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("find_attribute", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("find_statement", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("get_fragment_value", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("get_statements", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("get_includes", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("get_error", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
    ]


_vt = _DocumentRaw.in_dll(LIB, "Document")


def get_error(doc: int) -> int | None:
    return _vt.get_error(doc)


def find_statement(doc: int, name: bytes) -> int | None:
    return _vt.find_statement(doc, name)


def get_attribute_count(doc: int) -> int:
    return _vt.get_attribute_count(doc)


def get_attribute(doc: int, index: int) -> int | None:
    return _vt.get_attribute(doc, index)


def find_attribute(doc: int, key: bytes) -> int | None:
    return _vt.find_attribute(doc, key)


def get_statements(doc: int) -> int | None:
    return _vt.get_statements(doc)


def get_includes(doc: int) -> int | None:
    return _vt.get_includes(doc)


def get_fragment_value(doc: int) -> int | None:
    return _vt.get_fragment_value(doc)
