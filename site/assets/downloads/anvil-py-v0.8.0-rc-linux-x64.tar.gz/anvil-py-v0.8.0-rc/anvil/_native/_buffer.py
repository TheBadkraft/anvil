"""Shared helper for the buffer-sizing convention every text-returning native accessor shares
(documented on anvil_statement_get_name, reused identically by the rest): call once with a null
buffer to size it, once more to fill a buffer of exactly that size, +1 for the NUL terminator the
native side also writes. `reader` is a callable taking (buf, buflen) -> int.
"""
import ctypes as C


def read_string(reader) -> str:
    needed = reader(None, 0)
    if needed == 0:
        return ""
    buf = C.create_string_buffer(needed + 1)
    written = reader(buf, needed + 1)
    return buf.raw[:written].decode("utf-8")
