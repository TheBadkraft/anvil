"""Binds Anvil Native's Attribute vtable group (anvil_vtable.h's anvil_attribute_i)."""
import ctypes as C

from ._buffer import read_string
from ._lib import LIB


class _AttributeRaw(C.Structure):
    _fields_ = [
        ("get_key", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_value", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
    ]


_vt = _AttributeRaw.in_dll(LIB, "Attribute")


def get_key(attr: int) -> str:
    return read_string(lambda buf, buflen: _vt.get_key(attr, buf, buflen))


def get_value(attr: int) -> str | None:
    """None specifically for a flag attribute (@[active], no =value) -- distinct from a
    genuinely empty value, which ANVL's grammar doesn't produce today, but the None/empty
    distinction is kept honest here regardless (matches anvil.net's own AnvilAttribute.Value)."""
    if _vt.get_value(attr, None, 0) == 0:
        return None
    return read_string(lambda buf, buflen: _vt.get_value(attr, buf, buflen))
