"""Binds Anvil Native's Statement vtable group (anvil_vtable.h's anvil_statement_i)."""
import ctypes as C

from ._buffer import read_string
from ._lib import LIB


class _StatementRaw(C.Structure):
    _fields_ = [
        ("get_value", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("get_name", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("get_attribute_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_attribute", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("find_attribute", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
    ]


_vt = _StatementRaw.in_dll(LIB, "Statement")


def get_value(stmt: int) -> int | None:
    return _vt.get_value(stmt)


def get_name(stmt: int) -> str:
    return read_string(lambda buf, buflen: _vt.get_name(stmt, buf, buflen))


def get_attribute_count(stmt: int) -> int:
    return _vt.get_attribute_count(stmt)


def get_attribute(stmt: int, index: int) -> int | None:
    return _vt.get_attribute(stmt, index)


def find_attribute(stmt: int, key: bytes) -> int | None:
    return _vt.find_attribute(stmt, key)
