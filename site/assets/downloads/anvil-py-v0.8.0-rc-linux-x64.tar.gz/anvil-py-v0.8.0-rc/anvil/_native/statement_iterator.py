"""Binds Anvil Native's StatementIterator vtable group (anvil_vtable.h's
anvil_statement_iterator_i)."""
import ctypes as C

from ._lib import LIB


class _StatementIteratorRaw(C.Structure):
    _fields_ = [
        ("next", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_void_p))),
        ("dispose", C.CFUNCTYPE(None, C.c_void_p)),
    ]


_vt = _StatementIteratorRaw.in_dll(LIB, "StatementIterator")


def next(it: int) -> int | None:
    out = C.c_void_p()
    if not _vt.next(it, C.byref(out)):
        return None
    return out.value


def dispose(it: int) -> None:
    _vt.dispose(it)
