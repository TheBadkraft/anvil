"""One @[key]/@[key=value] attribute, attached either to a document's header (module-level) or
to an individual statement. Lifetime is tied to the owning AnvilDocument; never valid after it's
disposed.
"""
from anvil._native import attribute as native_attribute


class AnvilAttribute:
    def __init__(self, handle: int):
        self._handle = handle

    @property
    def key(self) -> str:
        return native_attribute.get_key(self._handle)

    @property
    def value(self) -> str | None:
        return native_attribute.get_value(self._handle)
