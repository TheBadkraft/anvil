"""Rich diagnostic detail behind a document's recorded error -- a specific message plus source
position, richer than AnvilDocument.error_category's stable category alone. Lifetime is tied to
the owning AnvilDocument; never valid after it's disposed.
"""
from anvil._native import error as native_error
from anvil.error_code import ErrorCode


class AnvilError:
    def __init__(self, handle: int):
        self._handle = handle

    @property
    def category(self) -> ErrorCode:
        return native_error.get_category(self._handle)

    @property
    def message(self) -> str:
        return native_error.get_message(self._handle)

    @property
    def line(self) -> int:
        return native_error.get_line(self._handle)

    @property
    def column(self) -> int:
        return native_error.get_column(self._handle)
