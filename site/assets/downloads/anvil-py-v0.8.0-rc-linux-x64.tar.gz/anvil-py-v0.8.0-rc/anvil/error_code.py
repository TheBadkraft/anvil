from enum import IntEnum


class ErrorCode(IntEnum):
    """Mirrors anvil_types.h's anvil_err_code exactly -- one category per document-pipeline
    phase, plus cross-cutting infrastructure cases. Deliberately not numerically tied to the
    much larger internal anvl_err_code enum; this is the small, stable public surface."""

    OK = 0
    IO = 1
    HEADER = 2
    INCLUDE = 3
    SYNTAX = 4
    RESOLVE = 5
    MEMORY = 6
    INVALID_ARGUMENT = 7
