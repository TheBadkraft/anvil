"""A loaded, fully-resolved Anvil document -- the one disposable root of this binding's object
graph. Every other type (AnvlValue, AnvlStatement, AnvilAttribute) is a lightweight,
non-disposable view whose lifetime is tied to this instance; none of them are valid after
close()/dispose() runs.

A Python context manager (with ... as doc:) is the direct translation of C#'s
IDisposable/using -- both are deterministic (the block's exit runs cleanup exactly then, not
"whenever GC gets around to it"), unlike Python's own __del__/GC-finalizer timing, which has the
identical non-determinism problem anvil.net's own README documents for JS.
"""
from anvil._native import anvil as native
from anvil._native import document as native_document
from anvil._native import document_iterator as native_document_iterator
from anvil._native import statement_iterator as native_statement_iterator
from anvil.attribute import AnvilAttribute
from anvil.error import AnvilError
from anvil.error_code import ErrorCode
from anvil.statement import AnvlStatement
from anvil.value import AnvlValue


class AnvilDocument:
    def __init__(self, handle: int):
        self._handle = handle
        self._disposed = False

    @classmethod
    def load(cls, filepath: str) -> "AnvilDocument | None":
        handle = native.load(filepath.encode("utf-8"))
        return None if handle is None else cls(handle)

    @classmethod
    def load_buffer(cls, source: str) -> "AnvilDocument | None":
        encoded = source.encode("utf-8")
        handle = native.load_buffer(encoded, len(encoded))
        return None if handle is None else cls(handle)

    @property
    def has_errors(self) -> bool:
        self._check_not_disposed()
        return native.has_errors(self._handle)

    @property
    def error_category(self) -> ErrorCode:
        self._check_not_disposed()
        return native.get_error(self._handle)

    @classmethod
    def parse_value_fragment(cls, text: str) -> "AnvilDocument | None":
        """Parses a single, standalone value expression with no enclosing document/statement
        context. Use fragment_value to retrieve the parsed value."""
        encoded = text.encode("utf-8")
        handle = native.parse_value_fragment(encoded, len(encoded))
        return None if handle is None else cls(handle)

    @staticmethod
    def get_version() -> str:
        return native.get_version()

    @property
    def fragment_value(self) -> "AnvlValue | None":
        """The value parsed by parse_value_fragment; None for any other document."""
        self._check_not_disposed()
        handle = native_document.get_fragment_value(self._handle)
        return None if handle is None else AnvlValue(handle)

    @property
    def error(self) -> "AnvilError | None":
        self._check_not_disposed()
        handle = native_document.get_error(self._handle)
        return None if handle is None else AnvilError(handle)

    def find_statement(self, name: str) -> "AnvlStatement | None":
        """Root-level statement lookup by name (the whole declaration -- name, value, and its
        own attributes)."""
        self._check_not_disposed()
        handle = native_document.find_statement(self._handle, name.encode("utf-8"))
        return None if handle is None else AnvlStatement(handle)

    def find_value(self, name: str):
        """Convenience one-hop equivalent of find_statement(name).value."""
        stmt = self.find_statement(name)
        return None if stmt is None else stmt.value

    @property
    def statements(self):
        """Every top-level statement, in declaration order. The native iterator is opened and
        disposed here -- including on an early break out of the caller's for-loop -- nothing for
        callers to manage by hand."""
        self._check_not_disposed()
        it = native_document.get_statements(self._handle)
        if it is None:
            return
        try:
            while (handle := native_statement_iterator.next(it)) is not None:
                yield AnvlStatement(handle)
        finally:
            native_statement_iterator.dispose(it)

    @property
    def includes(self):
        """This document's own direct includes (include "...";), in declaration order -- never
        the whole transitive graph. Each yielded document is independently disposable and shares
        the underlying parse context with this one -- dispose each one you're done with, same as
        any other AnvilDocument."""
        self._check_not_disposed()
        it = native_document.get_includes(self._handle)
        if it is None:
            return
        try:
            while (handle := native_document_iterator.next(it)) is not None:
                yield AnvilDocument(handle)
        finally:
            native_document_iterator.dispose(it)

    @property
    def attributes(self) -> list[AnvilAttribute]:
        self._check_not_disposed()
        count = native_document.get_attribute_count(self._handle)
        return [AnvilAttribute(native_document.get_attribute(self._handle, i)) for i in range(count)]

    def find_attribute(self, key: str) -> "AnvilAttribute | None":
        self._check_not_disposed()
        handle = native_document.find_attribute(self._handle, key.encode("utf-8"))
        return None if handle is None else AnvilAttribute(handle)

    def dispose(self) -> None:
        if self._disposed:
            return
        native.dispose(self._handle)
        self._disposed = True

    def _check_not_disposed(self) -> None:
        if self._disposed:
            raise RuntimeError("AnvilDocument used after dispose()")

    def __enter__(self) -> "AnvilDocument":
        return self

    def __exit__(self, *exc_info) -> None:
        self.dispose()
