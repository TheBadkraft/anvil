"""One parsed value -- a scalar, an array/tuple, or an object. Lifetime is tied to the owning
AnvilDocument; never valid after it's disposed. Navigation is lazy: every accessor is a direct
native call, nothing eagerly materialized.
"""
from anvil._native import value as native_value
from anvil.value_type import ValueType


class AnvlValue:
    def __init__(self, handle: int):
        self._handle = handle
        # Lazy, per-key memoization -- built one entry at a time as keys are actually looked up,
        # not an eager full-map build. native_value.find_statement already does the scan natively
        # in C (one call, no per-candidate marshaling); this cache makes every *repeated* lookup
        # of the same key free on top of that. Maps key -> AnvlStatement | None, matching
        # anvil.net's AnvlValue._fieldCache exactly.
        self._field_cache: "dict[str, AnvlStatement | None]" = {}

    @property
    def type(self) -> ValueType:
        return native_value.get_type(self._handle)

    @property
    def count(self) -> int:
        return native_value.get_count(self._handle)

    def __getitem__(self, index):
        if isinstance(index, str):
            stmt = self._find_field_statement(index)
            return None if stmt is None else stmt.value
        handle = native_value.get_element(self._handle, index)
        return None if handle is None else AnvlValue(handle)

    def has(self, key: str) -> bool:
        """Shares the same lazy cache as the string indexer above."""
        return self._find_field_statement(key) is not None

    def _find_field_statement(self, key: str):
        if key not in self._field_cache:
            # Deferred import: AnvlStatement.value will need AnvlValue right back, a genuine
            # mutual reference between the two wrapper types (matching anvil.net's own
            # AnvlValue <-> AnvlStatement relationship) -- resolved at call time, not at module
            # load time, so neither module needs the other before it's fully defined.
            from anvil.statement import AnvlStatement

            handle = native_value.find_statement(self._handle, key.encode("utf-8"))
            self._field_cache[key] = None if handle is None else AnvlStatement(handle)
        return self._field_cache[key]

    def entries(self):
        """Every field of an object, in declaration order. Empty for a non-object value."""
        for i in range(self.count):
            handle = native_value.get_statement(self._handle, i)
            if handle is None:
                continue
            stmt = self._statement(handle)
            value = stmt.value
            if value is not None:
                yield stmt.name, value

    @staticmethod
    def _statement(handle: int):
        from anvil.statement import AnvlStatement

        return AnvlStatement(handle)

    def _text(self) -> str:
        return native_value.get_text(self._handle)

    def as_string(self) -> str | None:
        return self._text() if self.type == ValueType.STRING else None

    def as_bool(self) -> bool | None:
        return self._text() == "true" if self.type == ValueType.BOOL else None

    def as_int(self) -> int | None:
        if self.type != ValueType.NUMERIC:
            return None
        return int(float(self._text()))
