from enum import IntEnum


class ValueType(IntEnum):
    """Mirrors anvil_types.h's anvil_value_type exactly."""

    NULL = 0
    BOOL = 1
    NUMERIC = 2
    STRING = 3
    BLOB = 4
    IDENTIFIER = 5
    ARRAY = 6
    TUPLE = 7
    OBJECT = 8
