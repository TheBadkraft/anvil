# anvil-py v0.8.0-rc — Linux x64

A Python binding over Anvil Native — the reference C implementation of the AML/AMP parser —
built directly on its vtable ABI (`anvil_vtable.h`) via `ctypes`: each vtable group's struct is
read once with `in_dll`, its function-pointer fields resolved into cached callables. No compiled
extension module, no dependency beyond the standard library.

## Requirements

- Python 3.11 or later (CPython; relies on `ctypes`, which ships with every install).
- Linux x64 (glibc) only. Other platforms: build from source (`vendor/anvil`'s `v0.8.0-rc` tag or
  later, `make so-release`) — not yet published to PyPI, so building means pointing at a real
  checkout, not `pip install anvil-py`.
- No other runtime dependencies once built.

## Usage

Drop the `anvil/` directory anywhere on your `PYTHONPATH` — `libanvil.so` is already inside it
(`anvil/runtimes/linux-x64/native/`), resolved automatically relative to the package itself.

```python
from anvil import AnvilDocument

with AnvilDocument.load_buffer('server := { host := "localhost"; port := 8080; };\n') as doc:
    if doc is None or doc.has_errors:
        err = doc.error if doc else None
        print(f"Failed: {err.message if err else 'allocation failed'}")
    else:
        server = doc.find_value("server")
        print(server["host"].as_string())  # "localhost"
```

Full API reference: see the anvldata.com Bindings guide.
