'use strict';
// The anvil-node reader API over the R1 tree: parse, parseRawValue, lastError, AnvlNode, AnvlStatement.
// An AnvlNode is a small facade (document context + node id) made on access; nothing is decoded until an accessor
// asks (strings, numbers and blob text are read from the source bytes then). Browser-safe: no Node modules.
const R = require('./reader');
const { load, loadFragment } = require('./load');
const { docOfNode } = require('./resolve');
const { NAMES } = require('./errors');

const enc = new TextEncoder();
const td = new TextDecoder('utf-8', { ignoreBOM: true }); // a BOM inside a string is data
const POW10 = [1, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18, 1e19, 1e20, 1e21, 1e22];
const MAX_SAFE = Number.MAX_SAFE_INTEGER;
const ROOT = -2, NONE = -1;

let defaultIo = null; // the platform's reader (Node: the file system), installed by the entry
let userIo = null;    // the reader the program installed with setIo()
let lastErr = null;

const setDefaultIo = (function setDefaultIo(io) { defaultIo = io; });
const currentIo = () => userIo || defaultIo;

// The public include reader: setIo({ read(path) -> string | Uint8Array | null }). `path` is the composed include path (the
// includer's directory + '/' + the include string, e.g. './schema-gen/x.types.anvl'); null means not found. Synchronous, with no
// caching of its own. setIo(null) removes it (in Node the file system is the default again).
const setIo = (function setIo(reader) {
   if (reader === null || reader === undefined) { userIo = null; return; }
   if (typeof reader !== 'object' || typeof reader.read !== 'function') throw new TypeError('setIo() requires { read(path) } or null');
   userIo = {
      readFile(binaryPath) {
         const got = reader.read(td.decode(Uint8Array.from(binaryPath, (ch) => ch.charCodeAt(0))));
         if (got === null || got === undefined) return null;
         if (typeof got === 'string') return enc.encode(got);
         if (got instanceof Uint8Array) return got;
         throw new TypeError('the include reader must return a string, a Uint8Array or null');
      },
   };
});

// ------------------------------------------------------------------------------------------ decoding
const NON_ASCII = /[^\x00-\x7f]/;
const text = (function text(s, a, b) {
   const len = b - a;
   if (len <= 32) {
      let str = '';
      for (let i = a; i < b; i++) {
         const c = s[i];
         if (c > 127) return td.decode(s.subarray(a, b));
         str += String.fromCharCode(c);
      }
      return str;
   }
   if (len <= 2048) {
      // ASCII, the usual case, is built directly: the TextDecoder's first use costs far more than a small span
      const str = String.fromCharCode.apply(null, s.subarray(a, b));
      if (!NON_ASCII.test(str)) return str;
   }
   return td.decode(s.subarray(a, b));
});

// the escape resolution of native: \n \t \r \\ \" ; any other backslash pair is kept as written
const unescape = (function unescape(str) {
   let out = '', from = 0;
   for (let i = 0; i < str.length; i++) {
      if (str.charCodeAt(i) !== 92 || i + 1 >= str.length) continue;
      const d = str.charCodeAt(i + 1);
      const r = d === 110 ? '\n' : d === 116 ? '\t' : d === 114 ? '\r' : d === 92 ? '\\' : d === 34 ? '"' : null;
      if (r === null) continue;
      out += str.slice(from, i) + r;
      from = ++i + 1;
    }
   return from === 0 ? str : out + str.slice(from);
});

// Clinger's fast path (<= 15 digits, |exp10| <= 22): one correctly rounded operation, so bit-identical to Number(text)
const parseDouble = (function parseDouble(s, a, b) {
   let i = a, neg = false;
   if (s[i] === 45) { neg = true; i++; }
   let mant = 0, digits = 0, frac = 0, dot = false;
   for (; i < b; i++) {
      const c = s[i];
      if (c >= 48 && c <= 57) { mant = mant * 10 + (c - 48); digits++; if (dot) frac++; } else if (c === 46) dot = true; else break;
   }
   let ex = 0;
   if (i < b) {
      i++;
      let sg = 1;
      if (s[i] === 43) i++; else if (s[i] === 45) { sg = -1; i++; }
      let e = 0;
      for (; i < b; i++) e = e * 10 + (s[i] - 48);
      if (e > 9999) return Number(text(s, a, b));
      ex = sg * e;
   }
   const e10 = ex - frac;
   if (digits <= 15 && e10 >= -22 && e10 <= 22) {
      const v = e10 < 0 ? mant / POW10[-e10] : mant * POW10[e10];
      return neg ? -v : v;
   }
   return Number(text(s, a, b));
});

// An integer literal as a JS value: a Number when it is a safe integer, else the exact BigInt (leading zeros are
// not significant). Float literals are Numbers.
const plainNumber = (function plainNumber(s, a, b, isFloat) {
   if (isFloat) return parseDouble(s, a, b);
   let i = a;
   const neg = s[i] === 45;
   if (neg) i++;
   while (i < b - 1 && s[i] === 48) i++;
   if (b - i <= 15) {
      let v = 0;
      for (let k = i; k < b; k++) v = v * 10 + (s[k] - 48);
      return neg ? -v : v;
   }
   const big = BigInt(text(s, i, b));
   const signed = neg ? -big : big;
   return signed >= -9007199254740991n && signed <= 9007199254740991n ? Number(signed) : signed;
});

// A class's methods compile on their first call; a function's, written as a parenthesized expression, at load (see test/eager-compile.test.js).
const defineMethod = (function defineMethod(proto, name, fn) { Object.defineProperty(proto, name, { value: fn, writable: true, configurable: true }); });

// ------------------------------------------------------------------------------------------ context
const Ctx = (function Ctx(res) {
   this.T = res.tree.T;
   this.A = res.tree.A;
   this.docs = res.docs;
   this.inh = res.inherited;
   this.multi = res.docs.length > 1;
   this.buf0 = res.docs[0].buf;
   this.root = res.docs[0];
   this.names = null;
});

defineMethod(Ctx.prototype, 'buf', (function buf(node) { return this.multi ? this.docs[docOfNode(this.docs, node)].buf : this.buf0; }));

// a reference reads through to the value it resolved to; an unresolved one is NONE (reads as null)
defineMethod(Ctx.prototype, 'deref', (function deref(v) { return this.T[v] === R.T_VARREF ? this.T[v + 5] : v; }));

defineMethod(Ctx.prototype, 'node', (function node(v) { return new AnvlNode(this, v < 0 ? NONE : this.T[v] === R.T_VARREF ? this.T[v + 5] : v); }));

const EMPTY = Object.freeze([]);


// A statement name, as a string. Sibling statements of same-shaped objects (the rows of a table) repeat their names
// position by position, so the string last made for position k is reused when the bytes match: no new string, less GC.
const nameAt = (function nameAt(ctx, buf, ns, ne, k) {
   const len = ne - ns;
   if (k < 32) {
      const names = ctx.names || (ctx.names = new Array(32));
      const c = names[k];
      if (c !== undefined && c.length === len) {
         let q = 0;
         while (q < len && buf[ns + q] === c.charCodeAt(q)) q++;
         if (q === len) return c;
      }
      return (names[k] = text(buf, ns, ne));
   }
   return text(buf, ns, ne);
});

const toAttribute = (function toAttribute(ctx, buf, a) {
   const A = ctx.A;
   const ks = A[a], ke = A[a + 1], vs = A[a + 2], ve = A[a + 3];
   const key = text(buf, ks, ke);
   if (ve === vs) return Object.freeze({ key, value: null, decodedValue: null });
   const scratch = R.decodeAttr(buf, vs, ve);
   return Object.freeze({ key, value: text(buf, vs, ve), decodedValue: plainValue(scratch, 0, buf) });
});

const AnvlStatement = (function AnvlStatement(ctx, s, k) {
   const T = ctx.T;
   const buf = ctx.buf(s);
   this.name = nameAt(ctx, buf, T[s + 1], T[s + 2], k);
   this.value = ctx.node(T[s + 5]);
   const n = T[s] >> 8;
   if (n === 0) {
      this._attributes = EMPTY;
   } else {
      const list = [];
      for (let k = 0, a = T[s + 7]; k < n; k++, a += 4) list.push(toAttribute(ctx, buf, a));
      this._attributes = Object.freeze(list);
   }
});

Object.defineProperty(AnvlStatement.prototype, 'attributes', { get: (function attributes() { return this._attributes; }), configurable: true });

defineMethod(AnvlStatement.prototype, 'findAttribute', (function findAttribute(key) { return this._attributes.find((a) => a.key === key) || null; }));

// ------------------------------------------------------------------------------------------ AnvlNode
const AnvlNode = (function AnvlNode(ctx, i) {
   this._c = ctx;
   this._i = i;
});

Object.defineProperty(AnvlNode.prototype, 'type', { get: (function type() {
   const i = this._i;
   if (i < 0) return i === ROOT ? 'object' : 'scalar';
   switch (this._c.T[i]) {
   case R.T_OBJECT: return 'object';
   case R.T_ARRAY: return 'array';
   case R.T_TUPLE: return 'tuple';
   case R.T_BLOB: return 'blob';
   default: return 'scalar';
   }
}), configurable: true });

// the type tag of the value node, 0 for the unresolved/none case
defineMethod(AnvlNode.prototype, '_t', (function _t() { return this._i < 0 ? (this._i === ROOT ? R.T_OBJECT : R.T_NULL) : this._c.T[this._i]; }));

// first child statement node, or -1
defineMethod(AnvlNode.prototype, '_first', (function _first() { return this._i === ROOT ? this._c.root.firstStmt : this._c.T[this._i + 5]; }));

// every statement node of an object in order: its own, then those inherited
defineMethod(AnvlNode.prototype, '_stmts', (function _stmts() {
   const c = this._c, T = c.T, out = [];
   for (let s = this._first(); s >= 0; s = T[s + 6]) out.push(s);
   const extra = this._i >= 0 ? c.inh.get(this._i) : undefined;
   if (extra) for (const s of extra) out.push(s);
   return out;
}));

// the first statement named `key`, or -1
defineMethod(AnvlNode.prototype, '_find', (function _find(key) {
   if (this._t() !== R.T_OBJECT) return -1;
   const c = this._c, T = c.T;
   if (typeof key !== 'string') key = String(key);
   const len = key.length;
   for (let k = 0; k < len; k++) if (key.charCodeAt(k) > 127) return -1; // names are ASCII
   let s = this._first();
   const own = this._i >= 0 && c.inh.has(this._i);
   for (;;) {
      for (; s >= 0; s = T[s + 6]) {
         const ns = T[s + 1];
         if (T[s + 2] - ns !== len) continue;
         const buf = c.multi ? c.buf(s) : c.buf0;
         let q = 0;
         while (q < len && buf[ns + q] === key.charCodeAt(q)) q++;
         if (q === len) return s;
      }
      if (!own) return -1;
      // inherited statements follow the own ones
      for (const x of c.inh.get(this._i)) {
         const ns = T[x + 1];
         if (T[x + 2] - ns !== len) continue;
         const buf = c.buf(x);
         let q = 0;
         while (q < len && buf[ns + q] === key.charCodeAt(q)) q++;
         if (q === len) return x;
      }
      return -1;
   }
}));

defineMethod(AnvlNode.prototype, 'has', (function has(key) { return this._find(key) >= 0; }));

defineMethod(AnvlNode.prototype, 'get', (function get(key) {
   const s = this._find(key);
   return s < 0 ? null : this._c.node(this._c.T[s + 5]);
}));

defineMethod(AnvlNode.prototype, 'statements', (function statements() {
   if (this._t() !== R.T_OBJECT) return [];
   return this._stmts().map((s, k) => new AnvlStatement(this._c, s, k));
}));

defineMethod(AnvlNode.prototype, 'statement', (function statement(name) {
   const s = this._find(name);
   return s < 0 ? null : new AnvlStatement(this._c, s, 99);
}));

Object.defineProperty(AnvlNode.prototype, 'attributes', { get: (function attributes() {
   if (this._i !== ROOT) return EMPTY;
   const c = this._c, d = c.root, out = [];
   for (let k = 0, a = d.attrFirst; k < d.attrCount; k++, a += 4) out.push(toAttribute(c, d.buf, a));
   return Object.freeze(out);
}), configurable: true });

defineMethod(AnvlNode.prototype, 'findAttribute', (function findAttribute(key) { return this.attributes.find((a) => a.key === key) || null; }));

defineMethod(AnvlNode.prototype, 'hasAttribute', (function hasAttribute(key) {
   if (this._i !== ROOT) return false;
   const c = this._c, d = c.root;
   for (let k = 0, a = d.attrFirst; k < d.attrCount; k++, a += 4) if (text(d.buf, c.A[a], c.A[a + 1]) === key) return true;
   return false;
}));

defineMethod(AnvlNode.prototype, 'entries', (function entries() {
   if (this._t() !== R.T_OBJECT) return [];
   const c = this._c, T = c.T;
   return this._stmts().map((s, k) => [nameAt(c, c.buf(s), T[s + 1], T[s + 2], k), c.node(T[s + 5])]);
}));

Object.defineProperty(AnvlNode.prototype, 'count', { get: (function count() {
   const t = this._t();
   if (t === R.T_ARRAY || t === R.T_TUPLE) return this._c.T[this._i + 7];
   if (t !== R.T_OBJECT) return 0;
   if (this._i === ROOT) return this._c.root.nstmt;
   const extra = this._c.inh.get(this._i);
   return this._c.T[this._i + 7] + (extra ? extra.length : 0);
}), configurable: true });

defineMethod(AnvlNode.prototype, 'at', (function at(index) {
   const t = this._t();
   if ((t !== R.T_ARRAY && t !== R.T_TUPLE) || !(index >= 0) || index >= this._c.T[this._i + 7]) return null;
   const T = this._c.T;
   let j = T[this._i + 5];
   for (let n = Math.trunc(index); n > 0; n--) j = T[j + 6];
   return this._c.node(j);
}));

defineMethod(AnvlNode.prototype, 'asString', (function asString() {
   const t = this._t();
   if (t === R.T_STRING || t === R.T_BARE || t === R.T_BLOB) {
      const c = this._c, T = c.T, i = this._i;
      const str = text(c.buf(i), T[i + 1], T[i + 2]);
      return t === R.T_STRING && T[i + 3] ? unescape(str) : str;
   }
   return null;
}));

defineMethod(AnvlNode.prototype, 'asBool', (function asBool() {
   if (this._t() !== R.T_BOOL) return null;
   return this._c.buf(this._i)[this._c.T[this._i + 1]] === 116;
}));

defineMethod(AnvlNode.prototype, 'isNull', (function isNull() { return this._t() === R.T_NULL; }));

// A safe integer is a Number; an integer outside the safe range is the exact BigInt. A float literal is
// Math.trunc of its value. null for anything that is not a number.
defineMethod(AnvlNode.prototype, 'asInt', (function asInt() {
   if (this._t() !== R.T_NUMERIC) return null;
   const c = this._c, T = c.T, i = this._i;
   const v = plainNumber(c.buf(i), T[i + 1], T[i + 2], T[i + 3] === 1);
   return typeof v === 'number' ? Math.trunc(v) : v;
}));

// 'integer' for a literal with no '.' and no exponent, 'float' for any other number literal, else null
Object.defineProperty(AnvlNode.prototype, 'numericKind', { get: (function numericKind() {
   if (this._t() !== R.T_NUMERIC) return null;
   return this._c.T[this._i + 3] === 1 ? 'float' : 'integer';
}), configurable: true });

// The exact Number a number node denotes (Infinity for a float literal that overflows a double); null for a
// non-number and for an integer literal outside the safe range, which no Number holds exactly.
defineMethod(AnvlNode.prototype, 'asNumber', (function asNumber() {
   if (this._t() !== R.T_NUMERIC) return null;
   const c = this._c, T = c.T, i = this._i;
   const v = plainNumber(c.buf(i), T[i + 1], T[i + 2], T[i + 3] === 1);
   return typeof v === 'number' ? v : null;
}));

// An integer LITERAL as a BigInt; null for a float literal (even 2020.0) and for a non-number.
defineMethod(AnvlNode.prototype, 'asBigInt', (function asBigInt() {
   if (this._t() !== R.T_NUMERIC || this._c.T[this._i + 3] === 1) return null;
   const c = this._c, T = c.T, i = this._i;
   return BigInt(text(c.buf(i), T[i + 1], T[i + 2]));
}));

// FR-2610-anvl-js-003: true when a float literal does not fit a finite double (it reads as +-Infinity), false for
// every other number, null for a node that is not a number.
Object.defineProperty(AnvlNode.prototype, 'overflowed', { get: (function overflowed() {
   if (this._t() !== R.T_NUMERIC) return null;
   const c = this._c, T = c.T, i = this._i;
   if (T[i + 3] !== 1) return false;
   return !Number.isFinite(parseDouble(c.buf(i), T[i + 1], T[i + 2]));
}), configurable: true });

// FR-2610-anvl-js-006: a tagged blob's tag, else null
Object.defineProperty(AnvlNode.prototype, 'blobTag', { get: (function blobTag() {
   if (this._t() !== R.T_BLOB) return null;
   const c = this._c, T = c.T, i = this._i;
   return T[i + 3] < 0 ? null : text(c.buf(i), T[i + 3], T[i + 4]);
}), configurable: true });

// ------------------------------------------------------------------------------------------ plain values
// A value as a plain JS value (parseRawValue, decoded attribute values): arrays for array and tuple, an object for
// an object (a repeated name is last-wins), a string for string, bare and blob text, exact BigInt past 2^53.
const plainValue = (function plainValue(T, v, buf, inh) {
   switch (T[v]) {
   case R.T_NULL: return null;
   case R.T_BOOL: return buf[T[v + 1]] === 116;
   case R.T_NUMERIC: return plainNumber(buf, T[v + 1], T[v + 2], T[v + 3] === 1);
   case R.T_STRING: { const s = text(buf, T[v + 1], T[v + 2]); return T[v + 3] ? unescape(s) : s; }
   case R.T_BLOB: case R.T_BARE: return text(buf, T[v + 1], T[v + 2]);
   case R.T_ARRAY: case R.T_TUPLE: {
      const out = [];
      for (let c = T[v + 5]; c >= 0; c = T[c + 6]) out.push(plainValue(T, c, buf, inh));
      return out;
   }
   case R.T_OBJECT: {
      const out = {};
      for (let s = T[v + 5]; s >= 0; s = T[s + 6]) {
         const name = text(buf, T[s + 1], T[s + 2]);
         const value = plainValue(T, T[s + 5], buf, inh);
         if (name === '__proto__') Object.defineProperty(out, name, { value, writable: true, enumerable: true, configurable: true });
         else out[name] = value;
      }
      return out;
   }
   default: return null;
   }
});

// ------------------------------------------------------------------------------------------ entry points
const describeType = (function describeType(value) {
   if (value === null) return 'null';
   if (Array.isArray(value)) return 'array';
   if (ArrayBuffer.isView(value)) return value.constructor.name;
   return typeof value;
});

const requireString = (function requireString(value, fn) {
   if (typeof value !== 'string') throw new TypeError(`${fn}() requires a string, not ${describeType(value)}`);
   return value;
});

// What lastError() reports for a load error. code and name are native's (src/errors.js is generated from the pinned native);
// message, line and column are anvil-node's. `source` is native's anvil_error_get_source (FR-2611-anvl-errors-001): the path of the
// document the error is in, as it was opened (the includer's directory, a '/', and the include string as written); "" for the root.
const errorInfo = (function errorInfo(err) {
   return { message: err.message, line: err.line, column: err.col, code: err.code, name: NAMES[err.code], source: err.source };
});

const failure = (function failure(res) {
   lastErr = errorInfo(res.err);
   return null;
});

const parse = (function parse(sourceText) {
   requireString(sourceText, 'parse');
   lastErr = null;
   const res = load(enc.encode(sourceText), { path: null, io: currentIo() });
   if (!res.ok) return failure(res);
   return new AnvlNode(new Ctx(res), ROOT);
});

const parseRawValueGeneral = (function parseRawValueGeneral(sourceText) {
   requireString(sourceText, 'parseRawValue');
   lastErr = null;
   const res = loadFragment(enc.encode(sourceText));
   if (!res.ok) return failure(res);
   return plainValue(res.tree.T, res.value, res.root.buf, res.inherited);
});

// ---- the fast path: an array of tuples of plain scalars, which is the text FlyWire's Table decode hands parseRawValue.
// The text is checked against a grammar of exactly what the general reader reads the same way and nothing else (strings without
// a backslash or a control character, the text well-formed UTF-16; integers of up to 15 digits without leading
// zeros (a longer one is a BigInt in the general reader); decimals; true, false, null; tuples of at least two; blank space between tokens), then read by JSON.parse once the tuples'
// parentheses are brackets. Native regex and JSON.parse run at full speed from the first call, where the general reader
// (JavaScript, tiering up) takes milliseconds to warm. Anything that does not match takes the general path, so errors and every other
// shape are the general reader's (test/raw-fast.test.js compares the two).
const SCALAR = '(?:"[^"\\\\\\x00-\\x1f\\x7f]*"|-?(?:0|[1-9][0-9]*)\\.[0-9]+|-?(?:0|[1-9][0-9]{0,14})|true|false|null)';
const WSP = '[ \\t\\r\\n]*';
// one scalar in the pattern, and a capture that is set only if the tuple has a second element
const ROW = new RegExp('\\(' + WSP + SCALAR + WSP + '(?:(,)' + WSP + SCALAR + WSP + ')*\\)', 'y');
const LONE_SURROGATE = /[\ud800-\udfff]/;
const rawFast = { hits: 0 };

const rawTable = (function rawTable(s) {
   const n = s.length;
   let i = 0;
   let c;
   while (i < n && ((c = s.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   if (i >= n || s.charCodeAt(i) !== 91) return undefined;
   i++;
   if (LONE_SURROGATE.test(s) && !(s.isWellFormed && s.isWellFormed())) return undefined; // the general reader reads U+FFFD there
   const parts = [];
   for (;;) {
      while (i < n && ((c = s.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
      ROW.lastIndex = i;
      const m = ROW.exec(s);
      if (m === null || m[1] === undefined) return undefined; // no tuple here, or a tuple of one element
      const end = ROW.lastIndex;
      parts.push(s.slice(i + 1, end - 1));
      i = end;
      while (i < n && ((c = s.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
      if (i >= n) return undefined;
      c = s.charCodeAt(i++);
      if (c === 44) continue;
      if (c === 93) break;
      return undefined;
   }
   while (i < n && ((c = s.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   if (i < n && s.charCodeAt(i) === 59) {
      i++;
      while (i < n && ((c = s.charCodeAt(i)) === 32 || c === 10 || c === 9 || c === 13)) i++;
   }
   if (i !== n) return undefined;
   const json = '[[' + parts.join('],[') + ']]';
   return JSON.parse(json);
});

const parseRawValue = (function parseRawValue(sourceText) {
   if (typeof sourceText === 'string') {
      const fast = rawTable(sourceText);
      if (fast !== undefined) {
         lastErr = null;
         rawFast.hits++;
         return fast;
      }
   }
   return parseRawValueGeneral(sourceText);
});

const lastError = (function lastError() { return lastErr; });

// What the schema layer needs: the context class, the io, the last-error slot and the escape resolver.
const internals = {
   Ctx, ROOT, NONE, unescape, plainNumber, parseRawValueGeneral, rawFast,
   io: currentIo,
   setLastError(info) { lastErr = info; },
};

module.exports = { parse, parseRawValue, lastError, AnvlNode, AnvlStatement, setIo, setDefaultIo, errorInfo, internals };
