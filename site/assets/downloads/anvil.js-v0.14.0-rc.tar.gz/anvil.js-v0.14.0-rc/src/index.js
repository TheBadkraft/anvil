'use strict';
// anvil.js: the anvil-node reader API over the R1 reader. (Types, schema and builder are later phases.)
const api = require('./api');
const info = require('./build-info');
const writer = require('./writer');
const builder = require('./builder');
const schema = require('./schema');

module.exports = {
   parse: api.parse,
   parseRawValue: api.parseRawValue,
   lastError: api.lastError,
   setIo: api.setIo,
   getVersion: () => (info.build ? `${info.nativeVersion}+${info.build}` : info.nativeVersion),
   AnvlNode: api.AnvlNode,
   AnvlStatement: api.AnvlStatement,
   implementation: 'anvil.js',
   AnvilDialect: writer.AnvilDialect,
   WriterErrorCode: writer.WriterErrorCode,
   AnvilWriterError: writer.AnvilWriterError,
   AnvilWriter: writer.AnvilWriter,
   AnvilBuilder: builder.AnvilBuilder,
   AnvilNode: builder.AnvilNode,
   AnvilMember: builder.AnvilMember,
   TypeRegistry: schema.TypeRegistry,
   Schema: schema.Schema,
   SchemaField: schema.SchemaField,
   TypeKind: schema.TypeKind,
   TypeDiagnostic: schema.TypeDiagnostic,
   SchemaViolation: schema.SchemaViolation,
   SchemaDiagnostic: schema.SchemaDiagnostic,
   SchemaErrorCode: schema.SchemaErrorCode,
   TypeErrorCode: schema.TypeErrorCode,
};
