'use strict';
// Loading: a root document (bytes), its include graph, every body, then the resolver; or one value fragment.
// The phases and their error categories are anvil_load's (anvil_flat.c: load_common). Native keeps one error list
// for the whole load and records the first error only, so one `err` here serves every phase.
//
// All file access goes through `io.readFile(path) -> Uint8Array | null`, with paths as binary strings (one char per
// byte), so the loader runs unchanged where there is no filesystem.
const { CODES: E, MESSAGES, CATEGORY } = require('./errors');
const R = require('./reader');
const { latin1 } = require('./bytes');
const { resolve, lineColOf, NO_INHERITED } = require('./resolve');

const PATH_MAX = 1024;

// The dialect a file name suggests (Files.dialect_hint): the text after the LAST '.' in the whole path.
const dialectHint = (function dialectHint(path) {
   const i = path.lastIndexOf('.');
   if (i < 0) return R.D_AML;
   const ext = path.slice(i);
   if (ext === '.amp') return R.D_AMP;
   if (ext === '.asl') return R.D_ASL;
   return R.D_AML;
});

// `source` is the document the error is in (FR-2611-anvl-errors-001): the path it was opened by, "" for the root.
const makeError = (function makeError(code, line, col, message, source) {
   return { code, line, col, message: message === undefined ? MESSAGES[code] : message, source: source === undefined ? '' : source };
});
const sourceOf = (function sourceOf(doc, root) { return doc === root || doc.path === root.path ? '' : doc.path; });

// Documents with the same bytes are one document (native's source registry). Found by a hash of the bytes, then compared byte for byte.
const contentKey = (function contentKey(buf) {
   let h = 0x811c9dc5 ^ buf.length;
   for (let i = 0; i < buf.length; i++) h = Math.imul(h ^ buf[i], 0x01000193);
   return h;
});
const sameContent = (function sameContent(a, b) {
   if (a.length !== b.length) return false;
   for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
   return true;
});
const registryFind = (function registryFind(registry, key, buf) {
   const list = registry.get(key);
   if (list === undefined) return undefined;
   for (const d of list) if (sameContent(d.buf, buf)) return d;
   return undefined;
});
const registryAdd = (function registryAdd(registry, key, doc) {
   const list = registry.get(key);
   if (list === undefined) registry.set(key, [doc]); else list.push(doc);
});

// A document's identity for include-cycle detection (module.c include_normalize_path): "." components and repeated slashes vanish,
// "name/.." cancels, a leading ".." stays on a relative path and is dropped on an absolute one. Textual: no symbolic links.
// "a.anvl", "./a.anvl", "d/../a.anvl" and ".//a.anvl" are one document. Printed paths are not changed.
const normalizePath = (function normalizePath(path) {
   const absolute = path.charCodeAt(0) === 47;
   const out = [];
   for (const part of path.split('/')) {
      if (part === '' || part === '.') continue;
      if (part === '..') {
         if (out.length > 0 && out[out.length - 1] !== '..') { out.pop(); continue; }
         if (absolute) continue; // the parent of the root is the root
      }
      out.push(part);
   }
   const joined = out.join('/');
   return absolute ? '/' + joined : joined === '' ? '.' : joined;
});

// a load that stopped in a phase: its category, its error, and the tree as far as it got
const failLoad = (function failLoad(res, category, err) {
   res.category = category;
   res.err = err;
   res.tree = R.finish();
   return res;
});

const load = (function load(bytes, options) {
   const opts = options || {};
   const rootPath = opts.path === undefined ? null : opts.path;
   const io = opts.io || null;
   const res = { ok: false, category: CATEGORY.OK, err: null, docs: [], tree: null, inherited: NO_INHERITED, root: null };

   R.begin(bytes.length >> 2);
   const root = R.openSource(bytes, rootPath === null ? null : dialectHint(rootPath));
   root.path = rootPath === null ? '<buffer>' : rootPath;
   res.docs.push(root);
   res.root = root;

   // header
   let code = R.scanHeader(root);
   if (code) {
      const [line, col] = lineColOf(root.buf, R.headerError());
      return failLoad(res, CATEGORY.HEADER, makeError(code, line, col, undefined, ''));
   }

   // includes
   if (root.includes.length > 0) {
      const registry = new Map();
      registryAdd(registry, contentKey(root.buf), root);
      const stack = [];
      const loadChildren = (doc) => {
         stack.push(normalizePath(doc.path));
         for (const inc of doc.includes) {
            const e = loadChild(doc, inc);
            if (e) { stack.pop(); return e; }
         }
         stack.pop();
         return null;
      };
      // An include error is at the `include` keyword, in the document that holds the include (BR-2611-anvl-errors-001).
      const includeError = (parent, inc, code) => {
         const [line, col] = lineColOf(parent.buf, inc.declS);
         return makeError(code, line, col, undefined, sourceOf(parent, root));
      };
      const loadChild = (parent, inc) => {
         const pb = parent.buf;
         const nameLen = inc.pathE - inc.pathS - 2;
         if (nameLen >= PATH_MAX) return includeError(parent, inc, E.ANVL_ERR_INVALID_ARGUMENT);
         let end = inc.pathS + 1 + nameLen;
         const nul = pb.indexOf(0, inc.pathS + 1);
         if (nul >= 0 && nul < end) end = nul; // C string: the name stops at a NUL
         const name = latin1(pb, inc.pathS + 1, end);
         let resolved;
         if (name.charCodeAt(0) === 47) {
            resolved = name;
         } else {
            const slash = parent.path.lastIndexOf('/');
            let dir = slash < 0 ? '.' : parent.path.slice(0, slash);
            if (dir === '') dir = '.';
            resolved = dir + '/' + name;
            if (resolved.length >= PATH_MAX) return includeError(parent, inc, E.ANVL_ERR_INVALID_ARGUMENT);
         }
         if (stack.includes(normalizePath(resolved))) return includeError(parent, inc, E.ANVL_ERR_INCLUDE_CYCLIC);
         const data = io ? io.readFile(resolved) : null;
         if (!data) return includeError(parent, inc, E.ANVL_ERR_INCLUDE_FILE_NOT_FOUND);
         const child = R.openSource(data, dialectHint(resolved));
         child.path = resolved;
         const key = contentKey(child.buf);
         const existing = registryFind(registry, key, child.buf);
         if (existing) { inc.resolved = res.docs.indexOf(existing); return null; }
         registryAdd(registry, key, child);
         res.docs.push(child);
         const c = R.scanHeader(child);
         if (c) {
            const [line, col] = lineColOf(child.buf, R.headerError());
            return makeError(c, line, col, undefined, sourceOf(child, root));
         }
         inc.resolved = res.docs.length - 1;
         return loadChildren(child);
      };
      const e = loadChildren(root);
      if (e) return failLoad(res, CATEGORY.INCLUDE, e);
   }

   // bodies, in registration order
   for (const doc of res.docs) {
      if (!R.parseBody(doc)) {
         const { code: c, pos } = R.getError();
         const [line, col] = lineColOf(doc.buf, pos);
         return failLoad(res, CATEGORY.SYNTAX, makeError(c, line, col, undefined, sourceOf(doc, root)));
      }
   }

   res.tree = R.finish();
   const rerr = resolve(res.docs, res.tree, res);
   if (rerr) {
      res.category = CATEGORY.RESOLVE;
      res.err = makeError(rerr.code, rerr.line, rerr.col, rerr.message, rerr.doc === undefined ? '' : sourceOf(res.docs[rerr.doc], root));
      return res;
   }
   res.ok = true;
   return res;
});

const loadFragment = (function loadFragment(bytes) {
   const res = { ok: false, category: CATEGORY.OK, err: null, docs: [], tree: null, inherited: NO_INHERITED, root: null, value: -1 };
   R.begin(bytes.length >> 2);
   const doc = R.openSource(bytes, null);
   doc.path = '<fragment>';
   res.docs.push(doc);
   res.root = doc;
   const v = R.parseFragment(doc);
   res.tree = R.finish();
   if (v < 0) {
      const { code, pos } = R.getError();
      const [line, col] = lineColOf(doc.buf, pos);
      res.category = CATEGORY.SYNTAX;
      res.err = makeError(code, line, col, undefined, '');
      return res;
   }
   res.ok = true;
   res.value = v;
   return res;
});

module.exports = { load, loadFragment, dialectHint };
