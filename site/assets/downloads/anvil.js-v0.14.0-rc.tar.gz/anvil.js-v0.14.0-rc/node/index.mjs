// ES module entry for Node: named exports over the CommonJS entry (so `import { parse } from 'anvil.js'` works).
import api from './index.js';

export const { setIo, parse, parseRawValue, lastError, getVersion, AnvlNode, AnvlStatement, implementation, AnvilDialect, WriterErrorCode, AnvilWriterError, AnvilWriter, AnvilBuilder, AnvilNode, AnvilMember, TypeRegistry, Schema, SchemaField, TypeKind, TypeDiagnostic, SchemaViolation, SchemaDiagnostic, SchemaErrorCode, TypeErrorCode } = api;
export default api;
