# anvil-net

.NET bindings for **Anvil Native**, the reference C implementation of the ANVL (AML/AMP/ASL) parser. Parse ANVL, navigate it
lazily, validate it against a schema, and write it back out, with the same parser every other Anvil binding uses.
Documentation: https://anvldata.com/docs

## Installing the prebuilt package

`Anvil.Net.dll` is a managed assembly that calls the native `libanvil.so`, which ships beside it. Installing needs no
compiler and no build step.

- **.NET:** .NET 9 (`net9.0`).
- **Platform:** Linux x64 (glibc) only. Other platforms build from source (see Development).
- **Not on nuget.org yet:** there is no `dotnet add package Anvil.Net` from the public feed.

**From the tarball.** Extract it, reference the assembly, and have `libanvil.so` copied beside your own output
(the native library is loaded from the assembly's directory):

```xml
<ItemGroup>
  <Reference Include="Anvil.Net"><HintPath>path/to/Anvil.Net.dll</HintPath></Reference>
  <None Include="path/to/libanvil.so" Link="libanvil.so" CopyToOutputDirectory="PreserveNewest" />
</ItemGroup>
```

**A NuGet package is not part of the release.** The tarball holds `Anvil.Net.dll`, `libanvil.so`, this README and the
licence, and nothing is published to nuget.org. If you would rather use a `PackageReference`, build the package yourself
from the source repository (see "Building a local NuGet package" under Development), put it in a folder, and add that folder
as a restore source (`dotnet nuget add source <folder>`, or `RestoreSources`).

## Quick start

```csharp
using Anvil.Net;

// Parse. Accessors are lazy calls into the native library; `using` frees the document.
using var doc = AnvilDocument.LoadBuffer(
    "#!aml\n@[version=\"1.2\"]\nticket @[type=bug] := { id := 7; title := \"login fails\"; };\n")!;
if (doc.HasErrors) { /* doc.Error?.Message / .Line / .Column */ }
doc.FindAttribute("version")!.DecodedValue!.AsString();      // "1.2"
var ticket = doc.FindStatement("ticket")!;
ticket.FindAttribute("type")!.Value;                         // "bug"
ticket.Value!["title"]!.AsString();                          // "login fails"

// Validate. A schema is an ANVL document carrying @[schema]; the data to check is ANVL text too.
using var schemaDoc = AnvilDocument.LoadBuffer("#!aml\n@[schema]\nasset_id := { type := Numeric; required := true; };\n")!;
using var schema = AnvilSchema.Load(schemaDoc)!;
schema.ValidateField("set := { asset_id := 7; };\n", "set").IsValid;       // true
var bad = schema.ValidateField("set := { name := \"x\"; };\n", "set");
bad.IsValid;                                                  // false
bad.Violations.Select(v => v.Code);                           // Required, UnknownField

// Write.
using var w = AnvilWriter.Create(AnvilDialect.Amp);
string text = w.Statement("status").Bare("ok").Statement("code").Value(200L).Finish();
```

A parse failure still gives you a usable document: always check `doc.HasErrors`. `docs/getting-started.md` is a
task-oriented walkthrough of the reading API.

## Reading

```csharp
using var doc = AnvilDocument.Load("config.anvl");
if (doc is null || doc.HasErrors) { /* doc.Error?.Message / .Line / .Column */ }

if (doc.FindValue("server") is { Type: AnvilValueType.Object } server)
{
    string? name = server["name"]?.AsString();
    int? port = server["port"]?.AsInt();
}

foreach (var stmt in doc.Statements) { /* stmt.Name, stmt.Value */ }

foreach (var included in doc.Includes)
{
    using (included) { /* independently disposable, shares doc's parse context */ }
}
```

`AnvilDocument` is the one `IDisposable` root that owns the native lifetime; `AnvlValue`, `AnvlStatement` and
`AnvilAttribute` are lightweight, non-disposable views navigated lazily, each accessor a direct call into Anvil
Native's vtable ABI. Nothing is materialized into a tree up front. Using a disposed document throws
`ObjectDisposedException`; the values, statements and attributes you took from it are only valid while it is alive.

## Type registry and schema

Anvil Native's type registry and AnvilSchema, over the `TypeRegistry`
and `Schema` vtables. Both are self-contained copies, so they outlive the `AnvilDocument` they
were loaded from; both are `IDisposable`, and the views they hand out (`AnvilTypeDef`,
`AnvilSchemaField`) throw `ObjectDisposedException` once their owner is disposed.

```csharp
using var schemaDoc = AnvilDocument.Load("asset.schema.anvl");   // carries @[schema]; may include @[types]
using var schema = AnvilSchema.Load(schemaDoc)!;                  // null if it has no @[schema]

using var data = AnvilDocument.LoadBuffer("#!aml\nname := \"widget\";\nstatus := scrapped;\n")!;
AnvilSchemaValidation result = schema.Validate(data);             // snapshot: IsValid + Violations
foreach (AnvilSchemaViolation v in result.Violations)             // Code (AnvilSchemaViolationCode), Field, Message
    Console.WriteLine($"{v.Code} at {v.Field}: {v.Message}");

// A request body's `set` object, validated without loading a second document:
using var fragment = AnvilDocument.ParseValueFragment("{ name := \"widget\"; }")!;
schema.ValidateValue(fragment.FragmentValue!, new AnvilValidationOptions(SkipRequired: true));

// ...or straight from document text (same shape as `anvil-node`'s `validateField`):
schema.ValidateField("#!aml\nset := { name := \"widget\"; };\n", "set");

using var typesDoc = AnvilDocument.Load("asset.types.anvl")!;
using var registry = AnvilTypeRegistry.Load(typesDoc)!;           // or FromIncludes(doc) for the types.X namespace
AnvilTypeDef year = registry.Find("AssetYear")!;                  // Resolve() also answers for Numeric, String, ...
year.TryGetMin(out long min);                                     // false when not declared, never a default
AnvilNumeric? bound = year.Max;                                   // exact: AsLong() / AsDouble(), Overflowed
```

- **Exact bounds.** `TryGetMin`/`TryGetMax`/`TryGetSize(out long)` are the integer getters (false when
  not declared, or not an integer that fits); `Min`/`Max` (`AnvilNumeric?`) read any bound exactly,
  including fractional ones (`min := 0.5;`) and ones that overflow `long`.
- **`ValidateField(text, name, options)`** parses the text, finds the top-level statement, and
  validates its object value. An absent statement is one `Required` violation with an empty
  `Field`; one that isn't an object is the native `TypeMismatch`; text that doesn't parse is a
  `FormatException`. A batch (`set := [ {...}, ... ]`) is validated by iterating the array and
  calling `ValidateValue` on each element. Text identical to a document you already hold loads
  independently of it, and a parse error carries native's real message (a missing `;` reads
  `Expected ';' to end the statement`).
- **Introspection.** `schema.Fields`/`FindField` give each rule's `Kind`, `TypeName`, `IsRequired`,
  `IsNullable`, `IsInteger`, `Min`/`Max`, `TryGetMinItems`/`TryGetMaxItems`, `Values`, `Format`,
  `Tag` (blobs), `Nested` fields, the array `Items` rule, and `Extras` (extension keys such as
  FlyWire's `pooled`, as readable `AnvlValue`s owned by the schema).
- **Diagnostics.** `registry.Diagnostics` and `schema.Diagnostics` are what loading reported
  (`NameCollision`, `UnknownType`, ...); whether any is fatal is the caller's call.
- **Enums** (`AnvilTypeKind`, `AnvilTypeDiagnosticCode`, `AnvilSchemaViolationCode`,
  `AnvilSchemaDiagnosticCode`) mirror the C headers value for value.

## Attributes

`@[...]` attributes hang off the document (module attributes) and off any statement: `doc.Attributes` /
`doc.FindAttribute(key)`, and `statement.Attributes` / `statement.FindAttribute(key)`.

```csharp
using var doc = AnvilDocument.LoadBuffer("#!aml\n@[version=\"1.2\"]\nticket @[type=bug, urgent] := 1;\n")!;
doc.FindAttribute("version")!.Value;                      // "\"1.2\""  (raw: the quotes are kept)
doc.FindAttribute("version")!.DecodedValue!.AsString();   // "1.2"
var ticket = doc.FindStatement("ticket")!;
ticket.FindAttribute("type")!.Value;                      // "bug"
ticket.FindAttribute("urgent")!.Value;                    // null: a flag has no value
ticket.FindAttribute("urgent")!.DecodedValue;             // null
```
- **Attributes have a raw `Value` and a typed `DecodedValue`.** `AnvilAttribute.Value` is native's source text
  (`status="done"` is `"done"` with its quotes, a flag is `null`). `DecodedValue` reads the same attribute as an
  `AnvlValue` (native `anvil_attribute_get_value_handle`): escapes resolved, delimiters stripped, typed.
  `status="done"` is a `String` `done`, `note="a\"b"` is `a"b`, `n=42` a `Numeric` 42 (`AsInt()`), `type=bug` a
  `Bare` `bug`. It is `null` for a flag; an explicit `@[x=null]` is a `Null` value, which is not the same thing.
  A value the scalar grammar does not accept whole (`@[range=1..5]`) is a `Bare` value of its raw text.

## Writing

```csharp
// streaming: forward-only, chainable; the first rejected call throws and is sticky
using var w = AnvilWriter.Create(AnvilDialect.Aml);
string text = w.Statement("server").BeginObject()
    .Statement("host").Bare("localhost")
    .Statement("port").Value(8080L)
    .EndObject().Finish();

// builder: create values detached, attach them in any order, emit (and re-emit) at will
using var b = AnvilBuilder.Create(AnvilDialect.Aml);
AnvilNode server = b.Object();
server.Add("host", b.Bare("localhost"));
b.Add("server", server).Attribute("env", "production");
string text2 = b.Emit();
```

Both throw `AnvilWriterException` (with an `AnvilWriterErrorCode`) when Anvil Native rejects a call; the
native library owns every grammar rule. Reading is exact: `AsLong()`/`AsInt()` are exact or `null`
(never wrapped), with `AsBigInteger()`, `AsDouble()`, `AsNumericText()`, `IsIntegral()`, `AsBytes()`,
`BlobTag()` and `RawBytes()` beside them. `FinishBytes()`/`EmitBytes()` and
`AnvilDocument.LoadBuffer(byte[])` carry non-UTF-8 blob bytes without a lossy `string` hop.

## Development

Everything below is for working on this repository. None of it applies to the prebuilt package.

### Building from source

```sh
git clone --recurse-submodules <this repository>
make -C vendor/anvil so-release   # produces vendor/anvil/lib/release/libanvil.so
dotnet build
dotnet test
```

`vendor/anvil` is a git submodule pinned to a commit on `anvil`'s `main`. `Anvil.Net.csproj` runs its `make so-release`
on every build and copies the library beside the assembly (and into `src/Anvil.Net/runtimes/linux-x64/native/`, the
standard NuGet layout). Bump the submodule, rebuild.

### Building a local NuGet package

`dotnet pack -c Release` builds a **local** package, `Anvil.Net.<version>.nupkg`, into `src/Anvil.Net/bin/Release`; it
carries the assembly and `runtimes/linux-x64/native/libanvil.so`, so a `PackageReference` is enough once its folder is a
restore source. It is a build-it-yourself convenience: the release tarball does not contain it. The version is the
`<Version>` in `Anvil.Net.csproj` (`0.10.0-rc` at the release). NuGet caches by version
(`~/.nuget/packages/anvil.net/<version>`), so a consumer would silently keep an old package if you rebuild it under the
same version: bump the `<Version>` whenever the packaged library or assembly changes, and `make -C vendor/anvil clean` first
at pins before the build-number fix.

### The version string

The native library reports `MAJOR.MINOR.PATCH` plus a build number, and the build number comes from native's own
Makefile: the commit count of `vendor/anvil`, or `make -C vendor/anvil so-release BUILD_NUM=<n>` to set it (a release
build passes the tag's number). At older pins the library keeps a stale number after a submodule bump unless you
`make -C vendor/anvil clean` first, because a changed number alone does not force `anvil.o` to rebuild; do that before
`dotnet pack`. A tree without git metadata gets 0, which native reports as no `+BUILD`. .NET needs no build-side change
of its own.

### Design: lazy, OOP-native, not a JSON-blob port

`anvil-node` and `anvil-wasm` convert a whole parsed document into one JSON string natively and cross the boundary once,
the right call for them because N-API and WASM crossings are expensive. P/Invoke doesn't have that problem (a call with
blittable types costs tens of nanoseconds), and Anvil Native's vtable ABI (`anvil_vtable.h`) was designed for exactly this:
real, lazy, on-demand navigation through direct calls, no serialization anywhere. C#'s `using`/`Dispose()` is
deterministic, unlike a JS wrapper's GC-finalizer timing. Loads are independent, so two live documents with identical
text are fine.

### Testing scope

Marshaling-layer correctness only; never re-tests ANVL grammar (`vendor/anvil`'s own regression owns that). xUnit,
`dotnet test`: a drift gate that checks every vtable struct and native enum against the real C header field for field,
the type registry and schema, exact numeric/blob/raw-bytes reads, the writer and the builder, document lifecycle and
error reporting, navigation, attributes, the iterators (with disposal), NUL handling, and a direct proof that the
binding is built against the post-rename core (`include` works, `import` is rejected). Every change is test-first.

### Distribution

An `anvildata.com` tarball (a prebuilt `Anvil.Net.dll` plus the `libanvil.so` it links against), in parity with the
`anvil-node`, `anvil-wasm` and `anvil-py` tarballs. See the [Bindings guide](https://anvldata.com/docs#Bindings-Guide.md)
for the full write-up. A published NuGet package is planned, not done (building one yourself is described above); the project is `runtimes/{rid}/native/`-ready, and
only `linux-x64` is built and verified.

### Repo layout

```
anvil.net/
├── vendor/anvil/              (submodule: the native library source)
├── src/Anvil.Net/             (the managed binding)
├── test/Anvil.Net.Tests/      (xUnit, marshaling-layer only)
├── docs/getting-started.md    (task-oriented walkthrough)
└── CHANGELOG.md
```
