# anvil-node

Node.js bindings for **Anvil Native**, the reference C implementation of the ANVL (AML/AMP/ASL)
parser. Parse ANVL text into plain JavaScript, validate it against a schema, and write it back out,
with the same parser every other Anvil binding uses. Documentation: https://anvldata.com/docs

## Installing the prebuilt package

The package ships a compiled N-API addon, so installing it needs no compiler and no build step.

- **Platform:** Linux x64 only. The addon is not built for other platforms or architectures.
- **Node.js:** current LTS releases (tested on Node 22).

```
npm install <tarball URL or path>
```

then:

```js
const anvil = require('anvil-node');
```

If `require` fails to load `anvil_node.node`, you are on an unsupported platform, or the tarball is
not the prebuilt one; see "Building from source" under Development.

## Quick start

```js
const { parse, Schema, AnvilWriter, AnvilDialect } = require('anvil-node');

// Parse. The document is converted to plain JS values in one call; there is no native handle to free.
const doc = parse('#!aml\n@[version="1.2"]\nticket @[type=bug] := { id := 7; title := "login fails"; };\n');
doc.findAttribute('version').decodedValue;          // '1.2'
const ticket = doc.statement('ticket');
ticket.findAttribute('type').value;                 // 'bug'
ticket.value.get('title').asString();               // 'login fails'

// Validate. A schema is an ANVL document carrying @[schema]; the data to check is ANVL text too.
const schema = Schema.load('#!aml\n@[schema]\nasset_id := { type := Numeric; required := true; };\n');
const ok  = schema.validateField('set := { asset_id := 7; };\n', 'set');
ok.valid;                                           // true
const bad = schema.validateField('set := { name := "x"; };\n', 'set');
bad.valid;                                          // false: bad.violations lists what failed
schema.dispose();

// Write.
const w = AnvilWriter.create(AnvilDialect.AMP);
const text = w.statement('status').bare('ok').statement('code').value(200).finish();
w.dispose();
```

`parse()` and `parseRawValue()` return `null` on failure and set `lastError()`.

## Parsing

```js
const doc = anvil.parse(source);       // full document parse
doc.hasAttribute('schema')             // module-level attribute check
for (const [name, value] of doc.entries()) { ... }  // top-level statements
value.get('type').asString()           // object-field access
value.has('values') && value.get('values').at(i).asString()

const plain = anvil.parseRawValue(text);  // Value Fragment -> plain JS, no AnvlNode at all
anvil.lastError();                        // { message, line, column } after a null return
anvil.getVersion();                       // the native library's version string
```

Two JS-facing shapes, both **eager**:

- **`parse()`** returns an `AnvlNode` (`.get()`, `.has()`, `.hasAttribute()`, `.at()`, `.count`,
  `.entries()`, `.asString()`/`.asBool()`/`.asInt()`, `.type`) wrapping an already-fully-converted plain JS
  value. `.type` is one of `'object'`, `'array'`, `'tuple'`, `'scalar'` or `'blob'`, so `[1,2]` (an array) is
  told apart from `(1,2)` (a tuple), and a plain string from a blob. The whole document is converted to plain
  JS, and the native document freed, inside the one synchronous `parse()` call.
- **`parseRawValue()`** returns a plain JS value (number, string, boolean, null, array, object) directly, with
  no wrapper. It returns `null` both for a parse failure and for a genuine ANVL `null`; `lastError()` tells
  them apart (it is `null` after a successful parse).

**Integers beyond 2^53.** An integer literal that fits the safe range (|n| <= 2^53 - 1) is a JS `Number`, as ever. One
outside it is an exact `BigInt`, never a rounded `Number`: `parseRawValue('9223372036854775807')` is
`9223372036854775807n`, and so is a literal past int64 (ANVL numbers are unbounded, and `AnvilWriter.value()` writes any
`bigint` as exact text, so what you write reads back). Decimals and exponent forms (`1.5`, `1e+20`) are not integer
literals and stay `Number`s. On an `AnvlNode`, `asInt()` returns a `Number` for a safe integer
and the exact `BigInt` otherwise (for a float literal it is the truncated value, as ever). An attribute's
`decodedValue` follows the same rule; its raw `value` is the source text. Mixing a `BigInt` with a `Number` in
arithmetic throws a `TypeError`, so a value that used to be silently rounded now fails loudly.

**A number's exact value and literal kind.** `2020` and `2020.0` are the same number but different literals, and
`AnvlNode` tells them apart:

| | `2020` | `2020.0` / `5.` / `5e+3` | `2020.7` | `9007199254740993` | not a number |
|---|---|---|---|---|---|
| `numericKind` | `'integer'` | `'float'` | `'float'` | `'integer'` | `null` |
| `asNumber()` | `2020` | `2020` / `5` / `5000` | `2020.7` | `null` (no exact `Number`) | `null` |
| `asBigInt()` | `2020n` | `null` | `null` | `9007199254740993n` | `null` |
| `asInt()` | `2020` | `2020` | `2020` | `9007199254740993n` | `null` |

The kind is the literal's spelling: no `.` and no exponent is an integer literal, anything else is a float literal,
even when its value is integral. `asNumber()` is the double a float literal denotes (`Infinity` for one that
overflows). So an integer field can reject `2020.7` with `Number.isInteger(node.asNumber())` and `2020.0` with
`node.numericKind === 'float'`. `parseRawValue()` returns plain values, which carry no kind: `2020.0` is the number
`2020` there. The exponent sign is optional (`1e3` is the float `1000`); a trailing-dot number such as `5.` or `5.e3`, and an exponent with no digits (`1e`, `1e+`), are parse errors (`null` with `lastError()`).

## Type registry and schema

Anvil Native's type registry and AnvilSchema, over ANVL source text:

```js
const { Schema, TypeRegistry, SchemaViolation } = require('anvil-node');

const schema = Schema.load(schemaText);            // text of a document carrying @[schema]
const result = schema.validate(dataText);          // { valid, violations: [{ category, field, message }] }
const body   = schema.validateValue('{ asset_id := 7; name := "widget"; }',
                                    { skipRequired: false, allowUnknown: false });
result.violations.some((v) => v.category === SchemaViolation.REQUIRED);
schema.diagnostics;                                // load-time findings, see below
schema.validateField(wireText, 'set');             // validate a statement of a document you already hold as text
schema.findField('asset_id');                      // introspection: schema.fields / findField(name)
schema.dispose();

const reg = TypeRegistry.load(typesText);          // a document carrying @[types]
reg.find('VIN');                                   // TypeDef | null (the registry's own types)
reg.resolve('String');                             // also answers for the built-in types
reg.find('VIN').min;                               // undefined when not declared, 0 for `min := 0;`
reg.diagnostics; reg.loadError; reg.dispose();
```

- **Input is ANVL text, not JS objects.** ANVL is not JSON (`{"a":1}` does not parse; objects use
  `:=`), and a wire body is already ANVL. `validateValue` takes an object value as text for that
  reason. Building ANVL text from a JS value is the writer's job (see "Writing ANVL").
- **Where includes resolve.** `loadFile`/`fromIncludesFile` resolve a document's `include`s
  relative to that file. The text forms (`load`, `fromIncludes`) resolve them against the process's
  current working directory, so a schema that includes `@[types]` documents should come from
  `Schema.loadFile(path)`. A text document whose include cannot be found fails to load, except
  through `fromIncludes`, which returns an empty registry with the problem in `loadError`.
- **Failures return `null`** and set `lastError()`, like `parse()`: not a `@[schema]`/`@[types]`
  document, or a document that does not parse. `validate()`/`validateValue()` return `null` the
  same way when the data does not parse.
- **`fromIncludes*` tolerates a consumer-document error.** A name defined by two included
  `@[types]` documents collides in the consumer's own namespace; Anvil Native still builds the
  registry and reports it as a `NAME_COLLISION` diagnostic. The document's error is kept on
  `registry.loadError` (`{ message, line, column }` or `null`), not thrown away.
- **Lifetime.** Native schemas and registries are self-contained copies, so the source document is
  parsed, loaded and disposed inside the one `load` call, and the no-live-`anvil_document` rule
  above still holds. The `Schema`/`TypeRegistry` handle itself lives until `dispose()` or GC. It is
  an N-API external with a finalizer, so there is no `FinalizationRegistry`. Using a disposed
  handle throws; a second `dispose()` is a no-op. `TypeDef`s, violations and diagnostics are
  plain snapshots and stay readable after `dispose()`.
- **Dispose in tight loops.** Node runs finalizers on a later event-loop turn, so a synchronous loop
  that abandons handles holds them until it yields. Call `dispose()` there.
- **Enums** (`TypeKind`, `TypeDiagnostic`, `SchemaViolation`, `SchemaDiagnostic`) are frozen
  objects with the C names minus their prefix.
- **`validateField(docText, name, opts)`** parses the text, finds the top-level statement `name` and
  validates its object value, in one native call: `validateValue` for a request body you already
  hold as ANVL text, without a second parse from JS. Same `{ valid, violations }` result and the
  same `skipRequired`/`allowUnknown` options. An absent statement is one `REQUIRED` violation with
  an empty `field` (the same as `anvil.net`'s `ValidateField`); a statement that is not an object is
  the native `TYPE_MISMATCH`; text that does not parse is `null` with `lastError()` set.
  **`{ each: true }`** treats an array or tuple value as a batch (`set := [ {...}, ... ]`): every
  element is validated with the same options and its violations are reported at `[i]` and
  `[i].field`. A single object still validates under `each`. Unlike `anvil.net`, a JS caller
  cannot iterate the batch itself, because `parse()` hands back no per-element native handle.
- **Introspection.** `schema.fields` and `schema.findField(name)` return `SchemaField` snapshots
  (readable after `dispose()`), each with `name`, `kind`, `typeName` (as written, e.g.
  `'types.Id32'`), `required`, `nullable`, `integer`, and, when declared, `size`, `min`, `max`,
  `minItems`, `maxItems`, `values`, `format` and `tag`. Inherited constraints are already folded in;
  an undeclared one is `undefined`, never a default. `nested` (an object rule's fields) and
  `findNested(name)`, `items` (an array rule's element rule, whose `name` is `''`) and `extras`
  (extension keys such as FlyWire's `pooled`, each `{ name, value }` with `value` an `AnvlNode`)
  cover the rest.
- **Known limits.** `min`/`max` are JS numbers, so a bound past 2^53 loses precision, and one that
  overflows `int64`/`double` is `undefined`, because native offers no text accessor for it.

## Attributes and statements

`parse()` exposes attributes and statements with the same names and meaning as `anvil-py` and
`anvil-net` (`AnvlStatement.attributes`/`find_attribute`), in JS idiom:

```js
const doc = anvil.parse('#!aml\n@[version="1.2"]\nticket @[type=bug, urgent] := { step @[status="done"] := 1; };\n');

doc.attributes;                         // [{ key: 'version', value: '"1.2"' }]   module attributes (root only)
doc.findAttribute('version').value;     // '"1.2"'; null when absent
doc.hasAttribute('version');            // true (unchanged)

const ticket = doc.statement('ticket'); // the first statement with that name, or null
ticket.name;                            // 'ticket'
ticket.attributes;                      // [{ key: 'type', value: 'bug' }, { key: 'urgent', value: null }]
ticket.findAttribute('type').value;     // 'bug' (raw); .decodedValue is the decoded, typed form
ticket.value.statements();              // the object's statements, in order: [AnvlStatement { name: 'step', ... }]
```

- **An attribute has a raw `value` and a `decodedValue`.** `value` is native's text for it, uninterpreted: a
  quoted string keeps its quotes (`status="done"` is `'"done"'`), a bare value is as written (`type=bug` is
  `'bug'`), and a flag (`@[urgent]`) is `null`. This is what `anvil-py`'s and `anvil-net`'s `AnvilAttribute.value`
  return. `decodedValue` reads the same attribute as a value (native `anvil_attribute_get_value_handle`): escapes
  resolved, delimiters stripped, and typed. `status="done"` is `'done'`, `note="a\"b"` is `a"b`, `n=42` is the
  number `42`, `b=true` is `true`, and `range=1..5` (not a scalar, so native exposes it as a bare word) is the
  string `'1..5'`. It is `null` for a flag and for an explicit `@[x=null]`; `value` tells them apart (`null` for the
  flag, `'null'` for the explicit one). A number past 2^53 loses precision, as in `parseRawValue()`.
- **A repeated name inside an object** (ANVL allows it; only the top level rejects it) counts once per
  occurrence, as in native, `anvil-py` and `anvil-net`: for
  `{ a := 1; a := 2; b := 3; }`, `count` is 3, `get('a')` and `statement('a')` are the **first** (`1`),
  and `entries()` and `statements()` yield all three in order. `has(name)` is true if any occurrence
  has that name. A document with no repeated names behaves exactly as before. A plain object built
  from `entries()` in order (as a `{ [name]: value }` conversion does) still ends up last-wins, by
  assignment; `parseRawValue()` returns a plain JS object, so a repeated name there is last-wins by
  construction. `statements()` is `[]` for a value that is not an object, and module attributes belong
  to the root: any other node's `attributes` is `[]`.
- **Attribute values are NUL-safe**, like every other text this binding returns.

## Writing ANVL

Anvil Native's streaming writer and document builder, in the same shape as `anvil.py` and
`anvil.net`. The native library owns every rule (dialect grammar, escaping, identifiers); AMP's
forbidden constructs are rejected at write time.

```js
const { AnvilWriter, AnvilBuilder, AnvilDialect } = require('anvil-node');

const w = AnvilWriter.create(AnvilDialect.AMP);        // streaming: forward-only, chainable
const text = w.statement('status').bare('ok')
              .statement('code').value(200)
              .statement('tags').beginArray().bare('a').bare('b').endArray()
              .finish();                                // '#!amp\n\nstatus := ok;\n...'
w.dispose();

const b = AnvilBuilder.create(AnvilDialect.AML);       // builder: attach in any order, re-emit at will
const server = b.object();
server.add('host', b.bare('localhost'));
b.add('server', server).attribute('env', 'production');
const text2 = b.emit();
b.dispose();
```

- **Values.** `value(x)` takes `null`, a boolean, a number or a `bigint`: a safe integer is written
  exactly, a `bigint` past `int64` as its exact decimal text (ANVL numbers are unbounded), any other
  number as a double. A string is ambiguous, so `value('x')` is a `TypeError`: use `string()`
  (quoted) or `bare()` (unquoted). `numeric(text)` takes ANVL numeric text (the exponent needs its
  sign: `1.5e+3`). `blob(tag, data)` takes bytes or a string; `tag` may be `null`.
- **Errors.** A native rejection is an `AnvilWriterError` with a `.code` (`WriterErrorCode`). The
  writer's first error is **sticky**: every later call throws the same code. The builder's are
  not: a failed call changes nothing, and what is only known once the tree is complete (an empty
  array, a one-element tuple) fails at `emit()` with the builder intact.
- **Arguments are checked before native code.** A wrong type is a `TypeError`; an embedded NUL in a
  NUL-terminated name is a `RangeError` (native code would silently truncate); a node from another
  builder, or any use after `dispose()`, is an `Error`.
- **Output.** `finish()` / `emit()` return a string and `finishBytes()` / `emitBytes()` a `Buffer`
  of the exact bytes. `dispose()` is idempotent; the handle is an N-API external with a finalizer,
  so an abandoned one is reclaimed on GC (call `dispose()` in a tight synchronous loop).
- **Blobs.** Content is written byte-exact, but a backtick in it is rejected (`INVALID_BLOB`): a
  blob has no escape for its delimiter. **Reading non-UTF-8 blob bytes back is not possible yet:**
  the loader takes a JS string, which cannot carry them. UTF-8 blob content round-trips.

## Development

Everything below is for working on this repository. None of it applies to the prebuilt package.

### Building from source

```
git clone --recurse-submodules <this repository>
npm install
npm run build     # node-gyp rebuild
npm test
```

Requires a C compiler with C2x support (matching Anvil Native's own `-std=c2x`), Python 3 for node-gyp
itself, and Linux. `binding.gyp` passes `-std=c2x -Wall -Wextra` and `_POSIX_C_SOURCE=200809L`
(needed for `ssize_t`, matching `anvil`'s own `test/unit/Makefile`) to every vendored `.c` file.

Anvil's allocator is `sigma.system.alloc`, a machine-level install and not vendored. The build links
`/usr/local/packages/sigma.system.alloc.o` and includes `/usr/local/include`, the same two fixed paths Anvil's
own `Makefile` uses. Install it once per machine before `npm run build`.

The addon exports only the N-API entry points. `exports.map` is a linker version script that enforces this on
Linux, because the vendored headers mark Anvil's public API `visibility(default)` and that would otherwise leak
through a static link. `test/vendor-pin.test.js` checks the export list, so run `npm run build` before `npm test`.

### The version string

The `+BUILD` in `getVersion()` is the build number `scripts/build-number.js` resolves and `binding.gyp` passes as
`ANVL_BUILD`: `ANVL_BUILD=<n> npm run build` if you set it (a release build passes the tag's number), else the
commit count of `vendor/anvil` when that is a full git checkout, else 0, which Anvil Native reports as no `+BUILD`.

### Why a submodule, not a package dependency

`vendor/anvil` is a git submodule pinned to a real commit on `anvil`'s `main`, and `binding.gyp` compiles the
vendored `.c` files directly as part of this addon's own build. No separate native library to keep in sync by
hand: bump the submodule, rebuild. This repo does only marshaling and wrapper-layer code, never a second copy
of parser logic.

### Why `parse()` doesn't hold a native handle

An earlier design was a *lazy* `parse()`: a wrapper holding a live `anvil_document`, disposed by an N-API
finalizer once the JS wrapper was collected. It was built and then reverted. Anvil Native's source registry
rejects a second registration of byte-identical content while an earlier one is still registered (correct for
its purpose, include-graph dedup), and GC finalizer timing is never deterministic, so two `parse()` calls on
identical text could race and fail unpredictably. (Native has since made loads of identical text independent, so
that particular failure no longer exists; the eager shape is kept because it needs no native lifetime bridging
and costs one crossing.) Anvil Native's job is primitives, not policy, so the binding works with its contract
in whatever way is idiomatic for its runtime: for JS, plain GC'd values.

### Testing scope

Tests here cover the marshaling and wrapper layer only (does a JS number come back as a JS number, does
disposal run, does an N-API external get finalized), never re-proving parse correctness, which is `anvil`'s own,
already-covered responsibility. Every change is test-first; native and marshaling work is checked Valgrind-clean.

### Repo layout

```
binding.gyp            # node-gyp build config: vendored .c sources + src/binding.c + src/writer_binding.c
exports.map            # linker version script: only the N-API entry points are exported
src/                   # N-API glue (this repo's only real C source)
vendor/anvil/          # git submodule, pinned to a commit on TheBadkraft/anvil main
lib/index.js           # JS-facing wrapper: AnvlNode, AnvlStatement, Schema, TypeRegistry, writer, builder
scripts/               # build-number.js
test/                  # marshaling-layer tests
CHANGELOG.md           # per-change history
```
