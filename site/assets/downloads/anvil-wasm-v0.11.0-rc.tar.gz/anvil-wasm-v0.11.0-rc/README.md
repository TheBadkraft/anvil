# anvil-wasm

**Anvil Native** compiled to WebAssembly: the reference C implementation of the ANVL (AML/AMP/ASL) parser,
for the browser and for Node.js. Parse ANVL text into plain JavaScript, validate it against a schema, and
write it back out, with the same parser every other Anvil binding uses and the same API as `anvil-node`.
Documentation: https://anvldata.com/docs

## Installing the prebuilt package

The package ships the compiled module (`dist/anvil.js`, `dist/anvil.wasm` and the script-tag bundle `dist/anvil.browser.js`), so installing it
needs no compiler and no Emscripten. It runs wherever WebAssembly does, so unlike `anvil-node` it is not tied
to Linux x64.

```
npm install <tarball URL or path>
```

- **Node.js:** `const anvil = require('anvil-wasm');` (tested on Node 22).
- **Browser, with a bundler:** import `anvil-wasm` as above. Keep `dist/anvil.wasm` beside `dist/anvil.js`;
  the module fetches it at startup.
- **Browser, without a bundler:** load the prebuilt bundle with a `<script>` tag (see below). It defines `window.anvl`,
  the full API this README describes, and needs no `require`.

Module loading is asynchronous, so **call and await `ready()` once before anything else**. Every operation
after that is a plain synchronous call.

### Script tag

```html
<script src="/vendor/anvil/anvil.browser.js"></script>
<script>
  anvl.ready().then(() => {
    const doc = anvl.parse('#!aml\nanswer := 42;\n');
    console.log(doc.get('answer').asInt());   // 42
  });
</script>
```

`dist/anvil.browser.js` is `lib/index.js` and the Emscripten glue in one file. `window.anvl` is exactly the
`require('anvil-wasm')` API: `ready`, `parse`, `parseRawValue`, `lastError`, `getVersion`, `AnvlNode`, `AnvilWriter`,
`AnvilBuilder`, `AnvilDialect`, `Schema`, `TypeRegistry` and the error classes. `anvil.wasm` is a separate file, so a
server can send it as `application/wasm` and a service worker can cache it.

By default `ready()` fetches `anvil.wasm` from **next to the script**. Serve both files from one directory, or say
where the `.wasm` is:

```js
await anvl.ready({ wasmUrl: '/assets/anvil.wasm' });
// or, Emscripten's own hook (called with 'anvil.wasm' and the script's directory):
await anvl.ready({ locateFile: (file, scriptDirectory) => `/assets/${file}` });
```

`ready(options)` takes `{ locateFile }` or `{ wasmUrl }`, not both (a `TypeError`). The options apply to the first
call; later calls return the same load. A load that fails (offline, 404) can be retried with `ready()` again. The
CommonJS entry accepts the same options (`wasmUrl` is then a file path or URL), with the same meaning.

**Service worker.** Precache both files, from the same URLs the page uses, so an installed app starts offline:

```js
// sw.js
const ASSETS = ['/vendor/anvil/anvil.browser.js', '/vendor/anvil/anvil.wasm'];
self.addEventListener('install', (e) => e.waitUntil(caches.open('anvil-v1').then((c) => c.addAll(ASSETS))));
self.addEventListener('fetch', (e) => e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request))));
```

Serve the `.wasm` with `Content-Type: application/wasm` (the browser's streaming compile requires it; without it
Emscripten falls back to a slower path). Bump the cache name when you update the package, so the script and the
`.wasm` always come from the same build.

## Quick start

```js
const anvil = require('anvil-wasm');
await anvil.ready();

// Parse. The document is converted to plain JS values in one call; there is no native handle to free.
const doc = anvil.parse('#!aml\n@[version="1.2"]\nticket @[type=bug] := { id := 7; title := "login fails"; };\n');
doc.findAttribute('version').decodedValue;          // '1.2'
const ticket = doc.statement('ticket');
ticket.findAttribute('type').value;                 // 'bug'
ticket.value.get('title').asString();               // 'login fails'

// Validate. A schema is an ANVL document carrying @[schema]; the data to check is ANVL text too.
const schema = anvil.Schema.load('#!aml\n@[schema]\nasset_id := { type := Numeric; required := true; };\n');
const ok  = schema.validateField('set := { asset_id := 7; };\n', 'set');
ok.valid;                                           // true
const bad = schema.validateField('set := { name := "x"; };\n', 'set');
bad.valid;                                          // false: bad.violations lists what failed
schema.dispose();

// Write.
const w = anvil.AnvilWriter.create(anvil.AnvilDialect.AMP);
const text = w.statement('status').bare('ok').statement('code').value(200).finish();
w.dispose();
```

`parse()` and `parseRawValue()` return `null` on failure and set `lastError()`.

## Parsing

```js
await anvil.ready();                   // once, before anything else
const doc = anvil.parse(source);       // full document parse
doc.hasAttribute('schema')             // module-level attribute check
for (const [name, value] of doc.entries()) { ... }  // top-level statements
value.get('type').asString()           // object-field access
value.has('values') && value.get('values').at(i).asString()

const plain = anvil.parseRawValue(text);  // Value Fragment -> plain JS, no AnvlNode at all
anvil.lastError();                        // { message, line, column } after a null return
anvil.getVersion();                       // the native library's version string
```

Two JS-facing shapes, both **eager**:

- **`parse()`** returns an `AnvlNode` (`.get()`, `.has()`, `.hasAttribute()`, `.at()`, `.count`,
  `.entries()`, `.asString()`/`.asBool()`/`.asInt()`, `.type`) wrapping an already-fully-converted plain JS
  value. `.type` is one of `'object'`, `'array'`, `'tuple'`, `'scalar'` or `'blob'`, so `[1,2]` (an array) is
  told apart from `(1,2)` (a tuple), and a plain string from a blob. The whole document is converted to plain
  JS, and the native document freed, inside the one synchronous `parse()` call, as a single JSON string built in C: one
  crossing between JS and WebAssembly per call, not one per field.
- **`parseRawValue()`** returns a plain JS value (number, string, boolean, null, array, object) directly, with
  no wrapper. It returns `null` both for a parse failure and for a genuine ANVL `null`; `lastError()` tells
  them apart (it is `null` after a successful parse).

**Integers beyond 2^53.** An integer literal that fits the safe range (|n| <= 2^53 - 1) is a JS `Number`, as ever. One
outside it is an exact `BigInt`, never a rounded `Number`: `parseRawValue('9223372036854775807')` is
`9223372036854775807n`, and so is a literal past int64 (ANVL numbers are unbounded, and `AnvilWriter.value()` writes any
`bigint` as exact text, so what you write reads back). Decimals and exponent forms (`1.5`, `1e20`, `1e+20`) are not integer
literals and stay `Number`s. The exponent sign is optional (`1e3` is the float 1000). A malformed number is a native
error at every depth, fragments included: `parse()` and `parseRawValue()` return `null` and `lastError()` says why for `5.`,
`-5.`, `5.e3`, `1e`, `1e+` and `1e-`. On an `AnvlNode`, `asInt()` returns a `Number` for a safe integer
and the exact `BigInt` otherwise (for a float literal it is the truncated value, as ever). An attribute's
`decodedValue` follows the same rule; its raw `value` is the source text. Mixing a `BigInt` with a `Number` in
arithmetic throws a `TypeError`, so a value that used to be silently rounded now fails loudly.

**A number's exact value and literal kind.** `2020` and `2020.0` are the same number but different literals, and
`AnvlNode` tells them apart:

| | `2020` | `2020.0` / `5.` / `5e+3` | `2020.7` | `9007199254740993` | not a number |
|---|---|---|---|---|---|
| `numericKind` | `'integer'` | `'float'` | `'float'` | `'integer'` | `null` |
| `asNumber()` | `2020` | `2020` / `5` / `5000` | `2020.7` | `null` (no exact `Number`) | `null` |
| `asBigInt()` | `2020n` | `null` | `null` | `9007199254740993n` | `null` |
| `asInt()` | `2020` | `2020` | `2020` | `9007199254740993n` | `null` |

The kind is the literal's spelling: no `.` and no exponent is an integer literal, anything else is a float literal,
even when its value is integral. `asNumber()` is the double a float literal denotes (`Infinity` for one that
overflows). So an integer field can reject `2020.7` with `Number.isInteger(node.asNumber())` and `2020.0` with
`node.numericKind === 'float'`. `parseRawValue()` returns plain values, which carry no kind: `2020.0` is the number
`2020` there. A trailing-dot number such as `5.` is accepted by Anvil Native and reads as the float `5`.

## Type registry and schema

Anvil Native's type registry and AnvilSchema, over ANVL text. Same API and result shapes as `anvil-node`, so a
caller has one API on the server and in the browser.

```js
const anvil = require('anvil-wasm');
await anvil.ready();

const schema = anvil.Schema.load(schemaText);       // text of a document carrying @[schema]
const result = schema.validate(dataText);           // { valid, violations: [{ category, field, message }] }
const body   = schema.validateValue('{ asset_id := 7; name := "widget"; }',
                                    { skipRequired: false, allowUnknown: false });
result.violations.some((v) => v.category === anvil.SchemaViolation.REQUIRED);
schema.validateField(wireText, 'set');              // validate a statement of a document you already hold as text
schema.findField('asset_id');                       // introspection: schema.fields / findField(name)
schema.diagnostics;                                 // load-time findings
schema.dispose();

const reg = anvil.TypeRegistry.load(typesText);     // a document carrying @[types]
reg.find('VIN');                                    // TypeDef | null (the registry's own types)
reg.resolve('String');                              // also answers for the built-in types
reg.diagnostics; reg.loadError; reg.dispose();

// Includes are read from the module's in-memory filesystem, which you fill:
anvil.writeFile('/schemas/types.anvl', typesText);
const withIncludes = anvil.Schema.loadFile('/schemas/asset.anvl');
```

- **Input is ANVL text, not JS objects.** ANVL is not JSON (`{"a":1}` does not parse; objects use
  `:=`), and a wire body is already ANVL. `validateValue` takes an object value as text for that
  reason. Building ANVL text from a JS value is the writer's job (see "Writing ANVL").
- **Failures return `null`** and set `lastError()`, like `parse()`: not a `@[schema]`/`@[types]`
  document, or a document that does not parse. `validate()`/`validateValue()` return `null` the
  same way when the data does not parse.
- **`fromIncludes*` tolerates a consumer-document error.** A name defined by two included
  `@[types]` documents collides in the consumer's own namespace; Anvil Native still builds the
  registry and reports it as a `NAME_COLLISION` diagnostic. The document's error is kept on
  `registry.loadError` (`{ message, line, column }` or `null`), not thrown away.
- **Enums** (`TypeKind`, `TypeDiagnostic`, `SchemaViolation`, `SchemaDiagnostic`) are frozen
  objects with the C names minus their prefix.
- **`validateField(docText, name, opts)`** parses the text, finds the top-level statement `name` and
  validates its object value, in one native call: `validateValue` for a request body you already
  hold as ANVL text, without a second parse from JS. Same `{ valid, violations }` result and the
  same `skipRequired`/`allowUnknown` options. An absent statement is one `REQUIRED` violation with
  an empty `field` (the same as `anvil.net`'s `ValidateField`); a statement that is not an object is
  the native `TYPE_MISMATCH`; text that does not parse is `null` with `lastError()` set.
  **`{ each: true }`** treats an array or tuple value as a batch (`set := [ {...}, ... ]`): every
  element is validated with the same options and its violations are reported at `[i]` and
  `[i].field`. A single object still validates under `each`. Unlike `anvil.net`, a JS caller
  cannot iterate the batch itself, because `parse()` hands back no per-element native handle.
- **Introspection.** `schema.fields` and `schema.findField(name)` return `SchemaField` snapshots
  (readable after `dispose()`), each with `name`, `kind`, `typeName` (as written, e.g.
  `'types.Id32'`), `required`, `nullable`, `integer`, and, when declared, `size`, `min`, `max`,
  `minItems`, `maxItems`, `values`, `format` and `tag`. Inherited constraints are already folded in;
  an undeclared one is `undefined`, never a default. `nested` (an object rule's fields) and
  `findNested(name)`, `items` (an array rule's element rule, whose `name` is `''`) and `extras`
  (extension keys such as FlyWire's `pooled`, each `{ name, value }` with `value` an `AnvlNode`)
  cover the rest.
- **Known limits.** `min`/`max` are JS numbers, so a bound past 2^53 loses precision, and one that
  overflows `int64`/`double` is `undefined`, because native offers no text accessor for it.

How WebAssembly differs from Node here:

- **A virtual filesystem for includes.** A schema that includes `@[types]` documents, and
  `loadFile`/`fromIncludesFile`, read the module's in-memory filesystem, which the caller fills with
  `writeFile(path, textOrBytes)` (parent directories are created) and empties with
  `removeFile(path)` (a missing file is a no-op). File loaders resolve includes beside the file; the
  text loaders (`load`, `fromIncludes`) resolve them against the filesystem root, `/`.
- **Handles are WASM heap memory.** `dispose()` frees one. A `FinalizationRegistry` frees an abandoned
  one when the garbage collector runs, but WASM memory is not reclaimed by anything else, so call
  `dispose()` in a loop that creates many. `TypeDef`s, violations, diagnostics and fields are plain
  snapshots, readable after `dispose()`.
- **Document text is passed with its byte length**, so a NUL character inside a string or a blob is
  data, and nothing after it is lost . Names, paths and identifiers are
  NUL-terminated by design and reject an embedded NUL with a `RangeError`. The type registry and schema keep a NUL in an enum label and in a string extension value.
- **Known limits:** `min`/`max` are JS numbers (a bound past 2^53 loses
  precision; one that overflows `int64`/`double` is `undefined`).

## Attributes and statements

`parse()` exposes attributes and statements with the same names and meaning as `anvil-py` and
`anvil-net` (`AnvlStatement.attributes`/`find_attribute`), in JS idiom:

```js
await anvil.ready();
const doc = anvil.parse('#!aml\n@[version="1.2"]\nticket @[type=bug, urgent] := { step @[status="done"] := 1; };\n');

doc.attributes;                         // [{ key: 'version', value: '"1.2"' }]   module attributes (root only)
doc.findAttribute('version').value;     // '"1.2"'; null when absent
doc.hasAttribute('version');            // true (unchanged)

const ticket = doc.statement('ticket'); // the first statement with that name, or null
ticket.name;                            // 'ticket'
ticket.attributes;                      // [{ key: 'type', value: 'bug' }, { key: 'urgent', value: null }]
ticket.findAttribute('type').value;     // 'bug' (raw); .decodedValue is the decoded, typed form
ticket.value.statements();              // the object's statements, in order: [AnvlStatement { name: 'step', ... }]
```

- **An attribute has a raw `value` and a `decodedValue`.** `value` is native's text for it, uninterpreted: a
  quoted string keeps its quotes (`status="done"` is `'"done"'`), a bare value is as written (`type=bug` is
  `'bug'`), and a flag (`@[urgent]`) is `null`. This is what `anvil-py`'s and `anvil-net`'s `AnvilAttribute.value`
  return. `decodedValue` reads the same attribute as a value (native `anvil_attribute_get_value_handle`): escapes
  resolved, delimiters stripped, and typed. `status="done"` is `'done'`, `note="a\"b"` is `a"b`, `n=42` is the
  number `42`, `b=true` is `true`, and `range=1..5` (not a scalar, so native exposes it as a bare word) is the
  string `'1..5'`. It is `null` for a flag and for an explicit `@[x=null]`; `value` tells them apart (`null` for the
  flag, `'null'` for the explicit one). A number past 2^53 loses precision, as in `parseRawValue()`.
- **A repeated name inside an object** (ANVL allows it; only the top level rejects it) counts once per
  occurrence, as in native, `anvil-py` and `anvil-net`: for
  `{ a := 1; a := 2; b := 3; }`, `count` is 3, `get('a')` and `statement('a')` are the **first** (`1`),
  and `entries()` and `statements()` yield all three in order. `has(name)` is true if any occurrence
  has that name. A document with no repeated names behaves exactly as before. A plain object built
  from `entries()` in order (as a `{ [name]: value }` conversion does) still ends up last-wins, by
  assignment; `parseRawValue()` returns a plain JS object, so a repeated name there is last-wins by
  construction. `statements()` is `[]` for a value that is not an object, and module attributes belong
  to the root: any other node's `attributes` is `[]`.
- **Attribute values are NUL-safe**, like every other text this binding returns.

## Writing ANVL

Anvil Native's streaming writer and document builder, in the same shape as `anvil.py` and
`anvil.net`. The native library owns every rule (dialect grammar, escaping, identifiers); AMP's
forbidden constructs are rejected at write time.

```js
const { AnvilWriter, AnvilBuilder, AnvilDialect } = require('anvil-wasm');
await require('anvil-wasm').ready();

const w = AnvilWriter.create(AnvilDialect.AMP);        // streaming: forward-only, chainable
const text = w.statement('status').bare('ok')
              .statement('code').value(200)
              .statement('tags').beginArray().bare('a').bare('b').endArray()
              .finish();                                // '#!amp\n\nstatus := ok;\n...'
w.dispose();

const b = AnvilBuilder.create(AnvilDialect.AML);       // builder: attach in any order, re-emit at will
const server = b.object();
server.add('host', b.bare('localhost'));
b.add('server', server).attribute('env', 'production');
const text2 = b.emit();
b.dispose();
```

- **Values.** `value(x)` takes `null`, a boolean, a number or a `bigint`: a safe integer is written
  exactly, a `bigint` past `int64` as its exact decimal text (ANVL numbers are unbounded), any other
  number as a double. A string is ambiguous, so `value('x')` is a `TypeError`: use `string()`
  (quoted) or `bare()` (unquoted). `numeric(text)` takes ANVL numeric text (the exponent sign is optional:
  `1.5e3` and `1.5e+3`; `5.`, `5.e3`, `1e`, `1e+` are rejected). `blob(tag, data)` takes bytes or a string; `tag` may be `null`.
- **Errors.** A native rejection is an `AnvilWriterError` with a `.code` (`WriterErrorCode`). The
  writer's first error is **sticky**: every later call throws the same code. The builder's are
  not: a failed call changes nothing, and what is only known once the tree is complete (an empty
  array, a one-element tuple) fails at `emit()` with the builder intact.
- **Arguments are checked before native code.** A wrong type is a `TypeError`; an embedded NUL in a
  NUL-terminated name is a `RangeError` (native code would silently truncate); a node from another
  builder, or any use after `dispose()`, is an `Error`.
- **Blobs.** Content is written byte-exact, but a backtick in it is rejected (`INVALID_BLOB`): a
  blob has no escape for its delimiter. **Reading non-UTF-8 blob bytes back is not possible yet:**
  the loader takes a JS string, which cannot carry them. UTF-8 blob content round-trips.

How WebAssembly differs from Node here:

- **Bytes are a `Uint8Array`**, not a `Buffer` (a browser build cannot assume `Buffer`):
  `finishBytes()`, `emitBytes()` and `writer.data` return one, and `blob()` accepts any typed array or
  a string. `finish()` and `emit()` decode it as UTF-8.
- **Integers are written as exact decimal text**, so a safe integer or a `bigint` of any size is
  exact and no 64-bit value crosses the JS/WASM boundary. Any other number is a double.
- **Handles are WASM heap memory.** `dispose()` frees one; a `FinalizationRegistry` frees an
  abandoned one when the garbage collector runs, so call `dispose()` in a loop that creates many.
- **A NUL inside a string or a blob round-trips exactly**: the writer emits it and `parse()` reads it
  back, with everything after it (`test/nul.test.js`).

## Native modules carried

The build compiles four native modules from Anvil Native into `dist/anvil.wasm`: **core** (the reader: `parse`,
`parseRawValue`, attributes), **writer** (the streaming writer and document builder), **types** (the type registry)
and **schema** (AnvilSchema validation). All four are reachable from JS. `dist/BUILD_INFO.json` records the native
commit and the module list the artifact was built from.

## Development

Everything below is for working on this repository. None of it applies to the prebuilt package.

### Building from source

Emscripten (`emcc`) is required and is not installed on the usual development machine, only on the Linode box that
hosts this project's other build and deploy work. Builds run there, over SSH:

```sh
git clone --recurse-submodules <this repository>
ssh linode "cd ~/projects/anvil.wasm && source ~/emsdk/emsdk_env.sh && ./build.sh"
npm test
```

`build.sh` compiles the vendored Anvil Native `.c` sources (`vendor/anvil`, a git submodule) plus `src/binding.c` and
`src/writer_binding.c` into `dist/anvil.js` + `dist/anvil.wasm`, then `scripts/build-browser.js` wraps `lib/index.js` and
`dist/anvil.js` into `dist/anvil.browser.js` (pure Node, no bundler; rerun it alone after editing `lib/index.js`).
`dist/` is gitignored, a build artifact; `test/browser-bundle.test.js` fails a stale `dist/anvil.browser.js`.

Anvil's allocator is `sigma.system.alloc`, which is not vendored. Its native x86-64 object can't be linked by
Emscripten, so `build-sigma-system-alloc.sh` compiles the same `sigma.core` source with `emcc` into `$WASM_PKG`
(default `~/wasm-packages`), laid out like the native `/usr/local` install. `build.sh` links that object. Order on
the box:

```sh
SIGMA_CORE=~/path/to/sigma.core ./build-sigma-system-alloc.sh   # once per sigma.core change
ANVIL_NATIVE_COMMIT=... ANVL_BUILD=... ./build.sh              # both only needed when the tree has no git metadata
```

`build.sh` writes `dist/BUILD_INFO.json` naming the native commit and modules the artifact was built from.
`test/vendor-pin.test.js` fails a `dist/` that doesn't match the `vendor/anvil` pin, so rebuild after every bump.

### The version string

The `+BUILD` in `getVersion()` is the build number `scripts/build-number.sh` resolves and `build.sh` passes as
`-DANVL_BUILD`: `ANVL_BUILD=<n> ./build.sh` if you set it (a release build passes the tag's number), else the
commit count of `vendor/anvil` when that is a full git checkout, else 0, which Anvil Native reports as no `+BUILD`.
A tree without git metadata, such as the one rsync'd to the build box, needs `ANVL_BUILD` passed in.

### The browser path

`test/web-path.test.js` is the one smoke test of the browser build: it evaluates `dist/anvil.js` in a sandbox with
no `process`, so Emscripten takes its `ENVIRONMENT=web` branch and fetches the `.wasm` over `fetch`. It is not a
real browser, but it is the same code path. It cannot see a failure that depends on the browser's own `ArrayBuffer`
rules (Node's wasm memory buffer is never resizable), so `test-browser/run-browser.sh` runs `lib/index.js` against
`dist/anvil.js` in a real headless browser: `test-browser/run-browser.sh <chromium|firefox> <glue|bundle>`. It needs a
built `dist/` and `node`. It is not part of `npm test`.

The browsers are Playwright's own Chromium and Firefox builds, never a system or snap browser. Fetch them once with
`test-browser/install-browsers.sh` (they go to `/tmp/anvl-browser-test/browsers`). Every run is contained by
`test-browser/contain.sh`: the page server and the browser run together in one `systemd-run --user` scope with
`MemoryMax=1536M`, no swap, `TasksMax=256` and `RuntimeMaxSec=180`; only one run at a time (`flock -n`, a second run
fails at once); all state (profile, lock, browsers) lives under `/tmp/anvl-browser-test/` and nothing in `$HOME`; on
exit, Ctrl-C or TERM the whole scope is killed and the profile removed, and a final self-check fails the run if any
process, profile directory or `$HOME` entry is left. It needs a systemd user session (`systemd-run --user`) and refuses
to run without one. `test-browser/prove-harness.sh` proves the containment with no browser (50 forked children plus
orphans killed after SIGTERM and after SIGKILL of the script, a memory hog killed by the cgroup, a runtime overrun,
and a second concurrent run refused); run it before the first browser run on a machine.

`build.sh` passes `-sGROWABLE_ARRAYBUFFERS=0`. Emscripten 6 defaults it to 1, which exposes the heap as a resizable
`ArrayBuffer` in browsers that have one, and Firefox's `TextDecoder.decode()` rejects a view on such a buffer, so every
string over 16 bytes read back from the heap (every `parse()` result) threw. Keep the setting at 0.

`test-browser/run-browser.sh <chromium|firefox> bundle` runs the same kind of check against `dist/anvil.browser.js` loaded by a plain
`<script>` tag (`window.anvl`, `ready({ wasmUrl })`, an AMP writer, and heap growth across small and multi-MB parses).
`test/browser-bundle.test.js` covers the bundle in a Node sandbox with no `require` or `process`.

### Design: mirrors `anvil-node` deliberately

Same JS-facing shape is the goal, so `AnvlNode` is pure JS, ported from `anvil-node`, dispatching against an
already-converted plain JS value regardless of which native layer produced it. `parse()` and `parseRawValue()`
convert their whole result eagerly and dispose the underlying `anvil_document` synchronously within one call, as
`anvil-node` does: a lazy, GC-deferred design would hand the source registry a document whose disposal time is
nondeterministic.

The one WASM-specific design point: rather than marshal a converted value across the JS/WASM boundary field by
field (many small crossings, the actual source of WASM's overhead relative to a native addon), the C side builds
the entire converted result as a single JSON string, hands back one pointer, and the JS side's native
`JSON.parse()` builds the structure. One crossing per call. See `notes/flywire-large-input-crash.md` for why
strings are marshaled onto the heap and not the stack.

### Target contract: `window.anvl`

FlyWire's browser client expects a global `window.anvl` loaded via a plain `<script>` tag, with the same method
shape as its server-side usage. This package is intended to fulfil that contract: `MODULARIZE`/`EXPORT_NAME`
Emscripten output, wrapped so it is loadable both as a plain script and via a bundler or `require`. The wrapper
that sets `window.anvl` itself is not written yet.

### Repo layout

```
build.sh                      # runs emcc: see "Building from source"
build-sigma-system-alloc.sh   # builds the sigma.system.alloc object with emcc
scripts/build-number.sh       # resolves the +BUILD number
src/                          # Emscripten glue (binding.c, writer_binding.c)
vendor/anvil/                 # git submodule, pinned to a commit on TheBadkraft/anvil main
lib/index.js                  # JS-facing wrapper: ready, parse, AnvlNode, Schema, TypeRegistry, writer, builder
dist/                         # build output (gitignored): anvil.js, anvil.wasm, anvil.browser.js, BUILD_INFO.json
test/                         # marshaling-layer tests only
notes/                        # design notes
CHANGELOG.md                  # per-change history
```
