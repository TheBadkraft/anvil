from enum import IntEnum


class SchemaViolationCode(IntEnum):
    """Why a value failed validation. Mirrors anvil_schema_err_code (anvil_schema.h) exactly, including the
    values: ANVIL_SCHEMA_ERR_VALIDATION_X is X here."""

    NONE = 0
    REQUIRED = 1
    TYPE_MISMATCH = 2
    SIZE = 3
    RANGE = 4
    VALUES = 5
    UNKNOWN_FIELD = 6
    ITEM_COUNT = 7
    TAG = 8
    FORMAT = 9
