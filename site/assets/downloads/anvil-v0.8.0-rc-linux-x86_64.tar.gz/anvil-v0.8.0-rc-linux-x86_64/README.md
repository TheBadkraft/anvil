# libanvil v0.8.0-rc — Linux x86_64

Prebuilt static (`libanvil.a`) and shared (`libanvil.so`) release builds of Anvil Native —
core parser (AML/AMP), the opt-in type registry, and AnvilSchema, bundled as one library for
this milestone. Built with `-O2`, stripped of debug symbols.

## Using it

```sh
gcc your_program.c -I include -L lib -lanvil -o your_program        # static or shared
# or, to force static linking:
gcc your_program.c -I include lib/libanvil.a -o your_program
```

## What's included

- `lib/libanvil.a`, `lib/libanvil.so`
- `include/anvil_flat.h` — the primary public API (plain function calls)
- `include/anvil_vtable.h` — the same API as a vtable-style struct-of-function-pointers
- `include/anvil_types.h` — public ABI types (opaque handles, stable error categories)
- `include/anvil_type_registry.h` — the opt-in type registry (`@[types]`)
- `include/anvil_schema.h` — AnvilSchema (`@[schema]`)

Full documentation: https://github.com/TheBadkraft/anvil (see `docs/`).

Only Linux x86_64 is built today. macOS/Windows: build from source (`make lib` at the repo
root) until real cross-platform CI exists.
