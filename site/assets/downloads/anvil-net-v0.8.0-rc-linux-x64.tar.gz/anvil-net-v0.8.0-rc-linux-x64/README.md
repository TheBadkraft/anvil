# anvil-net v0.8.0-rc — Linux x64

A .NET binding over Anvil Native — the reference C implementation of the AML/AMP parser — built
directly on its vtable ABI (`anvil_vtable.h`): one struct marshal and a set of cached delegates
per group, resolved once, no per-call symbol lookup. `AnvilDocument`/`AnvlValue`/`AnvlStatement`/
`AnvilAttribute`/`AnvilError`, all lazy — every accessor is a direct call, nothing is eagerly
materialized into a tree up front.

## Requirements

- .NET 9 runtime or later (`net9.0` target; a newer major runtime works too via roll-forward).
- Linux x64 (glibc) only. Other platforms: build from source (`vendor/anvil`'s `v0.8.0-rc` tag or
  later, `make so-release`, then `dotnet build`) — not yet published to NuGet, so building means
  pointing at a real checkout, not `dotnet add package`.
- No other runtime dependencies once built.

## Usage

Keep `Anvil.Net.dll` and `libanvil.so` in the same directory — the binding resolves the native
library next to its own assembly, not next to your application's entry point.

```csharp
using Anvil.Net;

using var doc = AnvilDocument.Load("config.anvl");
if (doc is null || doc.HasErrors)
{
    Console.WriteLine($"Failed: {doc?.Error?.Message} at {doc?.Error?.Line}:{doc?.Error?.Column}");
    return;
}

if (doc.FindValue("server") is { Type: AnvilValueType.Object } server)
{
    string? host = server["host"]?.AsString();
    int? port = server["port"]?.AsInt();
}
```

Reference `Anvil.Net.dll` directly (e.g. `<Reference Include="Anvil.Net"><HintPath>...</HintPath></Reference>`)
and make sure `libanvil.so` ends up next to it in your own build output — MSBuild copies a
referenced DLL automatically but won't copy a plain sibling file for you.

Full API reference: see the anvldata.com Bindings guide.
