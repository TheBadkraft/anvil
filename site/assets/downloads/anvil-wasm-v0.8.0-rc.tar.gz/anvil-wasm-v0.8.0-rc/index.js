'use strict';

// JS-facing wrapper over the compiled Emscripten module. Unlike anvil-node, module loading is
// inherently async (WASM instantiation) -- ready() is the one place that async cost is paid;
// every data operation after that resolves is a plain synchronous call, matching anvil-node's
// own shape as closely as the runtime difference allows.

const factory = require('../dist/anvil.js');

let modulePromise = null;
let Module = null;
let nativeGetVersion = null;
let nativeParseRawValue = null;
let nativeParse = null;
let nativeLastErrorJson = null;

function ready() {
   if (!modulePromise) {
      modulePromise = factory().then((mod) => {
         Module = mod;
         nativeGetVersion = Module.cwrap('anvil_get_version', 'string', []);
         // Return type 'number' (a raw pointer), not cwrap's own 'string' type -- these
         // functions return a malloc'd buffer whose ownership transfers to the caller, and
         // cwrap's 'string' return only reads a pointer, it never frees one (it has no way to
         // know whether one was allocated at all). Read + free is done explicitly below.
         nativeParseRawValue = Module.cwrap('anvil_wasm_parse_raw_value', 'number', ['string']);
         nativeParse = Module.cwrap('anvil_wasm_parse', 'number', ['string']);
         nativeLastErrorJson = Module.cwrap('anvil_wasm_last_error_json', 'number', []);
      });
   }
   return modulePromise;
}

function assertReady(fnName) {
   if (!Module) {
      throw new Error(
         `anvil-wasm: call and await ready() before ${fnName}() -- the WASM module hasn't finished loading yet.`
      );
   }
}

// Reads a JSON string out of WASM memory at `ptr` and frees the underlying buffer. `ptr === 0`
// (a real null pointer) means "nothing to read" -- the caller decides what that means (failure
// for parseRawValue()/parse(), "no error" for lastError()).
function readAndFreeJson(ptr) {
   if (ptr === 0) {
      return null;
   }
   const json = Module.UTF8ToString(ptr);
   Module._free(ptr);
   return JSON.parse(json);
}

function getVersion() {
   assertReady('getVersion');
   return nativeGetVersion();
}

function parseRawValue(text) {
   assertReady('parseRawValue');
   return readAndFreeJson(nativeParseRawValue(text));
}

function lastError() {
   assertReady('lastError');
   return readAndFreeJson(nativeLastErrorJson());
}

// AnvlNode -- ported near-verbatim from anvil-node/lib/index.js. Pure JS, no native calls at
// all: it dispatches has()/get()/entries()/asString()/etc. against an already-converted plain
// JS value, which is exactly what anvil_wasm_parse's single JSON-string crossing produces --
// the same reason this class needed zero changes to move from an N-API-backed value to a
// WASM-backed one. See anvil-node/README.md's "Why parse() doesn't hold a native handle" for
// why both bindings build this the same (eager, synchronous) way.
class AnvlNode {
   constructor(value, moduleAttributeKeys) {
      this._value = value;
      this._moduleAttributeKeys = moduleAttributeKeys || null;
   }

   _isPlainObject() {
      return this._value !== null && typeof this._value === 'object' && !Array.isArray(this._value);
   }

   has(key) {
      return this._isPlainObject() && Object.prototype.hasOwnProperty.call(this._value, key);
   }

   get(key) {
      if (!this.has(key)) {
         return null;
      }
      return new AnvlNode(this._value[key]);
   }

   hasAttribute(key) {
      return this._moduleAttributeKeys ? this._moduleAttributeKeys.includes(key) : false;
   }

   entries() {
      if (!this._isPlainObject()) {
         return [];
      }
      return Object.entries(this._value).map(([name, v]) => [name, new AnvlNode(v)]);
   }

   get count() {
      if (Array.isArray(this._value)) {
         return this._value.length;
      }
      return this._isPlainObject() ? Object.keys(this._value).length : 0;
   }

   at(index) {
      if (!Array.isArray(this._value) || index < 0 || index >= this._value.length) {
         return null;
      }
      return new AnvlNode(this._value[index]);
   }

   asString() {
      return typeof this._value === 'string' ? this._value : null;
   }

   asBool() {
      return typeof this._value === 'boolean' ? this._value : null;
   }

   asInt() {
      return typeof this._value === 'number' ? Math.trunc(this._value) : null;
   }
}

function parse(sourceText) {
   assertReady('parse');
   const result = readAndFreeJson(nativeParse(sourceText));
   if (result === null) {
      return null;
   }
   return new AnvlNode(result.root, result.attributes);
}

module.exports = { ready, getVersion, parseRawValue, lastError, parse, AnvlNode };
