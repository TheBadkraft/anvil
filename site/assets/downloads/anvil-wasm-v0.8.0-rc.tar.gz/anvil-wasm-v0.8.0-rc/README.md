# anvil-wasm bundle v0.8.0-rc

A WebAssembly build of Anvil Native — the reference C implementation of the AML/AMP parser —
for use in the browser or any JS host. Mirrors the anvil-node binding's API deliberately, with
one real difference: module loading is async (WASM instantiation), so you must `await ready()`
once before calling anything else.

## Files

- `anvil.wasm` — the compiled module
- `anvil.js` — Emscripten glue (loads/instantiates `anvil.wasm`)
- `index.js` — the JS-facing wrapper (`getVersion`/`parse`/`parseRawValue`/`lastError`, an
  `AnvlNode` read-only facade over a parsed value)

## Usage

```js
const anvil = require('./index.js'); // or import, if you adapt to ESM

await anvil.ready(); // pays the one-time async WASM instantiation cost

const doc = anvil.parse('#!aml\nserver := { host := "localhost"; port := 8080; };');
if (!doc) {
  const err = anvil.lastError();
  console.error(`${err.message} at ${err.line}:${err.column}`);
} else {
  console.log(doc.get('server').get('host').asString()); // "localhost"
}
```

Every call after `ready()` resolves is a plain synchronous call — the async cost is paid once,
not per parse.
