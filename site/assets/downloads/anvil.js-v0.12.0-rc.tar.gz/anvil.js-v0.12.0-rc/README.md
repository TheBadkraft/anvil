# anvil.js

The pure-JavaScript ANVL implementation (published as `anvil.js`, with the same API as anvil-node). ANVL Native is the spec: this reader is held to
it by the native-owned conformance corpus (`vendor/anvil/conformance/`), differential fuzzing and drift tests.

Design (owner-approved in R0): UTF-8 `Uint8Array` input, one `Int32Array` tree with 8 ints per node holding source
spans, values decoded lazily, a single forward pass with no lexer.

- `src/reader.js` header and body scanner; `src/load.js` include graph and phases; `src/resolve.js` the resolver;
  `src/dump.js` the FORMAT.md writer; `js/dump.js` the `anvil-dump` command line.
- `npm run conformance` runs the corpus; `npm test` runs the tests (the corpus included).

## Use

```js
const anvl = require('anvil.js');          // Node (include resolves against the working directory)
const doc = anvl.parse('#!aml\nid := 9007199254740993;\nname := "x";\n');
doc.get('id').asBigInt();                  // 9007199254740993n
doc.get('name').asString();                // 'x'
anvl.parse('x := 5.;');                    // null; anvl.lastError() is { message, line, column }
```

In a browser, with no bundler: vendor `dist/anvil.mjs` (`import { parse } from './anvil.mjs'`) or load
`dist/anvil.global.js` with a script tag (it defines `window.anvl`). `npm run build` regenerates both.

The reader API is anvil-node's (`parse`, `parseRawValue`, `lastError`, `getVersion`, `AnvlNode`, `AnvlStatement`) plus
`isNull()`, `blobTag`, `overflowed`, `implementation` (`'anvil.js'`) and `BUILD_INFO.json`. Types, schema, writer and builder
are later phases.

## Checks

`npm run conformance` (the native corpus), `npm test`, `npm run compat` (anvil-node's own reader tests, unedited, through a
require alias), `node scripts/api-diff.js --addon <anvil-node lib/index.js>`, `test-browser/run-browser.sh`.
