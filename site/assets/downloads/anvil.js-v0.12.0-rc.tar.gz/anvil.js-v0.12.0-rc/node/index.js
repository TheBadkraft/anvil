'use strict';
// Node entry point: the browser-safe API, plus the filesystem for `include` (resolved against the working directory,
// as anvil-node does for parse()).
const fs = require('node:fs');
const api = require('../src/api');

api.setIo({
   readFile(binaryPath) {
      try {
         return fs.readFileSync(Buffer.from(binaryPath, 'latin1'));
      } catch (e) {
         return e.code === 'EISDIR' ? new Uint8Array(0) : null; // native reads a directory as an empty file
      }
   },
});
module.exports = require('../src/index.js');
