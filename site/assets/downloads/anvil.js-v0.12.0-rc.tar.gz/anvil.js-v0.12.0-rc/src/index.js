'use strict';
// anvil.js: the anvil-node reader API over the R1 reader. (Types, schema, writer and builder are later phases.)
const api = require('./api');
const info = require('./build-info');

module.exports = {
   parse: api.parse,
   parseRawValue: api.parseRawValue,
   lastError: api.lastError,
   getVersion: () => (info.build ? `${info.nativeVersion}+${info.build}` : info.nativeVersion),
   AnvlNode: api.AnvlNode,
   AnvlStatement: api.AnvlStatement,
   implementation: 'anvil.js',
   // read at load time by anvil-node's own tests; the writer that uses it is a later phase
   AnvilDialect: Object.freeze({ AML: 0, AMP: 1 }),
};
