"""Binds Anvil Native's TypeRegistry vtable group (anvil_type_registry_vtable.h's anvil_type_registry_i). Field
order matches the C struct exactly; tests/test_vtable_drift.py checks it against the real header, since
a wrong order silently binds the wrong function. Generated from the header, then reviewed."""
import ctypes as C

from ._buffer import read_string
from ._lib import LIB
from .value import Numeric, _NumericRaw

class _TypeRegistryRaw(C.Structure):
    _fields_ = [
        ("load", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("load_from_includes", C.CFUNCTYPE(C.c_void_p, C.c_void_p)),
        ("dispose", C.CFUNCTYPE(None, C.c_void_p)),
        ("find", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("resolve", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_char_p)),
        ("def_get_kind", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("def_get_size", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("def_get_min", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("def_get_min_numeric", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(_NumericRaw))),
        ("def_get_max", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(C.c_longlong))),
        ("def_get_max_numeric", C.CFUNCTYPE(C.c_bool, C.c_void_p, C.POINTER(_NumericRaw))),
        ("def_get_format", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("def_get_value_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("def_get_value", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_size_t, C.c_char_p, C.c_size_t)),
        ("get_diagnostic_count", C.CFUNCTYPE(C.c_size_t, C.c_void_p)),
        ("get_diagnostic", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.c_size_t)),
        ("diagnostic_get_category", C.CFUNCTYPE(C.c_int, C.c_void_p)),
        ("diagnostic_get_name", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("diagnostic_get_source", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("diagnostic_get_message", C.CFUNCTYPE(C.c_size_t, C.c_void_p, C.c_char_p, C.c_size_t)),
        ("load_ex", C.CFUNCTYPE(C.c_void_p, C.c_void_p, C.POINTER(C.c_int))),
        ("err_code_name", C.CFUNCTYPE(C.c_char_p, C.c_int)),
        ("err_code_message", C.CFUNCTYPE(C.c_char_p, C.c_int)),
    ]

_vt = _TypeRegistryRaw.in_dll(LIB, "TypeRegistry")

def load(doc: int) -> int | None:
    return _vt.load(doc)

def load_from_includes(doc: int) -> int | None:
    return _vt.load_from_includes(doc)

def dispose(reg: int) -> None:
    _vt.dispose(reg)

def find(reg: int, name: bytes) -> int | None:
    return _vt.find(reg, name)

def resolve(reg: int, name: bytes) -> int | None:
    return _vt.resolve(reg, name)

def def_get_kind(type_def: int) -> int:
    return _vt.def_get_kind(type_def)

def def_get_size(type_def) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.def_get_size(type_def, C.byref(out)) else None

def def_get_min(type_def) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.def_get_min(type_def, C.byref(out)) else None

def def_get_min_numeric(type_def) -> Numeric | None:
    out = _NumericRaw()
    if not _vt.def_get_min_numeric(type_def, C.byref(out)):
        return None
    return Numeric(bool(out.is_integral), bool(out.overflowed), out.as_int64, out.as_double)

def def_get_max(type_def) -> int | None:
    out = C.c_longlong()
    return out.value if _vt.def_get_max(type_def, C.byref(out)) else None

def def_get_max_numeric(type_def) -> Numeric | None:
    out = _NumericRaw()
    if not _vt.def_get_max_numeric(type_def, C.byref(out)):
        return None
    return Numeric(bool(out.is_integral), bool(out.overflowed), out.as_int64, out.as_double)

def def_get_format(type_def) -> str:
    return read_string(lambda buf, buflen: _vt.def_get_format(type_def, buf, buflen))

def def_get_value_count(type_def: int) -> int:
    return _vt.def_get_value_count(type_def)

def def_get_value(type_def, index) -> str:
    return read_string(lambda buf, buflen: _vt.def_get_value(type_def, index, buf, buflen))

def get_diagnostic_count(reg: int) -> int:
    return _vt.get_diagnostic_count(reg)

def get_diagnostic(reg: int, index: int) -> int | None:
    return _vt.get_diagnostic(reg, index)

def diagnostic_get_category(diag: int) -> int:
    return _vt.diagnostic_get_category(diag)

def diagnostic_get_name(diag) -> str:
    return read_string(lambda buf, buflen: _vt.diagnostic_get_name(diag, buf, buflen))

def diagnostic_get_source(diag) -> str:
    return read_string(lambda buf, buflen: _vt.diagnostic_get_source(diag, buf, buflen))

def diagnostic_get_message(diag) -> str:
    return read_string(lambda buf, buflen: _vt.diagnostic_get_message(diag, buf, buflen))


def load_ex(doc: int) -> "tuple[int | None, int]":
    err = C.c_int()
    return _vt.load_ex(doc, C.byref(err)), err.value

def err_code_name(code: int) -> str:
    return _vt.err_code_name(code).decode("utf-8")

def err_code_message(code: int) -> str:
    return _vt.err_code_message(code).decode("utf-8")
