"""Binds Anvil Native's Builder vtable group (anvil_builder_vtable.h's anvil_builder_i) -- a 1:1
mirror, like _native/writer.py: one native call per function, no validation or conveniences.
Handles (builder, node, member) are plain ints; a failed constructor/lookup returns None.
tests/test_vtable_drift.py checks the field order against the real header.
"""
import ctypes as C

from ._lib import LIB

_B = C.c_void_p


class _BuilderRaw(C.Structure):
    _fields_ = [
        ("create", C.CFUNCTYPE(_B, C.c_int)),
        ("dispose", C.CFUNCTYPE(None, _B)),
        ("get_error", C.CFUNCTYPE(C.c_int, _B)),
        ("attribute", C.CFUNCTYPE(C.c_bool, _B, C.c_char_p, C.c_char_p)),
        ("attribute_string", C.CFUNCTYPE(C.c_bool, _B, C.c_char_p, C.c_char_p, C.c_size_t)),
        ("include", C.CFUNCTYPE(C.c_bool, _B, C.c_char_p)),
        ("null_value", C.CFUNCTYPE(C.c_void_p, _B)),
        ("bool_value", C.CFUNCTYPE(C.c_void_p, _B, C.c_bool)),
        ("numeric", C.CFUNCTYPE(C.c_void_p, _B, C.c_char_p)),
        ("int_value", C.CFUNCTYPE(C.c_void_p, _B, C.c_int64)),
        ("double_value", C.CFUNCTYPE(C.c_void_p, _B, C.c_double)),
        ("string", C.CFUNCTYPE(C.c_void_p, _B, C.c_char_p, C.c_size_t)),
        ("bare", C.CFUNCTYPE(C.c_void_p, _B, C.c_char_p)),
        ("blob", C.CFUNCTYPE(C.c_void_p, _B, C.c_char_p, C.c_char_p, C.c_size_t)),
        ("varref", C.CFUNCTYPE(C.c_void_p, _B, C.c_char_p)),
        ("array", C.CFUNCTYPE(C.c_void_p, _B)),
        ("tuple", C.CFUNCTYPE(C.c_void_p, _B)),
        ("object", C.CFUNCTYPE(C.c_void_p, _B)),
        ("append", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p, C.c_void_p)),
        ("add", C.CFUNCTYPE(C.c_void_p, _B, C.c_void_p, C.c_char_p, C.c_void_p)),
        ("set_base", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p, C.c_char_p)),
        ("member_attribute", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p, C.c_char_p, C.c_char_p)),
        ("member_attribute_string", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p, C.c_char_p, C.c_char_p, C.c_size_t)),
        ("find", C.CFUNCTYPE(C.c_void_p, _B, C.c_void_p, C.c_char_p)),
        ("write", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p)),
        ("emit", C.CFUNCTYPE(C.c_void_p, _B, C.POINTER(C.c_size_t))),
        ("set_block", C.CFUNCTYPE(C.c_bool, _B, C.c_void_p, C.c_bool)),
    ]


_vt = _BuilderRaw.in_dll(LIB, "Builder")


def create(dialect: int) -> int | None:
    return _vt.create(dialect)


def dispose(b: int) -> None:
    _vt.dispose(b)


def get_error(b: int) -> int:
    return _vt.get_error(b)


def attribute(b: int, key: bytes, value: bytes | None) -> bool:
    return _vt.attribute(b, key, value)


def attribute_string(b: int, key: bytes, text: bytes, length: int) -> bool:
    return _vt.attribute_string(b, key, text, length)


def include(b: int, path: bytes) -> bool:
    return _vt.include(b, path)


def null_value(b: int) -> int | None:
    return _vt.null_value(b)


def bool_value(b: int, value: bool) -> int | None:
    return _vt.bool_value(b, value)


def numeric(b: int, text: bytes) -> int | None:
    return _vt.numeric(b, text)


def int_value(b: int, value: int) -> int | None:
    return _vt.int_value(b, value)


def double_value(b: int, value: float) -> int | None:
    return _vt.double_value(b, value)


def string(b: int, text: bytes, length: int) -> int | None:
    return _vt.string(b, text, length)


def bare(b: int, text: bytes) -> int | None:
    return _vt.bare(b, text)


def blob(b: int, tag: bytes | None, data: bytes, length: int) -> int | None:
    return _vt.blob(b, tag, data, length)


def varref(b: int, name: bytes) -> int | None:
    return _vt.varref(b, name)


def array(b: int) -> int | None:
    return _vt.array(b)


def tuple_(b: int) -> int | None:
    return _vt.tuple(b)


def object_(b: int) -> int | None:
    return _vt.object(b)


def append(b: int, collection: int, element: int) -> bool:
    return _vt.append(b, collection, element)


def add(b: int, obj: int | None, name: bytes, value: int) -> int | None:
    return _vt.add(b, obj, name, value)


def set_base(b: int, member: int, base: bytes) -> bool:
    return _vt.set_base(b, member, base)


def set_block(b: int, member: int, block: bool) -> bool:
    return _vt.set_block(b, member, block)


def member_attribute(b: int, member: int, key: bytes, value: bytes | None) -> bool:
    return _vt.member_attribute(b, member, key, value)


def member_attribute_string(b: int, member: int, key: bytes, text: bytes, length: int) -> bool:
    return _vt.member_attribute_string(b, member, key, text, length)


def find(b: int, obj: int | None, name: bytes) -> int | None:
    return _vt.find(b, obj, name)


def write(b: int, writer: int) -> bool:
    return _vt.write(b, writer)


def emit(b: int) -> bytes | None:
    """The emitted text, copied out of the builder's buffer (borrowed until the next emit):
    None on error."""
    length = C.c_size_t()
    ptr = _vt.emit(b, C.byref(length))
    return None if ptr is None else C.string_at(ptr, length.value)
