"""Binds Anvil Native's Writer vtable group (anvil_writer_vtable.h's anvil_writer_i) -- a 1:1
mirror: each function is exactly one native call, with no validation or conveniences (those belong
to the public AnvilWriter). Field order matches the C struct exactly -- ctypes computes each
offset from the fields before it, so a wrong order silently binds the wrong function;
tests/test_vtable_drift.py checks the order against the real header.
"""
import ctypes as C

from ._lib import LIB

_W = C.c_void_p


class _WriterRaw(C.Structure):
    _fields_ = [
        ("create", C.CFUNCTYPE(_W, C.c_int)),
        ("dispose", C.CFUNCTYPE(None, _W)),
        ("get_error", C.CFUNCTYPE(C.c_int, _W)),
        ("error_message", C.CFUNCTYPE(C.c_char_p, C.c_int)),
        ("attribute", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_char_p)),
        ("attribute_string", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_char_p, C.c_size_t)),
        ("include", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p)),
        ("statement", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_char_p)),
        ("null_value", C.CFUNCTYPE(C.c_bool, _W)),
        ("bool_value", C.CFUNCTYPE(C.c_bool, _W, C.c_bool)),
        ("numeric", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p)),
        ("int_value", C.CFUNCTYPE(C.c_bool, _W, C.c_int64)),
        ("double_value", C.CFUNCTYPE(C.c_bool, _W, C.c_double)),
        ("string", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_size_t)),
        ("bare", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p)),
        ("blob", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_char_p, C.c_size_t)),
        ("varref", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p)),
        ("begin_array", C.CFUNCTYPE(C.c_bool, _W)),
        ("end_array", C.CFUNCTYPE(C.c_bool, _W)),
        ("begin_tuple", C.CFUNCTYPE(C.c_bool, _W)),
        ("end_tuple", C.CFUNCTYPE(C.c_bool, _W)),
        ("begin_object", C.CFUNCTYPE(C.c_bool, _W)),
        ("end_object", C.CFUNCTYPE(C.c_bool, _W)),
        ("finish", C.CFUNCTYPE(C.c_bool, _W)),
        ("data", C.CFUNCTYPE(C.c_void_p, _W, C.POINTER(C.c_size_t))),
        ("statement_block", C.CFUNCTYPE(C.c_bool, _W, C.c_char_p, C.c_char_p)),
    ]


_vt = _WriterRaw.in_dll(LIB, "Writer")


def create(dialect: int) -> int | None:
    return _vt.create(dialect)


def dispose(w: int) -> None:
    _vt.dispose(w)


def get_error(w: int) -> int:
    return _vt.get_error(w)


def error_message(code: int) -> str:
    return _vt.error_message(code).decode("utf-8")


def attribute(w: int, key: bytes, value: bytes | None) -> bool:
    return _vt.attribute(w, key, value)


def attribute_string(w: int, key: bytes, text: bytes, length: int) -> bool:
    return _vt.attribute_string(w, key, text, length)


def include(w: int, path: bytes) -> bool:
    return _vt.include(w, path)


def statement(w: int, name: bytes, base: bytes | None) -> bool:
    return _vt.statement(w, name, base)


def statement_block(w: int, name: bytes, base: bytes | None) -> bool:
    return _vt.statement_block(w, name, base)


def null_value(w: int) -> bool:
    return _vt.null_value(w)


def bool_value(w: int, value: bool) -> bool:
    return _vt.bool_value(w, value)


def numeric(w: int, text: bytes) -> bool:
    return _vt.numeric(w, text)


def int_value(w: int, value: int) -> bool:
    return _vt.int_value(w, value)


def double_value(w: int, value: float) -> bool:
    return _vt.double_value(w, value)


def string(w: int, text: bytes, length: int) -> bool:
    return _vt.string(w, text, length)


def bare(w: int, text: bytes) -> bool:
    return _vt.bare(w, text)


def blob(w: int, tag: bytes | None, data: bytes, length: int) -> bool:
    return _vt.blob(w, tag, data, length)


def varref(w: int, name: bytes) -> bool:
    return _vt.varref(w, name)


def begin_array(w: int) -> bool:
    return _vt.begin_array(w)


def end_array(w: int) -> bool:
    return _vt.end_array(w)


def begin_tuple(w: int) -> bool:
    return _vt.begin_tuple(w)


def end_tuple(w: int) -> bool:
    return _vt.end_tuple(w)


def begin_object(w: int) -> bool:
    return _vt.begin_object(w)


def end_object(w: int) -> bool:
    return _vt.end_object(w)


def finish(w: int) -> bool:
    return _vt.finish(w)


def data(w: int) -> bytes | None:
    """The emitted text, copied out of the writer's buffer (which is only borrowed): None until a
    successful finish() and after any error."""
    length = C.c_size_t()
    ptr = _vt.data(w, C.byref(length))
    return None if ptr is None else C.string_at(ptr, length.value)
