from enum import IntEnum

from anvil._native import type_registry as native_registry


class TypeErrorCode(IntEnum):
    """Why a type registry could not be loaded. Mirrors anvil_type_err_code (anvil_type_registry.h) exactly,
    including the values."""

    NONE = 0
    ATTRIBUTE_MISSING = 1  # the document does not carry the @[types] module attribute

    @property
    def native_name(self) -> str:
        """Native's identifier for this code, e.g. "ANVIL_TYPE_ERR_ATTRIBUTE_MISSING"."""
        return native_registry.err_code_name(self.value)

    @property
    def message(self) -> str:
        """Anvil Native's own one-line description of this code."""
        return native_registry.err_code_message(self.value)
