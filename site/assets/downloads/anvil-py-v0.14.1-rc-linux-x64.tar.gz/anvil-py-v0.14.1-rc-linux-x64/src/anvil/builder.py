"""AnvilBuilder: build a document as a tree, in any order, then emit it -- a view over Anvil
Native's document builder (anvil_builder.h). Where AnvilWriter is forward-only, a builder lets you
create values first and place them afterwards, add to the document or an object incrementally, and
re-emit after changing it. Emission goes through the native streaming writer, so output and grammar
rules are exactly the writer's.

Values (AnvilNode) are created detached and attached exactly once: as an array/tuple element
(AnvilNode.append) or as a statement's value (AnvilBuilder.add / AnvilNode.add). A call that is wrong
in itself (bad name, AMP-forbidden construct, a node attached twice or into a cycle, a repeated
top-level name) raises AnvilWriterError at that call and changes nothing -- errors are NOT sticky
here. What can only be known once the tree is complete (empty arrays/objects, 1-tuples, nesting past
MAX_DEPTH) raises from emit(), and the builder can still be completed and emitted again.

Everything made through a builder is owned by it and dies with dispose(); using a node or member
afterwards raises RuntimeError, and passing one to a different builder raises ValueError (it never
reaches native code).

    with AnvilBuilder.create(AnvilDialect.AML) as b:
        server = b.object()
        server.add("host", b.bare("localhost"))
        b.add("server", server).attribute("env", "production")
        text = b.emit()
"""
from anvil import _args
from anvil._native import builder as native
from anvil.dialect import AnvilDialect
from anvil.writer import AnvilWriter
from anvil.writer_error import AnvilWriterError
from anvil.writer_error_code import WriterErrorCode


class AnvilBuilder:
    MAX_DEPTH = 256
    """Deepest array/tuple/object nesting emit() will write."""

    def __init__(self, handle: int):
        self._handle = handle
        self._disposed = False

    @classmethod
    def create(cls, dialect: AnvilDialect) -> "AnvilBuilder":
        if not isinstance(dialect, AnvilDialect):
            raise TypeError(f"dialect must be AnvilDialect, not {type(dialect).__name__}")
        handle = native.create(dialect.value)
        if handle is None:
            raise MemoryError("Anvil Native could not allocate a builder")
        return cls(handle)

    def _live(self) -> int:
        if self._disposed:
            raise RuntimeError("AnvilBuilder used after dispose()")
        return self._handle

    def _failure(self) -> AnvilWriterError:
        return AnvilWriterError(WriterErrorCode(native.get_error(self._handle)))

    def _check(self, accepted: bool) -> None:
        if not accepted:
            raise self._failure()

    def _node(self, handle: "int | None") -> "AnvilNode":
        if handle is None:
            raise self._failure()
        return AnvilNode(self, handle)

    @property
    def error(self) -> WriterErrorCode:
        """Outcome of the most recent call: WriterErrorCode.OK if it succeeded."""
        return WriterErrorCode(native.get_error(self._live()))

    def _owned(self, node, what: str) -> int:
        """Ownership guard: must be an AnvilNode of this builder, and this builder open."""
        if not isinstance(node, AnvilNode):
            raise TypeError(f"{what} must be AnvilNode, not {type(node).__name__}")
        if node._builder is not self:
            raise ValueError(f"{what} belongs to a different AnvilBuilder")
        self._live()
        return node._handle

    # ---- header (AML only) ----

    def attribute(self, key: str, value: "str | None" = None) -> "AnvilBuilder":
        """Module attribute; `value` is raw text or None for a flag."""
        h = self._live()
        self._check(native.attribute(h, _args.required(key, "key"), _args.optional(value, "value")))
        return self

    def attribute_string(self, key: str, text: str) -> "AnvilBuilder":
        h = self._live()
        encoded = _args.text(text, "text")
        self._check(native.attribute_string(h, _args.required(key, "key"), encoded, len(encoded)))
        return self

    def include(self, path: str) -> "AnvilBuilder":
        h = self._live()
        self._check(native.include(h, _args.required(path, "path")))
        return self

    # ---- values (created detached) ----

    def null(self) -> "AnvilNode":
        return self._node(native.null_value(self._live()))

    def value(self, value) -> "AnvilNode":
        """None, bool, int or float. An int past int64 is built exactly (ANVL numbers are
        unbounded); a non-finite float is rejected. Use string()/bare() for text."""
        h = self._live()
        kind, payload = _args.classify(value)
        if kind == "null":
            return self._node(native.null_value(h))
        if kind == "bool":
            return self._node(native.bool_value(h, payload))
        if kind == "int":
            return self._node(native.int_value(h, payload))
        if kind == "numeric":
            return self._node(native.numeric(h, payload))
        return self._node(native.double_value(h, payload))

    def numeric(self, text: str) -> "AnvilNode":
        """ANVL numeric text: -?digits(.digits)?([eE][+-]digits)?"""
        h = self._live()
        return self._node(native.numeric(h, _args.required(text, "text")))

    def string(self, text: str) -> "AnvilNode":
        h = self._live()
        encoded = _args.text(text, "text")
        return self._node(native.string(h, encoded, len(encoded)))

    def bare(self, text: str) -> "AnvilNode":
        h = self._live()
        return self._node(native.bare(h, _args.required(text, "text")))

    def blob(self, tag: "str | None", data) -> "AnvilNode":
        """`tag` is None (or empty) for an untagged blob; `data` is bytes-like or a str."""
        h = self._live()
        content = _args.data(data, "data")
        return self._node(native.blob(h, _args.optional(tag, "tag"), content, len(content)))

    def varref(self, name: str) -> "AnvilNode":
        """A dollar-name reference (AML only)."""
        h = self._live()
        return self._node(native.varref(h, _args.required(name, "name")))

    def array(self) -> "AnvilNode":
        return self._node(native.array(self._live()))

    def tuple(self) -> "AnvilNode":
        return self._node(native.tuple_(self._live()))

    def object(self) -> "AnvilNode":
        """AML only."""
        return self._node(native.object_(self._live()))

    # ---- structure ----

    def add(self, name: str, value: "AnvilNode") -> "AnvilMember":
        """Adds the top-level statement `name := value;`. `value` must be detached; a top-level
        name may only be added once. Statements are emitted in the order added."""
        return self._add_to(None, name, value)

    def find(self, name: str) -> "AnvilMember | None":
        """Finds a top-level statement by name, or None."""
        return self._find_in(None, name)

    def _add_to(self, obj: "AnvilNode | None", name: str, value: "AnvilNode") -> "AnvilMember":
        self._live()
        encoded = _args.required(name, "name")
        object_handle = None if obj is None else self._owned(obj, "object")
        value_handle = self._owned(value, "value")
        handle = native.add(self._handle, object_handle, encoded, value_handle)
        if handle is None:
            raise self._failure()
        return AnvilMember(self, handle)

    def _find_in(self, obj: "AnvilNode | None", name: str) -> "AnvilMember | None":
        h = self._live()
        encoded = _args.required(name, "name")
        object_handle = None if obj is None else self._owned(obj, "object")
        handle = native.find(h, object_handle, encoded)
        return None if handle is None else AnvilMember(self, handle)

    def _append_to(self, collection: "AnvilNode", element: "AnvilNode") -> None:
        self._live()
        collection_handle = self._owned(collection, "collection")
        element_handle = self._owned(element, "element")
        self._check(native.append(self._handle, collection_handle, element_handle))

    # ---- output ----

    def write(self, writer: AnvilWriter) -> None:
        """Streams the whole document into `writer`: header, then every statement. The writer must
        be fresh and of the same dialect; it is not finished -- that is the caller's."""
        h = self._live()
        if not isinstance(writer, AnvilWriter):
            raise TypeError(f"writer must be AnvilWriter, not {type(writer).__name__}")
        self._check(native.write(h, writer._live()))

    def emit(self) -> str:
        """Emits the document as text. May be called again after changing the builder; raises
        AnvilWriterError (leaving the builder intact) if the tree isn't complete."""
        return self.emit_bytes().decode("utf-8")

    def emit_bytes(self) -> bytes:
        """As emit(), but returns the exact bytes -- use it when the document carries blob content
        that isn't valid UTF-8."""
        data = native.emit(self._live())
        if data is None:
            raise self._failure()
        return data

    def dispose(self) -> None:
        if self._disposed:
            return
        native.dispose(self._handle)
        self._disposed = True

    def __enter__(self) -> "AnvilBuilder":
        return self

    def __exit__(self, *exc_info) -> None:
        self.dispose()


class AnvilNode:
    """A value under construction in an AnvilBuilder: a scalar, array, tuple or object. Created
    detached, attached exactly once. A lightweight view -- owned by its builder and invalid after
    AnvilBuilder.dispose()."""

    def __init__(self, builder: AnvilBuilder, handle: int):
        self._builder = builder
        self._handle = handle

    def append(self, element: "AnvilNode") -> "AnvilNode":
        """Appends `element` to this array or tuple. The element must be detached and must not be
        this node or one of its ancestors; in AMP it must be a scalar."""
        self._builder._append_to(self, element)
        return self

    def add(self, name: str, value: "AnvilNode") -> "AnvilMember":
        """Adds the statement `name := value;` to this object. Names inside an object may repeat."""
        return self._builder._add_to(self, name, value)

    def find(self, name: str) -> "AnvilMember | None":
        """Finds a statement by name in this object, or None."""
        return self._builder._find_in(self, name)


class AnvilMember:
    """A statement in an AnvilBuilder -- in the document or in an object: a name, an optional
    base, attributes, and its value. A lightweight view -- owned by its builder and invalid after
    AnvilBuilder.dispose()."""

    def __init__(self, builder: AnvilBuilder, handle: int):
        self._builder = builder
        self._handle = handle

    def set_base(self, base: str) -> "AnvilMember":
        """Declares an inheritance base; this statement's value must be an object. AML only."""
        b = self._builder
        h = b._live()
        b._check(native.set_base(h, self._handle, _args.required(base, "base")))
        return self

    def set_block(self, block: bool = True) -> "AnvilMember":
        """Marks this statement as block form (`name { ... };`, anonymous and read-only); its value must be
        an object (BLOCK_REQUIRES_OBJECT). False restores `name := { ... };`. A block-form member cannot be a
        base: emit() refuses it with BASE_IS_BLOCK_FORM. AML only."""
        b = self._builder
        h = b._live()
        b._check(native.set_block(h, self._handle, bool(block)))
        return self

    def attribute(self, key: str, value: "str | None" = None) -> "AnvilMember":
        """Adds a statement attribute; `value` is raw text or None for a flag. AML only."""
        b = self._builder
        h = b._live()
        b._check(native.member_attribute(h, self._handle, _args.required(key, "key"),
                                         _args.optional(value, "value")))
        return self

    def attribute_string(self, key: str, text: str) -> "AnvilMember":
        """Adds a statement attribute whose value is emitted as a double-quoted string. AML only."""
        b = self._builder
        h = b._live()
        encoded = _args.text(text, "text")
        b._check(native.member_attribute_string(h, self._handle, _args.required(key, "key"),
                                                encoded, len(encoded)))
        return self
