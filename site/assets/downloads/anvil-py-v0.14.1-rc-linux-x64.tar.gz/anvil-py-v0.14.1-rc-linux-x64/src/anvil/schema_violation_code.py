from enum import IntEnum

from anvil._native import schema as native_schema


class SchemaViolationCode(IntEnum):
    """Why a value failed validation. Mirrors anvil_schema_err_code (anvil_schema.h) exactly, including the
    values: ANVIL_SCHEMA_ERR_VALIDATION_X is X here."""

    NONE = 0
    REQUIRED = 1
    TYPE_MISMATCH = 2
    SIZE = 3
    RANGE = 4
    VALUES = 5
    UNKNOWN_FIELD = 6
    ITEM_COUNT = 7
    TAG = 8
    FORMAT = 9
    UNRESOLVED_TYPE = 10
    ATTRIBUTE_MISSING = 11  # load: the document does not carry the @[schema] module attribute

    @property
    def native_name(self) -> str:
        """Native's identifier for this code, e.g. "ANVIL_SCHEMA_ERR_ATTRIBUTE_MISSING"."""
        return native_schema.err_code_name(self.value)

    @property
    def message(self) -> str:
        """Anvil Native's own one-line description of this code."""
        return native_schema.err_code_message(self.value)
