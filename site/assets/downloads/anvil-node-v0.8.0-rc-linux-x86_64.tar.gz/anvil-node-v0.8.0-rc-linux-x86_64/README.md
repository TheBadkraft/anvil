# anvil-node v0.8.0-rc — Linux x86_64

A prebuilt N-API addon for Anvil Native — the reference C implementation of the AML/AMP
parser. `getVersion()`/`parse()`/`parseRawValue()`/`lastError()`, and an `AnvlNode` read-only
facade over a parsed value.

## Requirements

- Node.js with N-API support (any current LTS). Built and tested against Node 22.x; N-API's
  own ABI-stability guarantee means it should work on other recent majors too, but this hasn't
  been verified against older ones — if you hit a missing-symbol error on an old Node version,
  that's why.
- Linux x86_64 (glibc) only. Other platforms: build from source (`npm install && npm run build`
  against `vendor/anvil`'s `v0.8.0-rc` tag) with a C2x compiler and Python 3 for `node-gyp`.

## Usage

Keep `lib/index.js` and `build/Release/anvil_node.node` in this exact relative layout —
`index.js` loads the addon by that relative path.

```js
const anvil = require('./lib/index.js');

const doc = anvil.parse('#!aml\nserver := { host := "localhost"; port := 8080; };');
if (!doc) {
  const err = anvil.lastError();
  console.error(`${err.message} at ${err.line}:${err.column}`);
} else {
  console.log(doc.get('server').get('host').asString()); // "localhost"
}
```

Full API reference: see the anvldata.com Bindings guide.
