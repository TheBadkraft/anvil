# anvil.js

The pure-JavaScript ANVL implementation (published as `anvil.js`, with the same API as anvil-node). ANVL Native is the spec: this reader is held to
it by the native-owned conformance corpus (`vendor/anvil/conformance/`), differential fuzzing and drift tests.

Design (owner-approved in R0): UTF-8 `Uint8Array` input, one `Int32Array` tree with 8 ints per node holding source
spans, values decoded lazily, a single forward pass with no lexer.

- `src/reader.js` header and body scanner; `src/load.js` include graph and phases; `src/resolve.js` the resolver;
  `src/dump.js` the FORMAT.md dump writer; `js/dump.js` the `anvil-dump` command line.
- `src/writer.js` the streaming writer (`AnvilWriter`).

## Use

```js
const anvl = require('anvil.js');          // Node (include resolves against the working directory)
const doc = anvl.parse('#!aml\nid := 9007199254740993;\nname := "x";\n');
doc.get('id').asBigInt();                  // 9007199254740993n
doc.get('name').asString();                // 'x'
anvl.parse('x := 5.;');                    // null; anvl.lastError() is { message, line, column, code, name }
```

In a browser, with no bundler: vendor `dist/anvil.mjs` (`import { parse } from './anvil.mjs'`) or load
`dist/anvil.global.js` with a script tag (it defines `window.anvl`). `npm run build` regenerates both.

The reader API is anvil-node's (`parse`, `parseRawValue`, `lastError`, `getVersion`, `AnvlNode`, `AnvlStatement`) plus
`isNull()`, `blobTag`, `overflowed`, `implementation` (`'anvil.js'`) and `BUILD_INFO.json`. The writer (`AnvilWriter`, `AnvilDialect`, `WriterErrorCode`, `AnvilWriterError`) is anvil-node's, byte for byte
with native's. Types, schema and builder are later phases.

Errors: `lastError()` returns anvil-node's `{ message, line, column }` and, as an addition to anvil-node's API, native's numeric
`code` (for example `4001`) and its `name` (`'ANVL_ERR_PARSER_DUPLICATE_FIELD_IN_OBJECT'`), for `parse()` and `parseRawValue()`
alike, so a consumer can test the code instead of matching message text. They equal the `code=` and `name=` of native's
conformance dump for every error case.

Writer notes (anvil-node's API, which differs from the C API in two ways a JS call cannot avoid): `value(n)` writes a safe
integer as an integer, so `value(1e15)` gives `1000000000000000` (the C `double` verb gives `1e+15`) and `value(-0)` gives `0`
(C gives `-0`); and there is no NULL, so a missing string is a `TypeError` and `string()` takes a JS string, never invalid UTF-8
(use `blob()` for raw bytes). In the browser builds, `data` and `finishBytes()` are `Uint8Array`s; in Node they are Buffers.
