// ES module entry for Node: named exports over the CommonJS entry (so `import { parse } from 'anvil.js'` works).
import api from './index.js';

export const { parse, parseRawValue, lastError, getVersion, AnvlNode, AnvlStatement, implementation, AnvilDialect, WriterErrorCode, AnvilWriterError, AnvilWriter } = api;
export default api;
