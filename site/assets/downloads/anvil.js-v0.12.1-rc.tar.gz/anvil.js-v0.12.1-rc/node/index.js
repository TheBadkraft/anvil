'use strict';
// Node entry point: the browser-safe API, plus the filesystem for `include` (resolved against the working directory,
// as anvil-node does for parse()).
const fs = require('node:fs');
const api = require('../src/api');
const writer = require('../src/writer');

api.setIo({
   readFile(binaryPath) {
      try {
         return fs.readFileSync(Buffer.from(binaryPath, 'latin1'));
      } catch (e) {
         return e.code === 'EISDIR' ? new Uint8Array(0) : null; // native reads a directory as an empty file
      }
   },
});
// anvil-node returns Buffers for the writer's bytes
writer.setBytes((u8) => Buffer.from(u8.buffer, u8.byteOffset, u8.byteLength));
module.exports = require('../src/index.js');
