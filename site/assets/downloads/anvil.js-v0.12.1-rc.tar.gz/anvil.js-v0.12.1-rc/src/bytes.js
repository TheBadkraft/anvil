'use strict';
// Byte helpers with no Node dependency (this code runs in a browser as is). A "binary string" has one char per byte.
const enc = new TextEncoder();

function latin1(buf, s, e) {
   if (s === undefined) { s = 0; e = buf.length; }
   if (e - s <= 8192) return String.fromCharCode.apply(null, buf.subarray(s, e));
   let out = '';
   for (let i = s; i < e; i += 8192) out += String.fromCharCode.apply(null, buf.subarray(i, Math.min(e, i + 8192)));
   return out;
}

const HEX = [];
for (let i = 0; i < 256; i++) HEX.push((i < 16 ? '0' : '') + i.toString(16));
function hex(buf, s, e) {
   let out = '';
   for (let i = s; i < e; i++) out += HEX[buf[i]];
   return out;
}

// a JS string as the binary string of its UTF-8 bytes
function utf8Binary(str) { return latin1(enc.encode(str)); }

// a binary string as bytes
function fromBinary(str) {
   const out = new Uint8Array(str.length);
   for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i);
   return out;
}

module.exports = { latin1, hex, utf8Binary, fromBinary };
