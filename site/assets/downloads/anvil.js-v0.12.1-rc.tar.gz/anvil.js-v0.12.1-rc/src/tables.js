'use strict';
// The constants of the grammar that the reader hardcodes as bytes, spelled out once so the drift tests can compare
// them with the tables native generates from include/*.h (vendor/anvil/conformance/drift-tables.txt).
const KEYWORDS = { include: 'reserved', vars: 'reserved', import: 'reserved', true: 'value', false: 'value', null: 'value' };
const SHEBANGS = { '#!aml': 'AML', '#!amp': 'AMP', '#!asl': 'ASL' };
const EXTENSIONS = { '.aml': 'AML', '.amp': 'AMP', '.asl': 'ASL', '.anvl': 'ANVL' };
const TOKENS = {
   STMT_TERMINATOR: 59, QUOTE: 34, BACKTICK: 96, ATTRIB: 64, LBRACE: 123, RBRACE: 125, LBRACKET: 91, RBRACKET: 93,
   LPAREN: 40, RPAREN: 41, ESCAPE: 92, NEWLINE: 10, RETURN: 13, TAB: 9, DOT: 46,
};
const TOKEN_STRINGS = { SHEBANG_PREFIX: '#!', ASSIGN: ':=', ARROW: '=>' };
// native's internal enums as this reader numbers them is private; what is shared is the NAME of each value type and
// the dialect names the dump prints.
const DIALECT_ENUM = { ANVL_DIALECT_AML: 0, ANVL_DIALECT_ASL: 1, ANVL_DIALECT_AMP: 2, ANVL_DIALECT_ERROR: 3 };
const VALUE_TYPE_ENUM = {
   ANVL_VALUE_NONE: 0, ANVL_VALUE_NULL: 1, ANVL_VALUE_BOOL: 2, ANVL_VALUE_NUMERIC: 3, ANVL_VALUE_STRING: 4,
   ANVL_VALUE_BLOB: 5, ANVL_VALUE_ARRAY: 6, ANVL_VALUE_TUPLE: 7, ANVL_VALUE_OBJECT: 8, ANVL_VALUE_BARE: 9,
   ANVL_VALUE_VARREF: 10, ANVL_VALUE_FUNCTION: 11,
};
const STMT_KIND_ENUM = {
   ANVL_STMT_ASSIGN: 0, ANVL_STMT_OBJECT_BLOCK: 1, ANVL_STMT_VARS: 2, ANVL_STMT_IMPORT: 3, ANVL_STMT_FUNCTION: 4,
};
module.exports = { KEYWORDS, SHEBANGS, EXTENSIONS, TOKENS, TOKEN_STRINGS, DIALECT_ENUM, VALUE_TYPE_ENUM, STMT_KIND_ENUM };
