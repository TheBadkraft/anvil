'use strict';
// The reader: one forward pass over UTF-8 bytes, no lexer and no token array. The tree is one Int32Array with 8
// ints per node holding source spans; nothing is decoded here (strings, numbers and blob bytes are decoded on
// access). It follows ANVL Native's parser step for step, because native is the spec: where native records an
// error and keeps going, so does this (the first error wins, as in native), and a fragment depends on that.
//
// Node ids are offsets into T (a multiple of 8). Two node shapes share the array:
//   value     [type, start, end, aux, aux2, first, next, count]
//               STRING aux = 1 if the span holds a backslash; NUMERIC aux = 1 if float by spelling;
//               BLOB aux/aux2 = tag span (-1 when untagged); VARREF aux/aux2 = target span, first = resolved
//               value node (-1 unresolved); ARRAY/TUPLE/OBJECT first = first child, count = children
//   statement [kind | attrCount << 8, nameStart, nameEnd, baseStart, baseEnd, value, next, firstAttr]
// Attributes live in A, 4 ints each: [keyStart, keyEnd, rawStart, rawEnd].
const { CODES: E } = require('./errors');

const T_NONE = 0, T_NULL = 1, T_BOOL = 2, T_NUMERIC = 3, T_STRING = 4, T_BLOB = 5, T_ARRAY = 6, T_TUPLE = 7,
   T_OBJECT = 8, T_BARE = 9, T_VARREF = 10;
const S_ASSIGN = 16, S_BLOCK = 17;
const D_AML = 0, D_AMP = 1, D_ASL = 2, D_ERROR = 3;

// character classes: 1 identifier start, 2 identifier part, 4 digit, 8 bare-literal part
const CLS = new Uint8Array(256);
for (let c = 0; c < 256; c++) {
   const alpha = (c >= 97 && c <= 122) || (c >= 65 && c <= 90);
   const digit = c >= 48 && c <= 57;
   let v = 0;
   if (alpha || c === 95) v |= 1 | 2 | 8;
   if (digit) v |= 2 | 4 | 8;
   if (c === 45 || c === 46 || c === 47 || c === 58 || c === 36) v |= 8; // - . / : $
   CLS[c] = v;
}

// ---------------------------------------------------------------------------------------------- state
let b = null, n = 0, p = 0;
// Scratch for the tree and the attribute table: a parse that fits uses these and hands back an exact-size copy, so a small
// document costs one allocation for its tree, and nothing it returns aliases the scratch.
const POOL_T = new Int32Array(65536), POOL_A = new Int32Array(1024), EMPTY_A = new Int32Array(0);
let T = POOL_T, nn = 0;
let A = POOL_A, na = 0;
let amp = false, strict = true;
let errCode = 0, errPos = 0;
let baseStmts = [], varrefs = [];

const FAIL = { fail: true };

// An "expected X" error with a stray control character under the cursor is reported as the character itself (5001):
// the position is the same, and the character is the reason.
function isStray(c) { return (c < 32 && c !== 9 && c !== 10 && c !== 13) || c === 127; }
function rec(code, pos) {
   if ((code === E.ANVL_ERR_PARSER_EXPECTED_IDENTIFIER || code === E.ANVL_ERR_PARSER_EXPECTED_ASSIGN ||
        code === E.ANVL_ERR_PARSER_EXPECTED_VALUE || code === E.ANVL_ERR_PARSER_EXPECTED_OBJECT_FIELD ||
        code === E.ANVL_ERR_PARSER_INVALID_KEY_IN_OBJECT) && pos < n && isStray(b[pos])) code = E.ANVL_ERR_PARSER_UNEXPECTED_CHAR;
   if (errCode === 0) { errCode = code; errPos = pos; }
   if (strict) throw FAIL;
}
// an error at a position saved earlier (the start of the token at fault): no stray-character rule
function recExact(code, pos) {
   if (errCode === 0) { errCode = code; errPos = pos; }
   if (strict) throw FAIL;
}

// The tree starts small (a quarter of a byte per int) and, the first time it fills, is grown ONCE to the size projected
// from the bytes read so far (the density of a document is steady), so there is no chain of doublings and little
// garbage; if the projection falls short it grows by half.
let grows = 0, docLo = 0, projected = false;
function growT() {
   grows++;
   let cap;
   if (!projected && p >= (n >> 4) && p > 0 && p < n) {
      projected = true;
      cap = Math.ceil(docLo + (nn - docLo) * (n / p) * 1.04) + 64;
      if (cap < T.length + 512) cap = T.length + 512;
   } else {
      cap = T.length + (T.length >> 1);
   }
   const t = new Int32Array(cap);
   t.set(T);
   T = t;
}

function mk(type, s, e, a, d) {
   if (nn + 8 > T.length) growT();
   const o = nn;
   nn += 8;
   T[o] = type; T[o + 1] = s; T[o + 2] = e; T[o + 3] = a; T[o + 4] = d; T[o + 5] = -1; T[o + 6] = -1; T[o + 7] = 0;
   return o;
}

function mkStmt() {
   if (nn + 8 > T.length) growT();
   const o = nn;
   nn += 8;
   T[o] = S_ASSIGN; T[o + 1] = 0; T[o + 2] = 0; T[o + 3] = -1; T[o + 4] = -1; T[o + 5] = -1; T[o + 6] = -1; T[o + 7] = -1;
   return o;
}

function addAttr(ks, ke, vs, ve) {
   if (na + 4 > A.length) {
      const a = new Int32Array(A.length * 2);
      a.set(A);
      A = a;
   }
   A[na] = ks; A[na + 1] = ke; A[na + 2] = vs; A[na + 3] = ve;
   na += 4;
}

// ---------------------------------------------------------------------------------------------- scanning
// whitespace and comments (Source.skip_whitespace_and_comments). An unterminated block comment records its error
// where the comment OPENS and swallows the rest of the document.
function skipWs() {
   while (p < n) {
      const c = b[p];
      if (c === 32 || c === 10 || c === 9 || c === 13) { p++; continue; }
      if (c === 47 && p + 1 < n) {
         const d = b[p + 1];
         if (d === 47) {
            p += 2;
            while (p < n && b[p] !== 10) p++;
            continue;
         }
         if (d === 42) {
            const open = p;
            p += 2;
            for (;;) {
               if (p >= n) { rec(E.ANVL_ERR_PARSER_UNTERMINATED_COMMENT, open); break; }
               if (b[p] === 42 && p + 1 < n && b[p + 1] === 47) { p += 2; break; }
               p++;
            }
            continue;
         }
      }
      break;
   }
}

function skipSameLine() {
   while (p < n && (b[p] === 32 || b[p] === 9)) p++;
}

function isKeyword(s, e) {
   const len = e - s;
   if (len < 4 || len > 7) return false;
   switch (len) {
   case 4:
      return (b[s] === 118 && b[s + 1] === 97 && b[s + 2] === 114 && b[s + 3] === 115) || // vars
         (b[s] === 116 && b[s + 1] === 114 && b[s + 2] === 117 && b[s + 3] === 101) || // true
         (b[s] === 110 && b[s + 1] === 117 && b[s + 2] === 108 && b[s + 3] === 108); // null
   case 5:
      return b[s] === 102 && b[s + 1] === 97 && b[s + 2] === 108 && b[s + 3] === 115 && b[s + 4] === 101; // false
   case 6:
      return b[s] === 105 && b[s + 1] === 109 && b[s + 2] === 112 && b[s + 3] === 111 && b[s + 4] === 114 &&
         b[s + 5] === 116; // import
   default:
      return b[s] === 105 && b[s + 1] === 110 && b[s + 2] === 99 && b[s + 3] === 108 && b[s + 4] === 117 &&
         b[s + 5] === 100 && b[s + 6] === 101; // include
   }
}

// is_boundary_at: the byte at `at` ends a value
function boundaryAt(at) {
   if (at >= n) return true;
   const c = b[at];
   return c === 32 || c === 9 || c === 13 || c === 10 || c === 59 || c === 44 || c === 93 || c === 41 || c === 125;
}

function exponentFollows(at) {
   if (at >= n) return false;
   const c = b[at];
   if (c !== 101 && c !== 69) return false;
   const d = at + 1 < n ? b[at + 1] : 0;
   return (d >= 48 && d <= 57) || d === 43 || d === 45 || boundaryAt(at + 1);
}

// ---------------------------------------------------------------------------------------------- scalars
// Each returns a value node, or -1 (declined, or failed with the error recorded).
function parseNumeric() {
   const save = p;
   let q = p;
   if (b[q] === 45) q++;
   q++;
   while (q < n && b[q] >= 48 && b[q] <= 57) q++;
   let float = 0;
   if (q < n && b[q] === 46) {
      if (!(q + 1 < n && b[q + 1] >= 48 && b[q + 1] <= 57)) {
         if (exponentFollows(q + 1) || boundaryAt(q + 1)) {
            p = save;
            rec(E.ANVL_ERR_PARSER_INVALID_NUMBER, save);
            return -2;
         }
         return -1;
      }
      q++;
      while (q < n && b[q] >= 48 && b[q] <= 57) q++;
      if (q < n && b[q] === 46) return -1; // a second decimal point
      float = 1;
   }
   if (q < n && (b[q] === 101 || b[q] === 69)) {
      const c1 = q + 1 < n ? b[q + 1] : 0;
      const signed = c1 === 43 || c1 === 45;
      const first = signed ? (q + 2 < n ? b[q + 2] : 0) : c1;
      if (first >= 48 && first <= 57) {
         q += signed ? 2 : 1;
         while (q < n && b[q] >= 48 && b[q] <= 57) q++;
         float = 1;
      } else if (signed || boundaryAt(q + 1)) {
         p = save;
         rec(E.ANVL_ERR_PARSER_INVALID_EXPONENT, save);
         return -2;
      }
   }
   if (!boundaryAt(q)) return -1;
   p = q;
   return mk(T_NUMERIC, save, q, float, 0);
}

function parseString() {
   const s = ++p;
   let esc = 0;
   while (p < n) {
      const c = b[p];
      if (c === 34) break;
      if (c === 92) { esc = 1; p += 2; } else p++;
   }
   if (p > n) p = n;
   if (p >= n) { rec(E.ANVL_ERR_PARSER_UNTERMINATED_STRING, p); return -1; }
   const e = p;
   p++;
   return mk(T_STRING, s, e, esc, 0);
}

function parseBlob() {
   let ts = -1, te = -1, hasTag = false;
   if (b[p] === 64) {
      hasTag = true;
      p++;
      if (p < n && (CLS[b[p]] & 1) !== 0) {
         ts = p;
         while (p < n && (CLS[b[p]] & 2) !== 0 && p - ts < 31) p++;
         te = p;
      } else {
         rec(E.ANVL_ERR_PARSER_INVALID_BLOB_TAG, p);
      }
   }
   if (!(p < n && b[p] === 96)) {
      if (hasTag) rec(E.ANVL_ERR_PARSER_EXPECTED_BACKTICK, p);
      return -1;
   }
   const s = ++p;
   const e = b.indexOf(96, s);
   if (e < 0 || e >= n) {
      p = n;
      rec(E.ANVL_ERR_PARSER_UNTERMINATED_BLOB, p);
      return -1;
   }
   p = e + 1;
   return mk(T_BLOB, s, e, ts, te);
}

function parseBare() {
   const s = p;
   p++;
   while (p < n && (CLS[b[p]] & 8) !== 0) p++;
   if (p < n && (b[p] === 64 || b[p] === 96)) {
      rec(E.ANVL_ERR_PARSER_INVALID_BARE_LITERAL, p);
      return -1;
   }
   if (isKeyword(s, p)) {
      rec(E.ANVL_ERR_PARSER_VALUE_IS_KEYWORD, p);
      return -1;
   }
   return mk(T_BARE, s, p, 0, 0);
}

// true / false / null as a WHOLE token (`nullable` is a bare word)
function parseReserved() {
   const s = p;
   const c = b[p];
   let len = 0, type = 0;
   if (c === 116) { if (b[p + 1] === 114 && b[p + 2] === 117 && b[p + 3] === 101) { len = 4; type = T_BOOL; } } else if (c === 102) {
      if (b[p + 1] === 97 && b[p + 2] === 108 && b[p + 3] === 115 && b[p + 4] === 101) { len = 5; type = T_BOOL; }
   } else if (b[p + 1] === 117 && b[p + 2] === 108 && b[p + 3] === 108) { len = 4; type = T_NULL; }
   if (len === 0 || s + len > n) return -1;
   if (s + len < n && (CLS[b[s + len]] & 8) !== 0) return -1;
   p = s + len;
   return mk(type, s, p, 0, 0);
}

function parseScalar() {
   if (p >= n) return -1;
   const c = b[p];
   if (c === 34) return parseString();
   if ((c >= 48 && c <= 57) || c === 45) {
      if (c === 45 && !(p + 1 < n && b[p + 1] >= 48 && b[p + 1] <= 57)) return -1;
      const v = parseNumeric();
      if (v >= 0) return v;
      if (v === -2 || c === 45) return -1; // malformed, or a '-' that is no bare literal's start
      return parseBare();
   }
   if (c === 64 || c === 96) {
      const v = parseBlob();
      if (v >= 0) return v;
      // a failed blob has consumed its '@' (and tag) without rewinding; native goes on to try a bare literal there
      const d = p < n ? b[p] : 0;
      if ((CLS[d] & 5) !== 0 || d === 46 || d === 47) return parseBare();
      return -1;
   }
   if (c === 116 || c === 102 || c === 110) {
      const v = parseReserved();
      if (v >= 0) return v;
   }
   if ((CLS[c] & 1) !== 0 || c === 46 || c === 47) return parseBare();
   return -1;
}

function parseVarref() {
   const s = p;
   p++;
   if (!(p < n && (CLS[b[p]] & 1) !== 0)) { rec(E.ANVL_ERR_VARS_INVALID_VARREF, p); return -1; }
   const ts = p;
   p++;
   while (p < n && (CLS[b[p]] & 2) !== 0) p++;
   if (p < n && b[p] === 46) { rec(E.ANVL_ERR_VARS_INVALID_VARREF, p); return -1; }
   const v = mk(T_VARREF, s, p, ts, p);
   varrefs.push(v);
   return v;
}

// ---------------------------------------------------------------------------------------------- attributes
function sameKey(ab, as, ae, bs, be) {
   if (ae - as !== be - bs) return false;
   for (let i = as, j = bs; i < ae; i++, j++) if (ab[i] !== ab[j]) return false;
   return true;
}

// An attribute value is a small scalar: one that starts with `[`, `{` or `(` (an array, object or tuple) or with a backtick or
// `@` (a blob, tagged or not) is 2006, decided by the first character alone, wherever a ',' or ']' falls in the rest.
function isCompoundValue(buf, begin, end) {
   if (begin >= end) return false;
   const c = buf[begin];
   return c === 91 || c === 123 || c === 40 || c === 96 || c === 64;
}

// ---------------------------------------------------------------------------------------------- values
function parseValueBody() {
   const v = parseScalar();
   if (v >= 0) return v;
   const c = p < n ? b[p] : 0;
   if (c === 91) return parseCollection(T_ARRAY);
   if (c === 40) return parseCollection(T_TUPLE);
   if (c === 123) {
      if (amp) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
      return parseObjectValue();
   }
   if (c === 36) {
      if (amp) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
      return parseVarref();
   }
   rec(E.ANVL_ERR_PARSER_EXPECTED_VALUE, p);
   return -1;
}

function parseCollection(type) {
   const start = p;
   const close = type === T_ARRAY ? 93 : 41;
   p++;
   skipWs();
   if (p < n && b[p] === close) {
      rec(type === T_ARRAY ? E.ANVL_ERR_PARSER_ARRAY_CANNOT_BE_EMPTY : E.ANVL_ERR_PARSER_EMPTY_TUPLE_NOT_ALLOWED, p);
      return -1;
   }
   let first = -1, last = -1, count = 0;
   while (p < n && b[p] !== close) {
      // a ',' where an element belongs: `(1,,2)`, `(,1)` (an array has no code for it and stays 2003)
      if (type === T_TUPLE && b[p] === 44) { rec(E.ANVL_ERR_PARSER_EMPTY_TUPLE_ELEMENT, p); return -1; }
      if (amp) {
         const lead = b[p];
         if (lead === 123 || lead === 91 || lead === 40) {
            rec(E.ANVL_ERR_AMP_ARRAY_ELEMENT_NOT_SCALAR, p);
            return -1;
         }
      }
      const e = parseValueBody();
      if (e < 0) return -1;
      if (last < 0) first = e; else T[last + 6] = e;
      last = e;
      count++;
      skipWs();
      if (p < n && b[p] === 44) {
         p++;
         skipWs();
         continue;
      }
      if (p < n && b[p] === close) break;
      rec(type === T_ARRAY ? E.ANVL_ERR_PARSER_MISSING_COMMA_IN_ARRAY : E.ANVL_ERR_PARSER_EXPECTED_COMMA_IN_TUPLE, p);
      return -1;
   }
   if (!(p < n && b[p] === close)) {
      rec(type === T_ARRAY ? E.ANVL_ERR_PARSER_EXPECTED_ARRAY_CLOSE : E.ANVL_ERR_PARSER_EXPECTED_TUPLE_CLOSE, p);
      return -1;
   }
   if (type === T_TUPLE && count < 2) {
      rec(E.ANVL_ERR_PARSER_TUPLE_TOO_FEW_ELEMENTS, p);
      return -1;
   }
   p++;
   const v = mk(type, start, p, 0, 0);
   T[v + 5] = first;
   T[v + 7] = count;
   return v;
}

// The names an object body has declared so far, one frame per nesting depth (a repeated one is 4001, at the repeat). A body
// of up to 16 names is a linear scan over the statements already read (no allocation); a bigger one spills into a Map.
const NS_IDS = [], NS_CNT = [], NS_MAP = [];
let ndepth = 0;
function nameKey(ns, ne) {
   let k = '';
   for (let i = ns; i < ne; i++) k += String.fromCharCode(b[i]);
   return k;
}
function addName(d, s, ns, ne) {
   const m = NS_MAP[d];
   if (m !== null) {
      const k = nameKey(ns, ne);
      if (m.has(k)) return true;
      m.set(k, 1);
      return false;
   }
   const ids = NS_IDS[d], cnt = NS_CNT[d], len = ne - ns;
   for (let i = 0; i < cnt; i++) {
      const o = ids[i], os = T[o + 1];
      if (T[o + 2] - os !== len) continue;
      let q = 0;
      while (q < len && b[os + q] === b[ns + q]) q++;
      if (q === len) return true;
   }
   if (cnt < 16) { ids[cnt] = s; NS_CNT[d] = cnt + 1; return false; }
   const spill = new Map();
   for (let i = 0; i < 16; i++) spill.set(nameKey(T[ids[i] + 1], T[ids[i] + 2]), 1);
   spill.set(nameKey(ns, ne), 1);
   NS_MAP[d] = spill;
   return false;
}

// True if the text up to the first non-blank after the ',' at `at` is '}': the comma is the last thing in its object body
function commaEndsObject(at) {
   for (let i = at + 1; i < n; i++) {
      const c = b[i];
      if (c === 32 || c === 9 || c === 13 || c === 10) continue;
      return c === 125;
   }
   return false;
}

// The code for "no identifier here" where a statement's name belongs, by what is actually there. At the top level only an
// attribute block has a more specific code than 2001 (`@[` after the header: a module attribute out of place; `@` alone: an
// attribute block that is not `@[...]`); in an object body a missing key is 3001 and a token that cannot be a key is 4002.
// AMP has no attributes, objects or includes, so it keeps the generic code.
function stmtStartCode(nested) {
   if (amp) return E.ANVL_ERR_PARSER_EXPECTED_IDENTIFIER;
   const c = p < n ? b[p] : 0;
   if (c === 64) {
      if (!(p + 1 < n && b[p + 1] === 91)) return E.ANVL_ERR_PARSER_INVALID_ATTRIBUTE_BLOCK;
      return nested ? E.ANVL_ERR_PARSER_INVALID_KEY_IN_OBJECT : E.ANVL_ERR_PARSER_UNEXPECTED_MODULE_ATTRIBUTES;
   }
   if (!nested) return E.ANVL_ERR_PARSER_EXPECTED_IDENTIFIER;
   if (c === 44 && commaEndsObject(p)) return E.ANVL_ERR_PARSER_TRAILING_COMMA_IN_OBJECT;
   if (c === 59 || c === 44 || c === 58 || c === 61 || c === 41 || c === 93) return E.ANVL_ERR_PARSER_EXPECTED_OBJECT_FIELD;
   return E.ANVL_ERR_PARSER_INVALID_KEY_IN_OBJECT;
}

// the code for a ';' that is not where the statement ends: a ',' closing out an object body is a trailing comma (3004)
function stmtEndCode(nested) {
   return nested && p < n && b[p] === 44 && commaEndsObject(p) ? E.ANVL_ERR_PARSER_TRAILING_COMMA_IN_OBJECT : E.ANVL_ERR_PARSER_UNTERMINATED_STATEMENT;
}

// '{ statements }' : returns the object value node (OBJECT_BLOCK and ASSIGN share this shape)
function parseObjectValue() {
   const start = p;
   p++;
   skipWs();
   if (p < n && b[p] === 125) { rec(E.ANVL_ERR_PARSER_EMPTY_OBJECT_NOT_ALLOWED, p); return -1; }
   let first = -1, last = -1, count = 0;
   const d = ndepth++;
   if (NS_IDS[d] === undefined) NS_IDS[d] = new Int32Array(16);
   NS_CNT[d] = 0; NS_MAP[d] = null;
   while (p < n && b[p] !== 125) {
      const s = parseStatement(d);
      if (s < 0) return -1;
      if (last < 0) first = s; else T[last + 6] = s;
      last = s;
      count++;
   }
   if (!(p < n && b[p] === 125)) { rec(E.ANVL_ERR_PARSER_EXPECTED_OBJECT_CLOSE, p); return -1; }
   ndepth--;
   p++;
   const v = mk(T_OBJECT, start, p, 0, 0);
   T[v + 5] = first;
   T[v + 7] = count;
   return v;
}

// ---------------------------------------------------------------------------------------------- statements
// '@[ key, key=value ]' on a statement. Records the raw spans only; the decoded value is made on access.
function parseAttrList(s) {
   p += 2;
   skipWs();
   const firstAttr = na;
   let count = 0;
   for (;;) {
      skipWs();
      if (!(p < n && (CLS[b[p]] & 1) !== 0)) {
         // `@[]` is an empty block (2008); any other non-key is an invalid attribute identifier (4012)
         rec(count === 0 && p < n && b[p] === 93 ? E.ANVL_ERR_PARSER_EMPTY_ATTRIBUTE_BLOCK : E.ANVL_ERR_PARSER_INVALID_ATTRIBUTE, p);
         return false;
      }
      const ks = p;
      p++;
      while (p < n && (CLS[b[p]] & 2) !== 0) p++;
      const ke = p;
      // a keyword is not an attribute name (4004), and a key repeated within the block is 4013, both where the key starts
      if (isKeyword(ks, ke)) { recExact(E.ANVL_ERR_PARSER_ATTRIBUTE_IS_KEYWORD, ks); return false; }
      for (let a = firstAttr; a < na; a += 4) {
         if (sameKey(b, A[a], A[a + 1], ks, ke)) { recExact(E.ANVL_ERR_PARSER_DUPLICATE_ATTRIBUTE_KEY, ks); return false; }
      }
      let vs = 0, ve = 0;
      skipWs();
      if (p < n && b[p] === 61) {
         p++;
         skipWs();
         if (p < n && b[p] === 36) { rec(E.ANVL_ERR_PARSER_VARREF_NOT_ALLOWED_IN_ATTRIBUTE, p); return false; }
         vs = p;
         let inStr = false;
         while (p < n) {
            const c = b[p];
            if (!inStr && (c === 44 || c === 93)) break;
            if (inStr && c === 92) {
               p++;
               if (p >= n) break;
            } else if (c === 34) inStr = !inStr;
            p++;
         }
         ve = p;
         while (ve > vs) {
            const l = b[ve - 1];
            if (l !== 32 && l !== 9 && l !== 13 && l !== 10) break;
            ve--;
         }
         if (isCompoundValue(b, vs, ve)) { recExact(E.ANVL_ERR_PARSER_INVALID_VALUE_IN_ATTRIBUTE, vs); return false; }
      }
      addAttr(ks, ke, vs, ve);
      count++;
      skipWs();
      if (p < n && b[p] === 44) { p++; continue; }
      if (p < n && b[p] === 93) { p++; break; }
      // another key where a ',' or ']' belongs is a missing comma (3014)
      rec(p < n && (CLS[b[p]] & 1) !== 0 ? E.ANVL_ERR_PARSER_MISSING_COMMA_IN_ATTRIBUTES : E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p);
      return false;
   }
   T[s] = (T[s] & 255) | (count << 8);
   T[s + 7] = firstAttr;
   return true;
}

// d: the name-set depth of the object body this statement is in, or -1 for a top-level statement
function parseStatement(d) {
   const nested = d >= 0;
   const s = mkStmt();
   const ns = p;
   if (!(p < n && (CLS[b[p]] & 1) !== 0)) { rec(stmtStartCode(nested), p); return -1; }
   p++;
   while (p < n && (CLS[b[p]] & 2) !== 0) p++;
   if (isKeyword(ns, p)) {
      // `include` where a top-level statement starts: the header is over, so it is out of place (4201), where it starts
      if (!nested && p - ns === 7 && b[ns] === 105 && b[ns + 1] === 110 && !amp) { recExact(E.ANVL_ERR_INCLUDE_NOT_FIRST, ns); return -1; }
      rec(E.ANVL_ERR_PARSER_IDENTIFIER_IS_KEYWORD, p);
      return -1;
   }
   T[s + 1] = ns;
   T[s + 2] = p;
   if (nested && addName(d, s, ns, p)) { recExact(E.ANVL_ERR_PARSER_DUPLICATE_FIELD_IN_OBJECT, ns); return -1; }
   skipWs();

   // inheritance ': base' (':' not followed by '=')
   if (p < n && b[p] === 58 && !(p + 1 < n && b[p + 1] === 61)) {
      if (amp) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
      p++;
      skipWs();
      const bs = p;
      if (!(p < n && (CLS[b[p]] & 1) !== 0)) { rec(E.ANVL_ERR_PARSER_EXPECTED_IDENTIFIER, p); return -1; }
      p++;
      while (p < n && (CLS[b[p]] & 2) !== 0) p++;
      if (isKeyword(bs, p)) { rec(E.ANVL_ERR_PARSER_IDENTIFIER_IS_KEYWORD, p); return -1; }
      T[s + 3] = bs;
      T[s + 4] = p;
      baseStmts.push(s);
      skipWs();
   }

   if (p + 1 < n && b[p] === 64 && b[p + 1] === 91) {
      if (amp) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
      if (!parseAttrList(s)) return -1;
      skipWs();
   }

   if (p + 1 < n && b[p] === 58 && b[p + 1] === 61) {
      p += 2;
      skipSameLine();
      if (T[s + 3] >= 0 && !(p < n && b[p] === 123)) { rec(E.ANVL_ERR_PARSER_INHERITANCE_REQUIRES_OBJECT, p); return -1; }
      const v = parseValueBody();
      if (v < 0) return -1;
      skipSameLine();
      if (!(p < n && b[p] === 59)) { rec(stmtEndCode(nested), p); return -1; }
      p++;
      skipWs();
      T[s + 5] = v;
      return s;
   }
   if (p < n && b[p] === 123) {
      if (amp) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
      T[s] = (T[s] & ~255) | S_BLOCK;
      const v = parseObjectValue();
      if (v < 0) return -1;
      skipSameLine();
      if (!(p < n && b[p] === 59)) { rec(stmtEndCode(nested), p); return -1; }
      p++;
      skipWs();
      T[s + 5] = v;
      return s;
   }
   // `@` after the name that does not open `@[` is a malformed attribute block (4011)
   rec(p < n && b[p] === 64 && !amp ? E.ANVL_ERR_PARSER_INVALID_ATTRIBUTE_BLOCK : E.ANVL_ERR_PARSER_EXPECTED_ASSIGN, p);
   return -1;
}

// ---------------------------------------------------------------------------------------------- documents
// A document's source: leading whitespace skipped, an optional '#!dialect' (Source.from_buffer). `hint` is the
// dialect a file extension suggests (null for a buffer); a shebang overrides it.
function openSource(buf, hint) {
   const len = buf.length;
   let q = 0, dialect = D_AML, shebang = false;
   if (len >= 2) {
      while (q < len && (buf[q] === 32 || buf[q] === 9 || buf[q] === 13 || buf[q] === 10)) q++;
      if (!(q + 1 >= len || buf[q] !== 35 || buf[q + 1] !== 33)) {
         shebang = true;
         if (len - q < 5) dialect = D_ERROR;
         else if (buf[q + 2] === 97 && buf[q + 3] === 109 && buf[q + 4] === 108) dialect = D_AML;
         else if (buf[q + 2] === 97 && buf[q + 3] === 109 && buf[q + 4] === 112) dialect = D_AMP;
         else if (buf[q + 2] === 97 && buf[q + 3] === 115 && buf[q + 4] === 108) dialect = D_ASL;
         else dialect = D_ERROR;
         if (dialect !== D_ERROR) {
            q += 5;
            if (q < len && buf[q] === 10) q++;
         }
      }
   }
   if (hint !== null && !shebang) dialect = hint;
   return { buf, n: len, dialect, shebang, pos: q, path: null, includes: [], attrFirst: 0, attrCount: 0, firstStmt: -1, nstmt: 0, lo: 0, hi: 0 };
}

// ----- header (document.c: doc_scan_header). Returns 0, or an error code with the position in headerErrPos.
let headerErrPos = 0;
function hdrSkip() {
   while (p < n) {
      const c = b[p];
      if (c === 32 || c === 10 || c === 9 || c === 13) { p++; continue; }
      if (c === 47 && p + 1 < n) {
         const d = b[p + 1];
         if (d === 47) {
            p += 2;
            while (p < n && b[p] !== 10) p++;
            continue;
         }
         if (d === 42) {
            p += 2;
            let closed = false;
            while (p < n) {
               if (b[p] === 42 && p + 1 < n && b[p + 1] === 47) { p += 2; closed = true; break; }
               p++;
            }
            if (!closed) return E.ANVL_ERR_PARSER_UNTERMINATED_COMMENT;
            continue;
         }
      }
      break;
   }
   return 0;
}

function isInclude() {
   return p + 7 <= n && b[p] === 105 && b[p + 1] === 110 && b[p + 2] === 99 && b[p + 3] === 108 && b[p + 4] === 117 &&
      b[p + 5] === 100 && b[p + 6] === 101 && !(p + 7 < n && (CLS[b[p + 7]] & 2) !== 0);
}

let hdrPos = -1; // the position of a header error saved earlier (the start of the token at fault), else the cursor
function hfail(code, pos) { hdrPos = pos; return code; }
function scanHeader(doc) {
   b = doc.buf; n = doc.n; p = doc.pos;
   hdrPos = -1;
   const code = scanHeaderInner(doc);
   if (code) headerErrPos = hdrPos >= 0 ? hdrPos : p;
   doc.pos = p;
   return code;
}

function scanHeaderInner(doc) {
   let code;
   if (doc.shebang && doc.dialect === D_ERROR) return E.ANVL_ERR_PARSER_INVALID_SHEBANG_DIALECT;
   if (doc.shebang && doc.dialect === D_ASL) return E.ANVL_ERR_HEADER_ASL_NOT_SUPPORTED;
   const isAmp = doc.dialect === D_AMP;

   for (;;) {
      if ((code = hdrSkip())) return code;
      if (!isInclude()) break;
      if (isAmp) return E.ANVL_ERR_INCLUDE_AMP_FORBIDDEN;
      const declStart = p;
      p += 7;
      if ((code = hdrSkip())) return code;
      if (!(p < n && b[p] === 34)) return E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN;
      const pathStart = p;
      p++;
      while (p < n && b[p] !== 34) p++;
      if (!(p < n && b[p] === 34)) return E.ANVL_ERR_PARSER_UNTERMINATED_STRING;
      const pathEnd = p;
      p++;
      const declEnd = p;
      if ((code = hdrSkip())) return code;
      if (!(p < n && b[p] === 59)) return E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN;
      p++;
      doc.includes.push({ declS: declStart, declE: declEnd, pathS: pathStart, pathE: pathEnd + 1, resolved: -1 });
   }

   doc.attrFirst = na;
   for (;;) {
      if ((code = hdrSkip())) return code;
      if (!(p + 1 < n && b[p] === 64 && b[p + 1] === 91)) break;
      if (isAmp) return E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN;
      p += 2;
      let first = true;
      for (;;) {
         if ((code = hdrSkip())) return code;
         if (!(p < n && (CLS[b[p]] & 1) !== 0)) {
            // `@[]` is an empty block (2008); any other non-key is an invalid attribute identifier (4012)
            return first && p < n && b[p] === 93 ? E.ANVL_ERR_PARSER_EMPTY_ATTRIBUTE_BLOCK : E.ANVL_ERR_PARSER_INVALID_ATTRIBUTE;
         }
         first = false;
         const ks = p;
         p++;
         while (p < n && (CLS[b[p]] & 2) !== 0) p++;
         const ke = p;
         if (isKeyword(ks, ke)) return hfail(E.ANVL_ERR_PARSER_ATTRIBUTE_IS_KEYWORD, ks);
         // a key repeated anywhere in the module's attributes (4013), at the repeat
         for (let a = doc.attrFirst, k = 0; k < doc.attrCount; k++, a += 4) {
            if (sameKey(b, A[a], A[a + 1], ks, ke)) return hfail(E.ANVL_ERR_PARSER_DUPLICATE_ATTRIBUTE_KEY, ks);
         }
         let vs = 0, ve = 0;
         if ((code = hdrSkip())) return code;
         if (p < n && b[p] === 61) {
            p++;
            if ((code = hdrSkip())) return code;
            if (p < n && b[p] === 36) return E.ANVL_ERR_PARSER_VARREF_NOT_ALLOWED_IN_ATTRIBUTE;
            vs = p;
            let inStr = false;
            while (p < n) {
               const c = b[p];
               if (!inStr && (c === 44 || c === 93)) break;
               if (inStr && c === 92) {
                  p++;
                  if (p >= n) break;
               } else if (c === 34) inStr = !inStr;
               p++;
            }
            ve = p;
            while (ve > vs) {
               const l = b[ve - 1];
               if (l !== 32 && l !== 9 && l !== 13 && l !== 10) break;
               ve--;
            }
            if (isCompoundValue(b, vs, ve)) return hfail(E.ANVL_ERR_PARSER_INVALID_VALUE_IN_ATTRIBUTE, vs);
         }
         if ((code = hdrSkip())) return code;
         addAttr(ks, ke, vs, ve);
         doc.attrCount++;
         if (p < n && b[p] === 44) { p++; continue; }
         if (p < n && b[p] === 93) { p++; break; }
         // another key where a ',' or ']' belongs is a missing comma (3014)
         return p < n && (CLS[b[p]] & 1) !== 0 ? E.ANVL_ERR_PARSER_MISSING_COMMA_IN_ATTRIBUTES : E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN;
      }
   }
   if ((code = hdrSkip())) return code;
   if (isInclude()) return E.ANVL_ERR_INCLUDE_NOT_FIRST; // an include after the module attributes
   // a second shebang, in a document that opened with one (2004); a '#!' with none before it, not on the first line (2005)
   if (p + 1 < n && b[p] === 35 && b[p + 1] === 33) return doc.shebang ? E.ANVL_ERR_PARSER_MULTIPLE_SHEBANG : E.ANVL_ERR_PARSER_SHEBANG_AFTER_STATEMENTS;
   return 0;
}

// ----- body (parser.c: anvl_parse / parse_source). Returns true, or false with the error in errCode/errPos.
function parseBody(doc) {
   b = doc.buf; n = doc.n; p = doc.pos;
   amp = doc.dialect === D_AMP;
   strict = true;
   ndepth = 0;
   doc.lo = nn;
   docLo = nn; projected = false;
   try {
      let last = -1;
      while (p < n) {
         if (p + 1 < n && b[p] === 35 && b[p + 1] === 33) rec(doc.shebang ? E.ANVL_ERR_PARSER_MULTIPLE_SHEBANG : E.ANVL_ERR_PARSER_SHEBANG_AFTER_STATEMENTS, p);
         const s = parseStatement(-1);
         if (s < 0) return false;
         if (last < 0) doc.firstStmt = s; else T[last + 6] = s;
         last = s;
         doc.nstmt++;
      }
      if (errCode !== 0) return false;
      return true;
   } catch (x) {
      if (x !== FAIL) throw x;
      return false;
   } finally {
      doc.hi = nn;
   }
}

// ----- fragment (parser.c: anvl_parse_value_fragment). Returns the value node, or -1 with the error recorded.
function parseFragment(doc) {
   b = doc.buf; n = doc.n; p = doc.pos;
   amp = doc.dialect === D_AMP;
   strict = false;
   ndepth = 0;
   skipWs();
   const v = parseValueBody();
   if (v < 0) return -1;
   skipWs();
   if (p < n && b[p] === 59) {
      p++;
      skipWs();
   }
   if (p < n) { rec(E.ANVL_ERR_PARSER_UNEXPECTED_TOKEN, p); return -1; }
   if (varrefs.length > 0) { rec(E.ANVL_ERR_PARSER_VARREF_NOT_ALLOWED_IN_FRAGMENT, p); return -1; }
   return v;
}

// Starts a fresh parse session (one per load): a new tree, no errors.
function begin(sizeHint) {
   T = (sizeHint | 0) <= POOL_T.length ? POOL_T : new Int32Array(sizeHint | 0);
   nn = 0;
   A = POOL_A;
   na = 0;
   errCode = 0; errPos = 0;
   baseStmts = []; varrefs = [];
   grows = 0; docLo = 0; projected = false;
}

// The tree, cut to the nodes used. The scratch tree is copied out; a tree of its own is shrunk in place where the
// platform can (ArrayBuffer.prototype.transfer reallocates without a second full-size copy), else copied.
const CAN_TRANSFER = typeof ArrayBuffer.prototype.transfer === 'function';
function trimmed() {
   if (T === POOL_T) return T.slice(0, nn);
   if (T.length <= nn + (nn >> 6)) return T;
   return CAN_TRANSFER && T.byteOffset === 0 ? new Int32Array(T.buffer.transfer(nn * 4)) : T.slice(0, nn);
}

// Hands the tree over. The session's arrays are given away, so a later begin() never touches them.
function finish() {
   // keep only what was used: the tree is what stays in memory
   const tree = {
      T: trimmed(), nn,
      A: na === 0 ? EMPTY_A : A === POOL_A || na < A.length ? A.slice(0, na) : A, na, baseStmts, varrefs, grows,
   };
   T = POOL_T; A = POOL_A; baseStmts = []; varrefs = [];
   return tree;
}

function getError() { return { code: errCode, pos: errPos }; }

// A scalar read from the raw text of an attribute value (anvl_attribute_decode): the whole span as one scalar, else
// BARE. Pure: it records nothing. Returns [tree, node] with a one-node scratch tree.
function decodeAttr(buf, vs, ve) {
   const sb = b, sn = n, sp = p, sT = T, snn = nn, sStrict = strict, sCode = errCode, sPos = errPos, sv = varrefs;
   b = buf; n = buf.length; p = vs; strict = false;
   T = new Int32Array(8); nn = 0;
   varrefs = [];
   let v = parseScalar();
   const whole = v >= 0 && p === ve;
   const out = T;
   if (!whole) {
      out[0] = T_BARE; out[1] = vs; out[2] = ve; out[3] = 0; out[4] = 0; out[5] = -1; out[6] = -1; out[7] = 0;
      v = 0;
   }
   b = sb; n = sn; p = sp; T = sT; nn = snn; strict = sStrict; errCode = sCode; errPos = sPos; varrefs = sv;
   return out;
}

module.exports = {
   T_NONE, T_NULL, T_BOOL, T_NUMERIC, T_STRING, T_BLOB, T_ARRAY, T_TUPLE, T_OBJECT, T_BARE, T_VARREF,
   S_ASSIGN, S_BLOCK, D_AML, D_AMP, D_ASL, D_ERROR,
   openSource, scanHeader, parseBody, parseFragment, begin, finish, getError, decodeAttr,
   headerError: () => headerErrPos,
};
