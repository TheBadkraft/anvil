'use strict';
// Loading: a root document (bytes), its include graph, every body, then the resolver; or one value fragment.
// The phases and their error categories are anvil_load's (anvil_flat.c: load_common). Native keeps one error list
// for the whole load and records the first error only, so one `err` here serves every phase.
//
// All file access goes through `io.readFile(path) -> Uint8Array | null`, with paths as binary strings (one char per
// byte), so the loader runs unchanged where there is no filesystem.
const { CODES: E, MESSAGES, CATEGORY } = require('./errors');
const R = require('./reader');
const { latin1 } = require('./bytes');
const { resolve, lineColOf, NO_INHERITED } = require('./resolve');

const PATH_MAX = 1024;

// The dialect a file name suggests (Files.dialect_hint): the text after the LAST '.' in the whole path.
function dialectHint(path) {
   const i = path.lastIndexOf('.');
   if (i < 0) return R.D_AML;
   const ext = path.slice(i);
   if (ext === '.amp') return R.D_AMP;
   if (ext === '.asl') return R.D_ASL;
   return R.D_AML;
}

function makeError(code, line, col, message) {
   return { code, line, col, message: message === undefined ? MESSAGES[code] : message };
}

function contentKey(buf) {
   return latin1(buf);
}

function load(bytes, options) {
   const opts = options || {};
   const rootPath = opts.path === undefined ? null : opts.path;
   const io = opts.io || null;
   const res = { ok: false, category: CATEGORY.OK, err: null, docs: [], tree: null, inherited: NO_INHERITED, root: null };

   R.begin(bytes.length >> 2);
   const root = R.openSource(bytes, rootPath === null ? null : dialectHint(rootPath));
   root.path = rootPath === null ? '<buffer>' : rootPath;
   res.docs.push(root);
   res.root = root;

   const fail = (category, err) => {
      res.category = category;
      res.err = err;
      res.tree = R.finish();
      return res;
   };

   // header
   let code = R.scanHeader(root);
   if (code) {
      const [line, col] = lineColOf(root.buf, R.headerError());
      return fail(CATEGORY.HEADER, makeError(code, line, col));
   }

   // includes
   if (root.includes.length > 0) {
      const registry = new Map();
      registry.set(contentKey(root.buf), root);
      const stack = [];
      const loadChildren = (doc) => {
         stack.push(doc.path);
         for (const inc of doc.includes) {
            const e = loadChild(doc, inc);
            if (e) { stack.pop(); return e; }
         }
         stack.pop();
         return null;
      };
      const loadChild = (parent, inc) => {
         const pb = parent.buf;
         const nameLen = inc.pathE - inc.pathS - 2;
         if (nameLen >= PATH_MAX) return makeError(E.ANVL_ERR_INVALID_ARGUMENT, 1, 1);
         let end = inc.pathS + 1 + nameLen;
         const nul = pb.indexOf(0, inc.pathS + 1);
         if (nul >= 0 && nul < end) end = nul; // C string: the name stops at a NUL
         const name = latin1(pb, inc.pathS + 1, end);
         let resolved;
         if (name.charCodeAt(0) === 47) {
            resolved = name;
         } else {
            const slash = parent.path.lastIndexOf('/');
            let dir = slash < 0 ? '.' : parent.path.slice(0, slash);
            if (dir === '') dir = '.';
            resolved = dir + '/' + name;
            if (resolved.length >= PATH_MAX) return makeError(E.ANVL_ERR_INVALID_ARGUMENT, 1, 1);
         }
         if (stack.includes(resolved)) return makeError(E.ANVL_ERR_INCLUDE_CYCLIC, 1, 1);
         const data = io ? io.readFile(resolved) : null;
         if (!data) return makeError(E.ANVL_ERR_INCLUDE_FILE_NOT_FOUND, 1, 1);
         const child = R.openSource(data, dialectHint(resolved));
         child.path = resolved;
         const key = contentKey(child.buf);
         const existing = registry.get(key);
         if (existing) { inc.resolved = res.docs.indexOf(existing); return null; }
         registry.set(key, child);
         res.docs.push(child);
         const c = R.scanHeader(child);
         if (c) {
            const [line, col] = lineColOf(child.buf, R.headerError());
            return makeError(c, line, col);
         }
         inc.resolved = res.docs.length - 1;
         return loadChildren(child);
      };
      const e = loadChildren(root);
      if (e) return fail(CATEGORY.INCLUDE, e);
   }

   // bodies, in registration order
   for (const doc of res.docs) {
      if (!R.parseBody(doc)) {
         const { code: c, pos } = R.getError();
         const [line, col] = lineColOf(doc.buf, pos);
         return fail(CATEGORY.SYNTAX, makeError(c, line, col));
      }
   }

   res.tree = R.finish();
   const rerr = resolve(res.docs, res.tree, res);
   if (rerr) {
      res.category = CATEGORY.RESOLVE;
      res.err = makeError(rerr.code, rerr.line, rerr.col, rerr.message);
      return res;
   }
   res.ok = true;
   return res;
}

function loadFragment(bytes) {
   const res = { ok: false, category: CATEGORY.OK, err: null, docs: [], tree: null, inherited: NO_INHERITED, root: null, value: -1 };
   R.begin(bytes.length >> 2);
   const doc = R.openSource(bytes, null);
   doc.path = '<fragment>';
   res.docs.push(doc);
   res.root = doc;
   const v = R.parseFragment(doc);
   res.tree = R.finish();
   if (v < 0) {
      const { code, pos } = R.getError();
      const [line, col] = lineColOf(doc.buf, pos);
      res.category = CATEGORY.SYNTAX;
      res.err = makeError(code, line, col);
      return res;
   }
   res.ok = true;
   res.value = v;
   return res;
}

module.exports = { load, loadFragment, dialectHint };
