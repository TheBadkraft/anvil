'use strict';
// anvil.js: the anvil-node reader API over the R1 reader. (Types, schema and builder are later phases.)
const api = require('./api');
const info = require('./build-info');
const writer = require('./writer');

module.exports = {
   parse: api.parse,
   parseRawValue: api.parseRawValue,
   lastError: api.lastError,
   getVersion: () => (info.build ? `${info.nativeVersion}+${info.build}` : info.nativeVersion),
   AnvlNode: api.AnvlNode,
   AnvlStatement: api.AnvlStatement,
   implementation: 'anvil.js',
   AnvilDialect: writer.AnvilDialect,
   WriterErrorCode: writer.WriterErrorCode,
   AnvilWriterError: writer.AnvilWriterError,
   AnvilWriter: writer.AnvilWriter,
};
